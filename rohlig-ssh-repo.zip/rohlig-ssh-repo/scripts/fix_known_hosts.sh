#!/usr/bin/env bash
set -euo pipefail

HOSTS=(
  "172.84.39.88"
  "172.38.89.25"
  "rohlig-cicd"
  "rohlig-app"
)

for host in "${HOSTS[@]}"; do
  echo "Removing stale known_hosts entry for ${host} if present"
  ssh-keygen -R "${host}" >/dev/null 2>&1 || true
done

echo "Done. Reconnect and accept the new fingerprint if the server was rebuilt."
