#!/usr/bin/env bash
set -euo pipefail

HOSTS=("rohlig-cicd" "rohlig-app")

for host in "${HOSTS[@]}"; do
  echo "Testing ${host}..."
  ssh -o BatchMode=yes -o ConnectTimeout=10 "${host}" "hostname && whoami"
  echo
  echo "${host} OK"
  echo "-----------------------------"
done
