#!/usr/bin/env bash
set -euo pipefail

PUB_KEY="${HOME}/.ssh/id_ed25519.pub"

if [[ ! -f "${PUB_KEY}" ]]; then
  echo "Public key not found at ${PUB_KEY}. Run ./scripts/generate_keys.sh first."
  exit 1
fi

SERVERS=(
  "RTITDrrev@172.84.39.88"
  "RTRITDev@172.38.89.25"
)

copy_key() {
  local target="$1"
  echo "Installing key on ${target}"

  if command -v ssh-copy-id >/dev/null 2>&1; then
    ssh-copy-id -i "${PUB_KEY}" "${target}"
  else
    echo "ssh-copy-id not found. Falling back to manual install for ${target}."
    cat "${PUB_KEY}" | ssh "${target}" 'mkdir -p ~/.ssh && chmod 700 ~/.ssh && cat >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys'
  fi
}

for server in "${SERVERS[@]}"; do
  copy_key "${server}"
done

echo "Public key installation complete."
