#!/usr/bin/env bash
set -euo pipefail

KEY_PATH="${HOME}/.ssh/id_ed25519"
PUB_PATH="${KEY_PATH}.pub"

mkdir -p "${HOME}/.ssh"
chmod 700 "${HOME}/.ssh"

if [[ -f "${KEY_PATH}" && -f "${PUB_PATH}" ]]; then
  echo "SSH key already exists at ${KEY_PATH}"
  exit 0
fi

echo "Generating SSH key at ${KEY_PATH}"
ssh-keygen -t ed25519 -C "robert@local" -f "${KEY_PATH}"
echo "Done. Public key: ${PUB_PATH}"
