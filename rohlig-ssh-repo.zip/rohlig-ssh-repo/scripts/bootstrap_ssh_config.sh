#!/usr/bin/env bash
set -euo pipefail

SSH_DIR="${HOME}/.ssh"
CONFIG_FILE="${SSH_DIR}/config"
TEMPLATE_FILE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../config" && pwd)/ssh_config.template"

mkdir -p "${SSH_DIR}"
chmod 700 "${SSH_DIR}"
touch "${CONFIG_FILE}"
chmod 600 "${CONFIG_FILE}"

append_block_if_missing() {
  local host_name="$1"
  local block_file="$2"

  if grep -q "^Host ${host_name}$" "${CONFIG_FILE}"; then
    echo "Host ${host_name} already exists in ${CONFIG_FILE}"
  else
    awk -v host="${host_name}" '
      $0 == "Host "host {print_block=1}
      print_block {print}
      print_block && /^$/ {exit}
    ' "${block_file}" >> "${CONFIG_FILE}"
    printf "\n" >> "${CONFIG_FILE}"
    echo "Added host ${host_name} to ${CONFIG_FILE}"
  fi
}

append_block_if_missing "rohlig-cicd" "${TEMPLATE_FILE}"
append_block_if_missing "rohlig-app" "${TEMPLATE_FILE}"

echo "SSH config bootstrap complete."
