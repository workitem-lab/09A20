# Röhlig SSH Access Repo

This repo gives you a clean, reusable SSH setup for your two Ubuntu servers.

## Servers

- `rohlig-cicd` → `172.84.39.88` → user `RTITDrrev`
- `rohlig-app` → `172.38.89.25` → user `RTRITDev`

## What this repo does

- generates an SSH key if you do not already have one
- installs your public key onto both servers
- creates a reusable SSH config with aliases
- tests passwordless login
- fixes stale host key entries when a server is rebuilt

## Important

This repo does **not** store passwords.
You will type the server passwords yourself when prompted.

## Quick start

Run these commands on your Mac:

```bash
cd rohlig-ssh-repo
chmod +x scripts/*.sh
./scripts/generate_keys.sh
./scripts/install_public_key.sh
./scripts/bootstrap_ssh_config.sh
./scripts/test_connections.sh
```

After that, use:

```bash
ssh rohlig-cicd
ssh rohlig-app
```

## Repo structure

```text
rohlig-ssh-repo/
├── README.md
├── config/
│   └── ssh_config.template
└── scripts/
    ├── bootstrap_ssh_config.sh
    ├── fix_known_hosts.sh
    ├── generate_keys.sh
    ├── install_public_key.sh
    └── test_connections.sh
```

## Step-by-step

### 1) Generate a key

```bash
./scripts/generate_keys.sh
```

This creates `~/.ssh/id_ed25519` and `~/.ssh/id_ed25519.pub` if they do not already exist.

### 2) Install your public key on both servers

```bash
./scripts/install_public_key.sh
```

This uses `ssh-copy-id` if available.
If `ssh-copy-id` is not available, it falls back to a manual SSH method.

### 3) Create SSH aliases

```bash
./scripts/bootstrap_ssh_config.sh
```

This appends the following aliases to `~/.ssh/config` if they are not already present:

- `rohlig-cicd`
- `rohlig-app`

### 4) Test access

```bash
./scripts/test_connections.sh
```

## Useful commands

### Connect

```bash
ssh rohlig-cicd
ssh rohlig-app
```

### Copy a file

```bash
scp local-file.txt rohlig-cicd:/home/RTITDrrev/
scp local-file.txt rohlig-app:/home/RTRITDev/
```

### Run a command remotely

```bash
ssh rohlig-cicd "hostname && docker ps"
ssh rohlig-app "hostname && docker compose ps"
```

### Fix host key problems

If a server is rebuilt and SSH complains that the remote host identification changed:

```bash
./scripts/fix_known_hosts.sh
```

Then reconnect and accept the new fingerprint.

## Optional hardening

Only do this after confirming SSH key login works.

On each server:

```bash
sudo nano /etc/ssh/sshd_config
```

Recommended settings:

```text
PubkeyAuthentication yes
PasswordAuthentication no
PermitRootLogin no
```

Then restart SSH:

```bash
sudo systemctl restart ssh
```

Keep one session open while testing changes so you do not lock yourself out.
