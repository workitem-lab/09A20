# Röhlig Postman 300+ Final Fixed Pack

## What was fixed
- replaced broken Postman URL object style `host: ["{{baseUrl}}"]`
- rebuilt requests with explicit:
  - `protocol`
  - `host`
  - `port`
  - `path`
- preserved raw URLs and environment variables

## Import order
1. import the environment file
2. import the collection file
3. select the environment
4. run `00 Setup Tokens Health` first

## Environment variables
- `baseScheme` = http
- `baseHost` = localhost
- `basePort` = 8080
- `keycloakScheme` = http
- `keycloakHost` = localhost
- `keycloakPort` = 8090
