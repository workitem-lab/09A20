%PDF-1.4
%���� ReportLab Generated PDF document (opensource)
1 0 obj
<<
/F1 2 0 R /F2 3 0 R /F3 7 0 R
>>
endobj
2 0 obj
<<
/BaseFont /Helvetica /Encoding /WinAnsiEncoding /Name /F1 /Subtype /Type1 /Type /Font
>>
endobj
3 0 obj
<<
/BaseFont /ZapfDingbats /Name /F2 /Subtype /Type1 /Type /Font
>>
endobj
4 0 obj
<<
/Contents 12 0 R /MediaBox [ 0 0 595.2756 841.8898 ] /Parent 11 0 R /Resources <<
/Font 1 0 R /ProcSet [ /PDF /Text /ImageB /ImageC /ImageI ]
>> /Rotate 0 /Trans <<

>> 
  /Type /Page
>>
endobj
5 0 obj
<<
/Contents 13 0 R /MediaBox [ 0 0 595.2756 841.8898 ] /Parent 11 0 R /Resources <<
/Font 1 0 R /ProcSet [ /PDF /Text /ImageB /ImageC /ImageI ]
>> /Rotate 0 /Trans <<

>> 
  /Type /Page
>>
endobj
6 0 obj
<<
/Contents 14 0 R /MediaBox [ 0 0 595.2756 841.8898 ] /Parent 11 0 R /Resources <<
/Font 1 0 R /ProcSet [ /PDF /Text /ImageB /ImageC /ImageI ]
>> /Rotate 0 /Trans <<

>> 
  /Type /Page
>>
endobj
7 0 obj
<<
/BaseFont /Symbol /Name /F3 /Subtype /Type1 /Type /Font
>>
endobj
8 0 obj
<<
/Contents 15 0 R /MediaBox [ 0 0 595.2756 841.8898 ] /Parent 11 0 R /Resources <<
/Font 1 0 R /ProcSet [ /PDF /Text /ImageB /ImageC /ImageI ]
>> /Rotate 0 /Trans <<

>> 
  /Type /Page
>>
endobj
9 0 obj
<<
/PageMode /UseNone /Pages 11 0 R /Type /Catalog
>>
endobj
10 0 obj
<<
/Author (\(anonymous\)) /CreationDate (D:20260407043919+00'00') /Creator (\(unspecified\)) /Keywords () /ModDate (D:20260407043919+00'00') /Producer (ReportLab PDF Library - \(opensource\)) 
  /Subject (\(unspecified\)) /Title (\(anonymous\)) /Trapped /False
>>
endobj
11 0 obj
<<
/Count 4 /Kids [ 4 0 R 5 0 R 6 0 R 8 0 R ] /Type /Pages
>>
endobj
12 0 obj
<<
/Filter [ /ASCII85Decode /FlateDecode ] /Length 987
>>
stream
GatU3>u03/'RfGR\.UGK.4'.$>A4V,JqdY`cq;b6,RB62]V]jkS8S<"F44"kgNAWUV'sJXHB,2T\[`mARic@*q&J>A(_0=J&.7G(OK]\@p]=41S];5ngmOt"`'H=VH`;:bF7fltE$uu9kcs0WJ=:Wi,M@r.[.C[*^D0"8o_WuS!99^63dl9ZCbEK6*A5urQ0,i!-r&VtaeHm7QNB?`WaLF:C&?]\_eNU]s2YTS\cN7-EQIUZY'U\6$`4]0rN[l4HTd<L:(p.cnH5tgOEiWp6A')raT\_25;3Z8[t_2jZ(/U-2@9Y)0s#+t$X#Bg;YR;>P6BDT7uhmY3,QeN'WWKY=[($+48([p,#guJ33,#ObIj(m%'mn&8naf/XnT?PCoZ31X/Z0E:J>'c@oP>[9F7T@%Ml,qjg*^mRsf?gW`$KASe5&.Rff]NJstI!q'ZrRY0l`$c_`Nkcq)f^(l'<e+INe)mb42_`gep<;CtW-J+*e7>+*skW#^#A68UAS.)7"k)RHPTCVh<JAh3H.ZZU2,bsZPbUCMWaJATf!5SGG<<-E7/W7/Z*g$,AV9N5%W(#H)96ld6OXq(/+msu?TG%QWC/L9aYIC<utG'4rb>gRONS6<=l2b6fTfq8J'@V:bU4(8bphR#Ql%afKZ2738YU-*eWRkZ%a[;D"d6F>q4de@.fFAplbdM*,n9j@d?h2(72E<1\MR+>S;@l,)\EfJ)ph49fe6k)o5DVL9B^SL0J"No60/&82.oi&W?3e59/r8dbF`UN*hp1WsWm-D]nR%*qslq-@=9DnMSBJfQD]H1m,Hu-*"Qcm;"VRYBEI[QVdUS68,dU'a*eog"j,L12];/:d\bQd#^3,tP+=1L;V@`#&*4_:L]XINL[itFCt`rpjmR+X7d-",s6T]AJ^XWITI+1]KT7dc7p]]<\GIa[1d't7qoa6<1d?4sk`3>'qma^A4*EAgp9O^P`.kt(guHTRJ)J=uK=l"-Q4~>endstream
endobj
13 0 obj
<<
/Filter [ /ASCII85Decode /FlateDecode ] /Length 794
>>
stream
Gau1,9omaW&;KZP'dNAQ84hjF`/2ED@?D+J=]'1ARsNh*o7cQao\\];.q"LZD2hSYEd<joB?&8V$"X#Ya*6>?grs4#M#a5'IfR>a%eDclSPQsqaRbaPKL1c"b#8(#]T=-;Z_$rAamX145^*R#*CJ4ATJt?a'Y]U)l.9l1$k>H0rBmo?$hHlU^H;5Gqradls5WdU7*EY.(5kW.PE`"Y<^_8fA(dj3p!,C3T+5W!2Dd;F%QdU)X3Hhdl/N;@2V.<'8c35i2pRE5Cpqmk\fK;/P*sO+7]Wu(1G`k$E:<A'_!9";Gb*^QKg7d';N=D%7:qu68MF)g:sX[1E/DSq"gA]Tm$?Atg1^p:p"0cO:A6AC!C:?C,\<o"AF)])#5`I[SSDB]qDrBCL,'PK3aj4nSZjn\$@ts)i3Ca=GH1a\Y=<23<Y%c"\'!F%%d(]+mKJU3r`gNN8oR>D:l1P=Euj'8<8H3l$^'TbKpUu+F<,=O_TI-TXD2RcBk*X+Y<\)BSNW*C%Le&Xdo^k(9u!\\D*1*Uj]O.6ST\bES>np$X@10?17#RZFh31R'q-[R^"*'2QpcLGa$_J&G1:ZEFH2O)==ea;T6F3a>6,1Z;j972U=Z5ZrGilO\EXJkNL%tj.9CHUe5Eb6BMKjG)_GN5o)jFNCc"XjUHB;MVu<&a:5>l_-ubEj!dE%V;hF!uZWQ#:oB/h?'K..F@Cu*C8V&WenlY&"/f,^.ap<p%X<)\cRblq<@;h$D7S#(C$(SI#,ot<.g.jaEq=X_]Vq+pT.e56nq[#rF!RP%aeG~>endstream
endobj
14 0 obj
<<
/Filter [ /ASCII85Decode /FlateDecode ] /Length 760
>>
stream
Gau1-6'%Kh&;BTK'dMhg<[*H]%>J)NCt2O4aED:DEJU+2&>7%"P^d%Y'"-Gn1V7\86K7QDjr(n<++r3Qm!Q#1!7MQu4tp@ab4!-a6pUPcDTgGR&\C5p.EEd(.$Z=_L)8jU?oK>10)Jr"(YE(e`TL.sZ-\uSZYh2J6MU`+GE6n8rUmP+pf%'.M<BG,,H/3)l+/`qi>iW*@MP(Z=H9tKZTo>Mjc\nsjr)a6Oq]N[1=5914GF)NO*,#)a/MIRbN+r&P"<rk8LTn9YJ1r:e6Q:oOcf#kMJ!i_ijl,EFn(V*/oq_"WC!lF)lM<ABlYb9L12LY:s<+V2[-:)[5722)IBXsM#o%n-u_Ol.XLIgMO`b$aLP7<f03s[K/<4=62"q>F!;-+DD7'L>\D0D$\e-uZ;BD"h\T\4D,YAIlb=f1UaULTL6D</3@"`bRRfbBMkIg+5@ePing7HmDq])fHeIX2@MH=?K`_"m^7Jj`C6XtBOphLNMB^KJ5_5`,"IFB.3=TF!Zb)^[*,aN5DC`%PXWuXXP\WmK;2OJpdkEr7bo5`8hZPL[HbD-9jddoD0R+?o(_J;/_\QJ^enjWffb8'C77Vugn9?uQIFFbF=DQP0<dnOr8.u;%4XG)Q@]qU=4@Z:t,_j?FVZ((+jMZhTl<nBtraV7fYYu/UL08I4Nr3#F<Fars=Y:adds*KW_7;OWYChDB<7\P[l4uR/3,NFN4f8]!aXfCs?bCcS^7S9)06ns=s3[9se.W-X^An@`2A?~>endstream
endobj
15 0 obj
<<
/Filter [ /ASCII85Decode /FlateDecode ] /Length 625
>>
stream
Gau1-9omaW&;KZP'dN+"&#G7!kDL;6D@p???oQlN\>e4$)S:qKV#G_r;R(>?0o@7kWL"tgIdPGX3XepdYk)eb"5L==>;BS(Zl<D#b+ZM(]6<aT_Cfb-2,jaKeoapg$4kQ@_!T(lZ9R`(KDp(qo\:oX20tB1a\-<^62TrsoWs%M)tTuI,>_,[ejM"$\Uec.+,s=HT[MSfm'Io>d&:bo<*-=0%%ko=dd?+'iAJ88Yn:/iddU[I8^u0[)qmne<MZS!L_f[&9(8iWFV^cZ+,nW#XJ717*<F)mPir'ZB$2_Qf*ickUGUP-IV,W0/<putG`1BQ3SCqDAOq9tOQHkCRRUkijVIEbgm`pa3")<0o5"=_/'86F<XH7XXbQ8UFQ6$Wmq;72pp,VDb99!hXg/Ftiu:,VEI=mt'*di&'P+Y*&>rAHSOd2d'H%cJ+iJ&Y`l=7PcfMgGCS6O!iGn(.J]H.2GXEfU#h:c3@WSX,.1>ktO80TnFMe,!$>h^+HOE>"+P<H3ZM1h^1N.lW.`q>Bn_XQ?fSR:Dm=T]'l0eVD`?pXQ>'BoO9$TtKn21-UT'sq.:/HgjE/sLD*;I1,^R+DrPB]?(A[4b0%N[lAO[C!Qjkg=j^AoqK6Vm~>endstream
endobj
xref
0 16
0000000000 65535 f 
0000000061 00000 n 
0000000112 00000 n 
0000000219 00000 n 
0000000302 00000 n 
0000000507 00000 n 
0000000712 00000 n 
0000000917 00000 n 
0000000994 00000 n 
0000001199 00000 n 
0000001268 00000 n 
0000001549 00000 n 
0000001627 00000 n 
0000002705 00000 n 
0000003590 00000 n 
0000004441 00000 n 
trailer
<<
/ID 
[<0351eaf64daa024f067450b7dd864e98><0351eaf64daa024f067450b7dd864e98>]
% ReportLab generated PDF document -- digest (opensource)

/Info 10 0 R
/Root 9 0 R
/Size 16
>>
startxref
5157
%%EOF
