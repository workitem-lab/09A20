# Röhlig Easy Estimate — End-to-End Interaction Flow

## 04 — System Flow, Service Purposes, Business Process Alignment, and Interactions

## Business-aligned service purposes

### Gateway
- single secured API entry point for frontend and approved clients
- routes requests to internal domain services
- enforces authentication, authorization, and request policies
- centralizes access so internal services are not exposed directly

### Customer Integration Service
- manages customer identity inside Easy Estimate
- supports two customer states:
  - `PROSPECT`
  - `REGISTERED`
- stores Easy Estimate temporary customer records for prospects
- maintains mapping between:
  - `easy_estimate_client_id`
  - `shipship_client_code`
- synchronizes registered customer reference data from ShipShip
- handles prospect-to-registered conversion linkage
- preserves customer traceability and audit history

### Shipment Service
- stores and validates shipment or quote request records
- links a shipment/estimate request to a customer identity
- supports quotation requests for both:
  - prospects
  - registered customers
- enforces idempotent create behavior
- emits shipment-created or estimate-request-created events

### Tariff Service
- resolves tariff, customs, and regulatory inputs
- provides customs-related rules and calculation inputs
- supports costing decisions independently from customer ownership
- returns tariff-related enrichment for costing flow

### Rate Repository Service
- stores locally synchronized pricing data used by Easy Estimate
- holds:
  - standard prospect / market / onboarding rates
  - synchronized customer-specific rates from ShipShip
- supports local quoting without hard runtime dependency on ShipShip
- provides versioned, auditable rate lookup capability

### Rates Importer / Sync Service
- imports approved rate files where required
- loads customer-specific and standard rates into the local pricing repository
- supports bulk migration from ShipShip data extracts
- supports scheduled synchronization from ShipShip
- audits import and sync batches
- records success, failure, mismatch, and reconciliation outcomes

### Costing Service
- determines which pricing path applies:
  - prospect pricing path
  - registered-customer pricing path
- combines:
  - shipment/request data
  - tariff inputs
  - customer identity status
  - synchronized rate data
- calculates estimate totals, charge lines, and pricing breakdowns
- applies correct pricing rules depending on whether the customer is:
  - `PROSPECT`
  - `REGISTERED`

### Quotation Service
- generates business quotations from shipment and costing data
- stores quote projections, snapshots, and document history
- creates CSV/PDF quotation outputs
- preserves quote auditability even if customer details or rates later change
- supports historic quotes for both prospects and registered customers

### ShipShip Integration Boundary
- ShipShip remains the source of truth for:
  - registered customer master data
  - official `client_code`
  - customer-specific contractual rates where applicable
- Easy Estimate consumes and synchronizes approved data from ShipShip
- Easy Estimate does not own master registration of registered customers
- Easy Estimate does own quotation workflow, quote history, and prospect handling

---

## Business process coverage

This target flow solves the main business problems:

1. **Quote new prospective customers before they exist in ShipShip**
   - Easy Estimate creates a temporary prospect record
   - assigns a local `easy_estimate_client_id`
   - applies prospect/default pricing

2. **Quote existing registered ShipShip customers using customer-specific rates**
   - Easy Estimate identifies the customer through mapped `shipship_client_code`
   - retrieves synchronized customer-specific pricing from the local rate repository
   - generates quote using correct contractual pricing

3. **Support migration and synchronization of customer and rate data**
   - existing ShipShip customer master data is migrated into Easy Estimate reference/mapping structures
   - customer-specific rate data is migrated or synchronized into the local pricing repository
   - ongoing sync keeps Easy Estimate aligned with ShipShip

4. **Reconcile prospects to official registered customers after conversion**
   - when a prospect becomes a registered customer in ShipShip, Easy Estimate updates the mapping
   - the temporary Easy Estimate customer is linked to the permanent ShipShip customer
   - future quotations use registered-customer pricing rules
   - historical quotations remain unchanged and auditable

---

## Target interaction model

### Flow A — Quoting a new prospect

1. User creates a prospect in Easy Estimate
2. Easy Estimate creates a temporary customer identity with status `PROSPECT`
3. User submits shipment / quote request
4. Shipment Service stores the request linked to the prospect identity
5. Costing Service identifies the customer as `PROSPECT`
6. Costing Service retrieves standard prospect / onboarding / market rates from the local Rate Repository
7. Tariff Service resolves customs and tariff inputs
8. Costing Service calculates estimate totals
9. Quotation Service generates quotation snapshot and documents
10. Quote is stored and remains historically auditable

### Flow B — Quoting an existing registered customer

1. User selects or searches for an existing registered customer
2. Customer Integration Service resolves the mapped `shipship_client_code`
3. Shipment Service stores the request linked to the registered customer
4. Costing Service identifies the customer as `REGISTERED`
5. Costing Service retrieves synchronized customer-specific rates from the local Rate Repository
6. Tariff Service resolves customs and tariff inputs
7. Costing Service calculates estimate totals
8. Quotation Service generates quotation snapshot and documents
9. Quote is stored with customer and pricing traceability

### Flow C — Prospect conversion to registered customer

1. Prospect is successfully registered in ShipShip
2. ShipShip creates the official permanent `client_code`
3. Integration process sends or syncs the new registered customer identity to Easy Estimate
4. Customer Integration Service updates mapping:
   - `easy_estimate_client_id` -> `shipship_client_code`
5. Customer status changes from `PROSPECT` to `REGISTERED`
6. Future pricing requests use registered-customer rate logic
7. Historical quotes remain tied to the original quote snapshot for audit purposes

### Flow D — Customer and rate synchronization

1. Initial migration loads existing ShipShip customers and customer-specific rates
2. Easy Estimate stores them in local customer reference and pricing structures
3. Scheduled sync / event-driven sync / controlled import updates changes
4. Reconciliation process flags:
   - missing customers
   - missing client mappings
   - missing rates
   - inactive or expired rate data
5. Operations teams review exceptions and correct mismatches

---

## End-to-end interaction flow

```mermaid
sequenceDiagram
    participant U as User / Frontend
    participant G as Gateway
    participant CI as Customer Integration Service
    participant S as Shipment Service
    participant T as Tariff Service
    participant RR as Rate Repository Service
    participant RS as Rates Importer / Sync Service
    participant C as Costing Service
    participant Q as Quotation Service
    participant SS as ShipShip

    Note over U,SS: Flow 1 — Quote a Prospect
    U->>G: Create prospect customer
    G->>CI: POST /customers/prospects
    CI-->>G: easy_estimate_client_id + status=PROSPECT

    U->>G: Create shipment / quote request
    G->>S: POST /api/v1/shipments
    S-->>G: Shipment created

    G->>C: Request estimate calculation
    C->>CI: Resolve customer status
    CI-->>C: PROSPECT
    C->>RR: Lookup prospect/default rates
    RR-->>C: Standard rate set
    C->>T: Resolve tariff/customs inputs
    T-->>C: Tariff response
    C-->>G: Cost lines + totals

    G->>Q: Generate quotation
    Q->>S: Get shipment/request data
    Q->>C: Get costing result
    Q-->>G: Quote snapshot + CSV/PDF
    G-->>U: Prospect quotation

    Note over U,SS: Flow 2 — Quote Registered Customer
    U->>G: Search/select registered customer
    G->>CI: Resolve registered customer
    CI->>SS: Sync/lookup registered customer reference
    SS-->>CI: shipship_client_code + customer details
    CI-->>G: REGISTERED customer identity

    U->>G: Create shipment / quote request
    G->>S: POST /api/v1/shipments
    S-->>G: Shipment created

    G->>C: Request estimate calculation
    C->>CI: Resolve customer status
    CI-->>C: REGISTERED + shipship_client_code
    C->>RR: Lookup synced customer-specific rates
    RR-->>C: Customer-specific rate set
    C->>T: Resolve tariff/customs inputs
    T-->>C: Tariff response
    C-->>G: Cost lines + totals

    G->>Q: Generate quotation
    Q->>S: Get shipment/request data
    Q->>C: Get costing result
    Q-->>G: Quote snapshot + CSV/PDF
    G-->>U: Registered-customer quotation

    Note over U,SS: Flow 3 — Prospect Conversion
    SS-->>RS: Registered customer created / changed
    RS->>CI: Update customer mapping
    CI-->>RS: easy_estimate_client_id linked to shipship_client_code
    RS->>RR: Sync customer-specific rates
    RR-->>RS: Rates updated

    Note over U,SS: Flow 4 — Bulk Migration / Ongoing Sync
    SS-->>RS: Customer master extract
    SS-->>RS: Customer-specific rates extract
    RS->>CI: Load/update customer mappings
    RS->>RR: Load/update local rate repository
    RS-->>G: Sync/audit outcome available to operations
```

---

## Key service interaction rules

### Customer identity rules
- every quote request must be tied to a customer record in Easy Estimate
- a customer must always be in one of these states:
  - `PROSPECT`
  - `REGISTERED`
- `PROSPECT` customers use temporary Easy Estimate identity only
- `REGISTERED` customers must be linked to a valid `shipship_client_code`
- once linked, future quotes must use the registered-customer pricing path

### Pricing rules
- prospect pricing must come from standard/default/prospect rate sets
- registered customer pricing must come from synchronized ShipShip customer-specific rates
- Easy Estimate should quote using its **local synchronized pricing repository**
- ShipShip should not be required synchronously for every quote request
- local quote execution improves:
  - performance
  - resilience
  - auditability
  - operational independence

### Audit and reconciliation rules
- quote snapshots must preserve the exact customer and pricing context used at the time of quotation
- later changes in ShipShip must not silently alter historical quotations
- all customer/rate sync operations must be auditable
- mismatches must be reported for operational follow-up

### Integration rules
- ShipShip remains source of truth for registered customers and contractual customer pricing
- Easy Estimate remains source of truth for:
  - prospect records
  - quote workflow
  - quote outputs
  - quote history
  - quote snapshots
- synchronization should support:
  - initial bulk migration
  - incremental sync
  - reconciliation reporting
  - failure recovery

---

## Why this is the better target design

This design is stronger because it:
- supports both prospects and registered customers cleanly
- separates master-data ownership from quote execution ownership
- avoids making ShipShip a hard real-time dependency for every quote
- supports customer-specific pricing without losing prospect support
- makes conversion from prospect to registered customer explicit and auditable
- preserves quote history even after customer or pricing changes
- aligns better with enterprise integration best practice:
  - system of record
  - system of engagement
  - local synchronized execution
  - auditable reconciliation

---

## Architecture conclusion

The target operating model should be:

- **ShipShip**
  - source of truth for registered customers
  - source of truth for official `client_code`
  - source of truth for customer-specific contractual pricing

- **Easy Estimate**
  - system of engagement for quotation creation
  - owner of prospect handling
  - owner of quote execution
  - owner of quote history and quote documents
  - local synchronized consumer of registered customer and pricing data

This is the best-practice design to solve the full business problem across quotation, pricing, customer lifecycle, migration, synchronization, and auditability.
