# Customer Integration Design and Implemented Backend Scope

## What this backend now includes

A dedicated `customer-integration-service` has been added to align the backend with the approved Easy Estimate + ShipShip operating model.

### Implemented capabilities
- prospect customer creation with `easy_estimate_client_id`
- customer states: `PROSPECT` and `REGISTERED`
- linkage of a prospect to a permanent `shipship_client_code`
- registered customer synchronization via batch API
- auditable customer sync batch table
- gateway routing and role-based access for customer APIs
- production-safe compose posture with internal services not published to the host
- corrected Postgres healthcheck syntax for Docker Compose

## Current service boundaries
- ShipShip remains the source of truth for registered customers and contractual rates
- Easy Estimate owns prospects, quotation workflow, quote history, and local quote execution
- The new customer service provides the identity bridge between those two worlds

## Important implementation note

The existing shipment, costing, and quotation flows continue to use `clientId` as the quote-time customer reference. In this implementation, that value can represent either:
- a temporary Easy Estimate prospect identifier, or
- a ShipShip registered customer code

The new customer mapping service provides the lifecycle and reconciliation layer needed to support formal prospect-to-registered conversion without losing quote history.

## Next recommended hardening step

The next engineering step is to make costing and tariff resolution explicitly consult customer mapping so that quote-time pricing path selection is derived from customer status instead of only from the incoming `clientId` value.
