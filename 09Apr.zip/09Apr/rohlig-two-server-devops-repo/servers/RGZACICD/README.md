# RGZACICD

This folder contains scripts and environment templates for the CI/CD server.

## Server details

- Hostname: `RGZACICD`
- IP: `172.84.39.88`
- SSH User: `RTITDrrev`

## Use this order

```bash
cd servers/RGZACICD/scripts
./00-precheck.sh
./01-bootstrap-cicd.sh
./02-create-ssh-key.sh
# optionally
./04-install-jenkins-optional.sh
./05-status-cicd.sh
```

## Bitbucket runner

Copy `pipelines/bitbucket-pipelines.yml` to your application repo and register a Linux Docker runner in Bitbucket. Then use the runner labels configured in `servers/RGZACICD/env/cicd.env`.
