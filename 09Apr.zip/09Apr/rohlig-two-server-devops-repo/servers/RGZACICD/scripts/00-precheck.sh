#!/usr/bin/env bash
set -euo pipefail

echo "=== RGZACICD PRECHECK ==="
echo "User: $(whoami)"
echo "Host: $(hostname)"
echo "Date: $(date)"
echo

echo "--- System ---"
uname -a
lsb_release -a || cat /etc/os-release
echo

echo "--- CPU / Memory / Disk ---"
nproc || true
free -h
df -h
echo

echo "--- Network ---"
ip -brief a || true
echo

echo "--- Packages / Tools ---"
for cmd in ssh scp git curl jq tar docker; do
  if command -v "$cmd" >/dev/null 2>&1; then
    echo "[OK] $cmd -> $(command -v "$cmd")"
  else
    echo "[WARN] Missing: $cmd"
  fi
done
echo

echo "--- Docker ---"
docker --version || true
docker compose version || true
sudo systemctl status docker --no-pager || true
echo

echo "--- Connectivity to app server ---"
ping -c 2 172.38.89.25 || true
echo

echo "Precheck complete."
