#!/usr/bin/env bash
set -euo pipefail

echo "=== RGZACICD STATUS ==="
hostname
uptime
echo

echo "--- Docker ---"
docker --version
docker compose version
docker ps
echo

echo "--- Disk ---"
df -h
echo

echo "--- Key paths ---"
ls -lah "${HOME}/.ssh" || true
ls -lah /opt/rohlig-ci || true
ls -lah /opt/rohlig-ci/releases || true
echo

echo "--- App server reachability ---"
ssh -o BatchMode=yes -o ConnectTimeout=5 RTRITDev@172.38.89.25 "hostname && uptime" || \
  echo "[WARN] SSH key auth to app server is not yet working"
