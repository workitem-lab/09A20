#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 4 ]]; then
  echo "Usage: $0 <runner-uuid> <oauth-client-id> <oauth-client-secret> <workspace>"
  echo "Example:"
  echo "  $0 '{runner_uuid}' 'client_id' 'client_secret' 'my-workspace'"
  exit 1
fi

RUNNER_UUID="$1"
OAUTH_CLIENT_ID="$2"
OAUTH_CLIENT_SECRET="$3"
WORKSPACE="$4"

RUNNER_DIR="/opt/rohlig-ci/bitbucket-runner"
mkdir -p "${RUNNER_DIR}"
cd "${RUNNER_DIR}"

docker rm -f rohlig-bitbucket-runner >/dev/null 2>&1 || true

docker container run -itd \
  --name rohlig-bitbucket-runner \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v "${RUNNER_DIR}:/tmp" \
  -e ACCOUNT_UUID="${WORKSPACE}" \
  -e RUNNER_UUID="${RUNNER_UUID}" \
  -e OAUTH_CLIENT_ID="${OAUTH_CLIENT_ID}" \
  -e OAUTH_CLIENT_SECRET="${OAUTH_CLIENT_SECRET}" \
  docker-public.packages.atlassian.com/sox/atlassian/bitbucket-pipelines-runner:1

echo "Runner started."
docker ps --filter "name=rohlig-bitbucket-runner"
echo "Use 'docker logs -f rohlig-bitbucket-runner' to follow logs."
