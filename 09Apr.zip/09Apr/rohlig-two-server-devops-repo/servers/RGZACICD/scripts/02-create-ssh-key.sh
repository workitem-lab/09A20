#!/usr/bin/env bash
set -euo pipefail

KEY_PATH="${HOME}/.ssh/id_ed25519"

mkdir -p "${HOME}/.ssh"
chmod 700 "${HOME}/.ssh"

if [[ -f "${KEY_PATH}" ]]; then
  echo "SSH key already exists at ${KEY_PATH}"
else
  ssh-keygen -t ed25519 -C "rohlig-cicd@RGZACICD" -f "${KEY_PATH}" -N ""
fi

chmod 600 "${KEY_PATH}"
chmod 644 "${KEY_PATH}.pub"

echo
echo "Public key:"
cat "${KEY_PATH}.pub"
echo
echo "Next step:"
echo "ssh-copy-id RTRITDev@172.38.89.25"
echo "Then test:"
echo "ssh RTRITDev@172.38.89.25 'hostname && whoami'"
