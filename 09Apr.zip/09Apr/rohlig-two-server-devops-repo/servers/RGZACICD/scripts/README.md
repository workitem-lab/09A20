# CI/CD Scripts

## 00-precheck.sh
Validates OS, Docker, network reachability, and required tools.

## 01-bootstrap-cicd.sh
Installs core packages and Docker if needed. Creates `/opt/rohlig-ci`.

## 02-create-ssh-key.sh
Creates an SSH key for deployment from CI/CD to app server.

## 03-start-bitbucket-runner.sh
Starts a Bitbucket self-hosted Linux Docker runner container. You must first create the runner in Bitbucket and supply the registration values.

## 04-install-jenkins-optional.sh
Installs Jenkins LTS and prints the initial admin password.

## 05-status-cicd.sh
Shows current CI/CD server status.
