#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="/opt/rohlig"
BACKUP_DIR="${ROOT_DIR}/shared/backups"
STAMP="$(date +%F_%H%M%S)"
TARGET="${BACKUP_DIR}/rohlig_release_backup_${STAMP}.tar.gz"

mkdir -p "${BACKUP_DIR}"

tar -C "${ROOT_DIR}" -czf "${TARGET}" releases current compose shared/env || true

echo "Backup created:"
ls -lh "${TARGET}"
