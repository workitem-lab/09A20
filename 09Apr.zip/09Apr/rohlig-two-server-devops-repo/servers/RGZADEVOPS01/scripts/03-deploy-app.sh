#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /opt/rohlig/releases/<release-id>"
  exit 1
fi

RELEASE_DIR="$1"
ROOT_DIR="/opt/rohlig"
CURRENT_LINK="${ROOT_DIR}/current"
COMPOSE_FILE="${RELEASE_DIR}/compose/docker-compose.app.yml"
MONITORING_FILE="${RELEASE_DIR}/compose/docker-compose.monitoring.yml"

if [[ ! -d "${RELEASE_DIR}" ]]; then
  echo "Release directory not found: ${RELEASE_DIR}"
  exit 1
fi

if [[ ! -f "${COMPOSE_FILE}" ]]; then
  echo "Compose file not found: ${COMPOSE_FILE}"
  exit 1
fi

echo "Deploying release: ${RELEASE_DIR}"

ln -sfn "${RELEASE_DIR}" "${CURRENT_LINK}"

cd "${RELEASE_DIR}/compose"
docker compose -f docker-compose.app.yml up -d --remove-orphans

if [[ -f "${MONITORING_FILE}" ]]; then
  docker compose -f docker-compose.monitoring.yml up -d --remove-orphans || true
fi

echo "Waiting for services..."
sleep 10

docker compose -f docker-compose.app.yml ps

echo "Health checks..."
curl -fsS http://localhost/ >/dev/null || echo "[WARN] Root endpoint did not return success"
curl -fsS http://localhost:8080/actuator/health || echo "[WARN] Backend health endpoint not yet healthy"

echo
echo "Current release:"
readlink -f "${CURRENT_LINK}"
