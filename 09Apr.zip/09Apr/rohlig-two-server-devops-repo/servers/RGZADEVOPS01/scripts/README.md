# App Server Scripts

## 00-precheck.sh
Checks OS, ports, Docker, and system state.

## 01-bootstrap-app.sh
Installs base packages and Docker if needed.

## 02-create-app-layout.sh
Creates `/opt/rohlig` release layout.

## 03-deploy-app.sh
Promotes a prepared release directory and starts containers.

## 04-status-app.sh
Shows Docker, ports, current release, and basic HTTP status.

## 05-rollback-app.sh
Reverts `current` to the previous release and restarts the stack.

## 06-backup-release.sh
Creates a tarball backup of release state and shared env files.

## 07-run-smoke-tests.sh
Performs quick service validation after deployment.
