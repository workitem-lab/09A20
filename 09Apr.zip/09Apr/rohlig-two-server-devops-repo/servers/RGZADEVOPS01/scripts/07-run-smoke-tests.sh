#!/usr/bin/env bash
set -euo pipefail

echo "=== SMOKE TESTS ==="

echo "[1] Root page"
curl -I http://localhost

echo
echo "[2] Backend health"
curl -fsS http://localhost:8080/actuator/health

echo
echo "[3] Container list"
docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'

echo
echo "[4] Open ports"
sudo ss -tulpn | grep -E ':80|:443|:8080|:9090|:3000|:9092' || true

echo
echo "Smoke tests completed."
