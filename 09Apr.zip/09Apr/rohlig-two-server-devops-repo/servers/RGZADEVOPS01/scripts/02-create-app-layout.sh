#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="/opt/rohlig"

sudo mkdir -p "${ROOT_DIR}"/{releases,shared/env,shared/logs,shared/backups,compose}
sudo chown -R "$USER:$USER" "${ROOT_DIR}"

chmod 750 "${ROOT_DIR}" || true
chmod 750 "${ROOT_DIR}/shared" || true

echo "Created layout:"
tree -L 2 "${ROOT_DIR}" || find "${ROOT_DIR}" -maxdepth 2 -type d | sort
