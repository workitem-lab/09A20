#!/usr/bin/env bash
set -euo pipefail

echo "=== RGZADEVOPS01 PRECHECK ==="
echo "User: $(whoami)"
echo "Host: $(hostname)"
echo "Date: $(date)"
echo

uname -a
lsb_release -a || cat /etc/os-release
echo

free -h
df -h
echo

ip -brief a || true
echo

for cmd in docker curl tar jq ss; do
  if command -v "$cmd" >/dev/null 2>&1; then
    echo "[OK] $cmd -> $(command -v "$cmd")"
  else
    echo "[WARN] Missing: $cmd"
  fi
done
echo

docker --version || true
docker compose version || true
sudo systemctl status docker --no-pager || true
echo

sudo ss -tulpn | grep -E ':22|:80|:443|:8080|:9090|:3000|:9092' || true
