#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="/opt/rohlig"

echo "=== APP SERVER STATUS ==="
hostname
uptime
echo

echo "--- Docker ---"
docker --version
docker compose version
docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}'
echo

echo "--- Release structure ---"
ls -lah "${ROOT_DIR}" || true
ls -lah "${ROOT_DIR}/releases" || true
readlink -f "${ROOT_DIR}/current" || true
echo

echo "--- Ports ---"
sudo ss -tulpn | grep -E ':80|:443|:8080|:9090|:3000|:9092' || true
echo

echo "--- HTTP checks ---"
curl -I http://localhost || true
curl -fsS http://localhost:8080/actuator/health || true
