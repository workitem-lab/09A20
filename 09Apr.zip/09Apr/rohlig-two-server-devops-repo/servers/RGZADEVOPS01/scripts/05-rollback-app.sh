#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="/opt/rohlig"
RELEASES_DIR="${ROOT_DIR}/releases"
CURRENT_LINK="${ROOT_DIR}/current"

mapfile -t releases < <(find "${RELEASES_DIR}" -mindepth 1 -maxdepth 1 -type d | sort)
count="${#releases[@]}"

if (( count < 2 )); then
  echo "Need at least two releases to roll back."
  exit 1
fi

current_target="$(readlink -f "${CURRENT_LINK}" || true)"
previous_release=""

for (( i=count-1; i>=0; i-- )); do
  if [[ "${releases[$i]}" != "${current_target}" ]]; then
    previous_release="${releases[$i]}"
    break
  fi
done

if [[ -z "${previous_release}" ]]; then
  echo "Could not determine previous release."
  exit 1
fi

echo "Rolling back from:"
echo "  current : ${current_target}"
echo "  previous: ${previous_release}"

ln -sfn "${previous_release}" "${CURRENT_LINK}"

cd "${previous_release}/compose"
docker compose -f docker-compose.app.yml up -d --remove-orphans

echo "Rollback complete."
readlink -f "${CURRENT_LINK}"
docker compose -f docker-compose.app.yml ps
