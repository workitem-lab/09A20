# RGZADEVOPS01

This folder contains the runtime-side scripts, Docker Compose templates, smoke tests, and rollback helpers for the Röhlig app server.

## Server details

- Hostname: `RGZADEVOPS01`
- IP: `172.38.89.25`
- SSH User: `RTRITDev`

## Use this order

```bash
cd servers/RGZADEVOPS01/scripts
./00-precheck.sh
./01-bootstrap-app.sh
./02-create-app-layout.sh
./04-status-app.sh
```

Deploy a release:

```bash
./03-deploy-app.sh /opt/rohlig/releases/<release-id>
```

Rollback:

```bash
./05-rollback-app.sh
```

Smoke tests:

```bash
./07-run-smoke-tests.sh
```
