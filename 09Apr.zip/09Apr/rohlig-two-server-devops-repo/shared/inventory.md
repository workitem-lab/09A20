# Röhlig Server Inventory

## CI/CD Server
- Role: CI/CD, source checkout, build, release packaging, optional Bitbucket runner, optional Jenkins
- Hostname: `RGZACICD`
- IP: `172.84.39.88`
- SSH User: `RTITDrrev`
- OS: Ubuntu Server 22.04.4 LTS
- RAM: 24 GB
- Disk: 500 GB

## Application Server
- Role: Spring Boot backend, Angular frontend, Kafka, reverse proxy, monitoring
- Hostname: `RGZADEVOPS01`
- IP: `172.38.89.25`
- SSH User: `RTRITDev`
- OS: Ubuntu Server 22.04.4 LTS
- RAM: 24 GB
- Disk: 2 TB

## Security Note
Do **not** commit or store login passwords in this repository. Use:
- the initial password only for the first login
- then SSH keys for all ongoing administration
- Bitbucket repository variables or deployment variables for secrets
