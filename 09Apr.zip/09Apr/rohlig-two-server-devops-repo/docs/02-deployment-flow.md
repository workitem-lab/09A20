# Deployment Flow

## 1. Source to release

The deployment flow is:

1. code is committed to Bitbucket
2. pipeline or Jenkins checks out the repo
3. backend is built with Maven
4. frontend is built with Node and Angular
5. Docker images are built or release assets are assembled
6. release files are copied to the app server
7. app server deploy script updates the current release
8. smoke tests verify success

## 2. Suggested artifact layout

Inside a release folder on the app server:

```text
release/
├── backend/
│   └── app.jar
├── frontend/
│   └── dist/
├── compose/
│   ├── docker-compose.app.yml
│   ├── docker-compose.monitoring.yml
│   └── .env
└── VERSION
```

## 3. Manual deployment from CI/CD server

Example manual flow from the CI/CD server:

```bash
export RELEASE_ID=$(date +%F_%H%M%S)
mkdir -p /tmp/releases/${RELEASE_ID}

# example copy into release staging area
cp -r /path/to/backend/target/app.jar /tmp/releases/${RELEASE_ID}/backend/
cp -r /path/to/frontend/dist /tmp/releases/${RELEASE_ID}/frontend/
cp -r /path/to/compose /tmp/releases/${RELEASE_ID}/compose/

tar -C /tmp/releases -czf /tmp/${RELEASE_ID}.tar.gz ${RELEASE_ID}

scp /tmp/${RELEASE_ID}.tar.gz RTRITDev@172.38.89.25:/tmp/
ssh RTRITDev@172.38.89.25 "mkdir -p /opt/rohlig/releases/${RELEASE_ID} && tar -xzf /tmp/${RELEASE_ID}.tar.gz -C /opt/rohlig/releases && sudo chown -R $USER:$USER /opt/rohlig/releases/${RELEASE_ID}"
ssh RTRITDev@172.38.89.25 "/opt/rohlig/releases/${RELEASE_ID}/../current"
```

The final step above is intentionally incomplete as a reminder: use the provided deploy script instead of a raw symlink switch.

## 4. Recommended deployment command

On the app server:

```bash
cd /tmp/rohlig-two-server-devops-repo/servers/RGZADEVOPS01/scripts
./03-deploy-app.sh /opt/rohlig/releases/<release-id>
```

## 5. Smoke test path

Run after every deployment:

```bash
./07-run-smoke-tests.sh
```

## 6. Rollback

If the new release fails:

```bash
./05-rollback-app.sh
```


## 7. Compose compatibility note
The compose files intentionally omit the old top-level `version` key to avoid the warning shown by modern `docker compose`.
