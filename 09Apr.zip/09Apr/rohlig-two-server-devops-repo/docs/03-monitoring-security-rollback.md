# Monitoring, Security, and Rollback

## Monitoring

### Basic operational checks

On the app server:

```bash
docker ps
docker compose -f /opt/rohlig/current/compose/docker-compose.app.yml ps
docker logs --tail 200 rohlig-backend
docker logs --tail 200 rohlig-nginx
curl -fsS http://localhost/ || true
curl -fsS http://localhost:8080/actuator/health || true
```

### Prometheus and Grafana

Use:

```bash
cd /opt/rohlig/current/compose
docker compose -f docker-compose.monitoring.yml up -d
```

Access:
- Prometheus: `http://<app-server>:9090`
- Grafana: `http://<app-server>:3000`

## Security

### Required security baseline

- move from password login to SSH keys
- restrict SSH with firewall rules if available
- use least privilege users
- keep secrets out of Git
- run only required ports
- store env files with strict permissions
- keep regular backups of release assets and database data
- keep Docker images patched

### File permissions

```bash
sudo chmod 750 /opt/rohlig
sudo chmod 750 /opt/rohlig/shared
sudo chmod 640 /opt/rohlig/shared/env/*
```

### Optional UFW baseline

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 8080/tcp
sudo ufw allow 9090/tcp
sudo ufw allow 3000/tcp
sudo ufw enable
sudo ufw status numbered
```

Only open the ports you really need.

## Rollback

### Check releases

```bash
ls -1 /opt/rohlig/releases
readlink -f /opt/rohlig/current
```

### Roll back to previous release

```bash
cd /tmp/rohlig-two-server-devops-repo/servers/RGZADEVOPS01/scripts
./05-rollback-app.sh
```

### Rollback principle

The rollback script:
1. finds the current target
2. finds the previous release
3. repoints `/opt/rohlig/current`
4. restarts the compose stack
5. verifies the services

## Backup

You can run:

```bash
./06-backup-release.sh
```
