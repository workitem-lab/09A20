# Copy-Paste Command Sequence

## From your laptop to CI/CD server

```bash
ssh RTITDrrev@172.84.39.88
```

## On CI/CD server

```bash
cd /tmp
# place this repo here if it is not already present
cd rohlig-two-server-devops-repo/servers/RGZACICD/scripts
chmod +x *.sh
./00-precheck.sh
./01-bootstrap-cicd.sh
./02-create-ssh-key.sh
ssh-copy-id RTRITDev@172.38.89.25
ssh RTRITDev@172.38.89.25 "hostname && whoami && docker --version && docker compose version"
```

## On app server

```bash
ssh RTRITDev@172.38.89.25
cd /tmp
# place this repo here if it is not already present
cd rohlig-two-server-devops-repo/servers/RGZADEVOPS01/scripts
chmod +x *.sh
./00-precheck.sh
./01-bootstrap-app.sh
./02-create-app-layout.sh
./04-status-app.sh
```

## Manual deployment example from CI/CD server

```bash
export RELEASE_ID=$(date +%F_%H%M%S)
mkdir -p /opt/rohlig-ci/releases/${RELEASE_ID}/{backend,frontend,compose/nginx,compose/prometheus}

# copy your real build outputs into the release folder
cp /path/to/backend/target/*.jar /opt/rohlig-ci/releases/${RELEASE_ID}/backend/app.jar
cp -r /path/to/frontend/dist /opt/rohlig-ci/releases/${RELEASE_ID}/frontend/
cp /tmp/rohlig-two-server-devops-repo/servers/RGZADEVOPS01/compose/docker-compose.app.yml /opt/rohlig-ci/releases/${RELEASE_ID}/compose/
cp /tmp/rohlig-two-server-devops-repo/servers/RGZADEVOPS01/compose/docker-compose.monitoring.yml /opt/rohlig-ci/releases/${RELEASE_ID}/compose/
cp /tmp/rohlig-two-server-devops-repo/servers/RGZADEVOPS01/compose/nginx/default.conf /opt/rohlig-ci/releases/${RELEASE_ID}/compose/nginx/
cp /tmp/rohlig-two-server-devops-repo/servers/RGZADEVOPS01/compose/prometheus/prometheus.yml /opt/rohlig-ci/releases/${RELEASE_ID}/compose/prometheus/
cp /tmp/rohlig-two-server-devops-repo/servers/RGZADEVOPS01/compose/.env.example /opt/rohlig-ci/releases/${RELEASE_ID}/compose/.env

tar -C /opt/rohlig-ci/releases -czf /opt/rohlig-ci/releases/${RELEASE_ID}.tar.gz ${RELEASE_ID}
scp /opt/rohlig-ci/releases/${RELEASE_ID}.tar.gz RTRITDev@172.38.89.25:/tmp/
ssh RTRITDev@172.38.89.25 "mkdir -p /opt/rohlig/releases && tar -xzf /tmp/${RELEASE_ID}.tar.gz -C /opt/rohlig/releases"
ssh RTRITDev@172.38.89.25 "/tmp/rohlig-two-server-devops-repo/servers/RGZADEVOPS01/scripts/03-deploy-app.sh /opt/rohlig/releases/${RELEASE_ID}"
```
