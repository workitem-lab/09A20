# Architecture

## 1. Logical architecture

The solution uses two Ubuntu servers.

```text
Developer -> Bitbucket -> RGZACICD -> SSH -> RGZADEVOPS01 -> Docker Compose -> Users
                                      \
                                       -> Optional Jenkins
```

## 2. Role split

### RGZACICD
This server handles the software delivery flow:
- Git checkout
- build
- test
- package
- release transfer
- deployment trigger

### RGZADEVOPS01
This server handles runtime:
- reverse proxy
- frontend
- backend
- Kafka
- monitoring
- persistent release folders

## 3. Runtime stack on app server

Containers expected:
- `rohlig-nginx`
- `rohlig-frontend`
- `rohlig-backend`
- `rohlig-kafka`
- `rohlig-zookeeper` or equivalent dependency
- `rohlig-prometheus` optional
- `rohlig-grafana` optional

## 4. Release layout

The app server uses versioned releases:

```text
/opt/rohlig/
├── current -> /opt/rohlig/releases/2026-04-09_001
├── releases/
│   ├── 2026-04-09_001/
│   ├── 2026-04-09_002/
│   └── ...
├── shared/
│   ├── logs/
│   ├── backups/
│   └── env/
└── compose/
```

This gives you:
- repeatable deployments
- easy rollback
- separation of releases from shared state

## 5. Network ports

Recommended ports:
- `22` SSH
- `80` HTTP
- `443` HTTPS if TLS is added
- `8080` Spring Boot internal
- `4200` Angular internal if not proxied
- `9092` Kafka internal
- `9090` Prometheus optional
- `3000` Grafana optional
- `7990` Bitbucket optional if self-hosted elsewhere
- `8080` Jenkins optional on CI/CD server

## 6. Deployment model

1. Build on RGZACICD
2. Create release package
3. Copy release package to RGZADEVOPS01
4. Expand to a versioned release folder
5. Point `/opt/rohlig/current` to the new release
6. Start or update containers with `docker compose`
7. Run smoke tests
8. Roll back if needed
