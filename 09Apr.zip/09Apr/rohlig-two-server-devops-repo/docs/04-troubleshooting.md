# Troubleshooting

## 1. SSH problems

### Cannot connect
Check:

```bash
ping 172.84.39.88
ping 172.38.89.25
ssh -vvv RTITDrrev@172.84.39.88
ssh -vvv RTRITDev@172.38.89.25
```

### SSH key not working
From CI/CD server:

```bash
ls -lah ~/.ssh
ssh-copy-id RTRITDev@172.38.89.25
ssh RTRITDev@172.38.89.25 "echo ok"
```

## 2. Docker issues

```bash
docker --version
docker compose version
sudo systemctl status docker
sudo journalctl -u docker -n 200 --no-pager
```

## 3. Port already in use

```bash
sudo ss -tulpn | grep -E ':80|:443|:8080|:9090|:3000|:9092'
```

## 4. Container crash loop

```bash
docker ps -a
docker logs rohlig-backend --tail 200
docker logs rohlig-frontend --tail 200
docker logs rohlig-nginx --tail 200
```

## 5. Spring Boot health endpoint failing

```bash
curl -v http://localhost:8080/actuator/health
docker logs rohlig-backend --tail 300
```

## 6. NGINX bad gateway

```bash
docker exec -it rohlig-nginx nginx -t
docker logs rohlig-nginx --tail 200
curl -v http://rohlig-backend:8080/actuator/health
```

## 7. Kafka not reachable

```bash
docker logs rohlig-kafka --tail 200
docker exec -it rohlig-kafka bash
```

## 8. Rollback validation

```bash
readlink -f /opt/rohlig/current
docker compose -f /opt/rohlig/current/compose/docker-compose.app.yml ps
curl -I http://localhost
curl -fsS http://localhost:8080/actuator/health
```
