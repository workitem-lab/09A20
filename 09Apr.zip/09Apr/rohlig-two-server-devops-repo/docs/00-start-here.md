# Start Here

This document is the operator's entry point for the full two-server Röhlig setup.

## 1. Goal

You will end up with:

- a CI/CD server that can build and package the application
- an app server that runs Spring Boot, Angular, Kafka, and monitoring in Docker Compose
- SSH trust between the CI/CD server and the app server
- a repeatable deployment path
- rollback and smoke test commands

## 2. Server roles

### CI/CD server
- Hostname: `RGZACICD`
- Address: `172.84.39.88`
- User: `RTITDrrev`

Use this machine for:
- Git clone
- Maven/Node builds
- release packaging
- Bitbucket self-hosted runner
- optional Jenkins

### Application server
- Hostname: `RGZADEVOPS01`
- Address: `172.38.89.25`
- User: `RTRITDev`

Use this machine for:
- release storage
- Docker Compose runtime
- NGINX reverse proxy
- Spring Boot service
- Angular frontend
- Kafka and Zookeeper or KRaft, depending on your image selection
- Prometheus and Grafana if enabled

## 3. What you need before you start

From your laptop you need:

- SSH access to both servers
- Git installed locally
- the ability to copy this repo to the CI/CD server or clone it there
- a Bitbucket repo for your code
- your application artifacts or application source

## 4. First login

Use the initial server password only for the first connection, then switch to SSH keys.

```bash
ssh RTITDrrev@172.84.39.88
ssh RTRITDev@172.38.89.25
```

After login on each host:

```bash
hostnamectl
whoami
pwd
ip a
sudo -v
```

## 5. Order of execution

### On the CI/CD server
Run:

```bash
cd /tmp
git clone <your-repo-or-copy-this-folder> rohlig-two-server-devops-repo
cd rohlig-two-server-devops-repo/servers/RGZACICD/scripts

./00-precheck.sh
./01-bootstrap-cicd.sh
./02-create-ssh-key.sh
```

### From the CI/CD server to the app server
Copy the SSH key:

```bash
ssh-copy-id RTRITDev@172.38.89.25
```

Test:

```bash
ssh RTRITDev@172.38.89.25 "hostname && whoami && uptime"
```

### On the app server
Run:

```bash
cd /tmp
# copy this repo or clone it
cd rohlig-two-server-devops-repo/servers/RGZADEVOPS01/scripts

./00-precheck.sh
./01-bootstrap-app.sh
./02-create-app-layout.sh
```

## 6. Environment files you must update

- `servers/RGZACICD/env/cicd.env.example`
- `servers/RGZADEVOPS01/env/app.env.example`
- `servers/RGZADEVOPS01/compose/.env.example`

Copy them before use:

```bash
cp servers/RGZACICD/env/cicd.env.example servers/RGZACICD/env/cicd.env
cp servers/RGZADEVOPS01/env/app.env.example servers/RGZADEVOPS01/env/app.env
cp servers/RGZADEVOPS01/compose/.env.example servers/RGZADEVOPS01/compose/.env
```

## 7. Minimum operational checks

From the CI/CD server:

```bash
ssh RTRITDev@172.38.89.25 "docker ps"
ssh RTRITDev@172.38.89.25 "docker compose version"
ssh RTRITDev@172.38.89.25 "sudo test -d /opt/rohlig/releases && echo OK"
```

From the app server:

```bash
curl -I http://localhost
curl -I http://localhost:8080/actuator/health || true
docker ps
docker compose ls
```

## 8. When you are ready to deploy

Use either:
- Bitbucket runner and `pipelines/bitbucket-pipelines.yml`
- optional Jenkins and `pipelines/Jenkinsfile`

Then use the deploy script:

```bash
servers/RGZADEVOPS01/scripts/03-deploy-app.sh /opt/rohlig/releases/<release-folder>
```
