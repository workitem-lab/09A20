# Röhlig Two-Server DevOps Repo

This repo is a runnable operations kit for a two-server Röhlig deployment on Ubuntu using SSH, Docker Compose, Bitbucket, Spring Boot, Angular, Kafka, and optional Jenkins.

It is designed for this server pair:

- **RGZACICD** — CI/CD server — `RTITDrrev@172.84.39.88`
- **RGZADEVOPS01** — App server — `RTRITDev@172.38.89.25`

Passwords are intentionally **not** stored in the repo.

---

## What this repo gives you

- step-by-step Markdown docs
- per-server shell scripts
- SSH setup flow
- server health checks
- app release folder structure
- Docker Compose templates
- NGINX reverse proxy config
- Prometheus monitoring config
- Bitbucket Pipelines template
- optional Jenkinsfile
- smoke tests
- rollback script

---

## Recommended execution order

1. Read `docs/00-start-here.md`
2. Run the CI/CD server scripts in `servers/RGZACICD/scripts`
3. Run the app server scripts in `servers/RGZADEVOPS01/scripts`
4. Adjust the environment files in each `env/` folder
5. Add your app artifacts or repo linkage
6. Configure Bitbucket runner or Jenkins
7. Run a deployment
8. Run the smoke tests

---

## Repo structure

```text
rohlig-two-server-devops-repo/
├── README.md
├── docs/
├── pipelines/
├── servers/
│   ├── RGZACICD/
│   │   ├── README.md
│   │   ├── env/
│   │   └── scripts/
│   └── RGZADEVOPS01/
│       ├── README.md
│       ├── compose/
│       ├── env/
│       └── scripts/
└── shared/
```

---

## Fast start

From your laptop:

```bash
cd rohlig-two-server-devops-repo

# Read the main guide
less docs/00-start-here.md

# Make scripts executable if needed
find . -type f -name "*.sh" -exec chmod +x {} \;

# Connect to CI/CD server
ssh RTITDrrev@172.84.39.88

# Connect to app server
ssh RTRITDev@172.38.89.25
```

---

## Safety rules

- Do not paste passwords into scripts.
- Do not hardcode secrets in `docker-compose` files.
- Use SSH keys after first access.
- Put production secrets in Bitbucket secured variables or a protected `.env` file on the server.
- Review every `.example` file before use.

---

## Main documents

- `docs/00-start-here.md`
- `docs/01-architecture.md`
- `docs/02-deployment-flow.md`
- `docs/03-monitoring-security-rollback.md`
- `docs/04-troubleshooting.md`

---

## Quick commands

Check both servers manually:

```bash
ssh RTITDrrev@172.84.39.88 "hostname && uptime && docker --version && docker compose version"
ssh RTRITDev@172.38.89.25 "hostname && uptime && docker --version && docker compose version"
```

Check app release directories:

```bash
ssh RTRITDev@172.38.89.25 "sudo ls -lah /opt/rohlig && sudo ls -lah /opt/rohlig/releases"
```

Check running containers:

```bash
ssh RTRITDev@172.38.89.25 "docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}'"
```


## Compose note
The Docker Compose files use the modern plugin format and intentionally omit the obsolete top-level `version` field.
