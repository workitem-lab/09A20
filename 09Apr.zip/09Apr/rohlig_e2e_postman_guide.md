# Röhlig Easy Estimate Backend — End-to-End Postman Pack Guide
This pack contains **134 Postman requests** with **381 automated Postman assertions/tests**.
It is designed for the production-hardened Röhlig Easy Estimate backend running locally through the gateway.
## Files included
- `rohlig_e2e_security_250plus.postman_collection.json` — main Postman collection
- `rohlig_e2e_security_local.postman_environment.json` — local Postman environment
- `rate-import-valid.csv` — sample valid CSV upload file
- `rate-import-invalid.csv` — sample invalid CSV with row-level errors
- `not-csv.txt` — sample wrong-extension upload file

## What this pack covers
- Keycloak token retrieval for local test users
- public health endpoints
- gateway and service auth introspection
- shipment create/read/search/idempotency tests
- cost recalculation/read/search/idempotency tests
- quotation projection, generation, CSV/PDF download, invoice alias tests
- rate repository access and filter tests
- rates importer batch, upload, error, and permission tests
- validation negatives and security role checks
- pagination and response sanity checks

## Important honesty notes
- Some negative tests intentionally allow more than one expected status, such as `400/500` or `404/500`. Those cases are not there to hide bugs. They are there because some endpoints still expose framework/default error behavior rather than a fully normalized error contract.
- The collection assumes the Docker stack is reachable at `http://localhost:8080` and Keycloak at `http://localhost:8090`.
- Token requests using the realm frontend client require **Direct Access Grants** to be enabled for `easy-estimate-frontend`, and the local test users must already exist.
- The internal tariff endpoint is not part of the normal gateway-exposed external test flow, so it is not included in the default end-to-end pack.

## Recommended execution order
1. Start the backend and confirm the gateway and Keycloak are healthy.
2. Run folder `00 Setup & Tokens`.
3. Run `01 Public Health` and `02 Auth Introspection`.
4. Run the business flow in order: `03 Shipment End-to-End` → `05 Costing End-to-End` → `07 Quotation End-to-End`.
5. Run the negative/security folders.
6. Run the importer folders after you confirm the file paths are correct in Postman.

## Local prerequisites
Use the local environment from the sign-off checklist. At minimum you need:
```bash
docker compose up -d
curl -fsS http://localhost:8080/actuator/health | jq .
curl -fsS http://localhost:8090/health/ready
```
### Optional Newman run
```bash
newman run rohlig_e2e_security_250plus.postman_collection.json -e rohlig_e2e_security_local.postman_environment.json
```
For file upload requests in Newman, keep the CSV and TXT sample files in the same folder as the collection and environment, or update the file path variables in the environment.

## Role model used in the pack
| Role | Main expected abilities |
|---|---|
| ADMIN | full read/write across platform routes |
| OPERATIONS_USER | create shipments, read shipments/costs, recalculate costs |
| QUOTATION_USER | read shipments/costs, recalculate costs, read/generate/download quotations |
| RATES_ADMIN | full rates importer access and rate repository reads |
| VIEW_ONLY | read shipments, costs, quotations, invoices, rate repository, and importer template/list routes |

## Endpoint catalog
| Method | Endpoint | Covered by scenarios | Expected result range | Roles used |
|---|---|---:|---|---|
| `GET` | `{{baseUrl}}/api/v1/shipments/{{shipmentIdAir}}` | 1 | 200 | VIEW_ONLY/OPERATIONS_USER |
| `GET` | `{{baseUrl}}/api/v1/shipments/{{shipmentIdLcl}}` | 1 | 200 | VIEW_ONLY/OPERATIONS_USER |
| `GET` | `{{baseUrl}}/actuator/health` | 1 | 200 | public |
| `GET` | `{{baseUrl}}/api/v1/auth/me` | 5 | 200, 401 | ADMIN, OPERATIONS_USER, invalid token, none |
| `GET` | `{{baseUrl}}/api/v1/costs` | 1 | 200 | VIEW_ONLY |
| `GET` | `{{baseUrl}}/api/v1/costs/auth/me` | 1 | 200 | QUOTATION_USER |
| `GET` | `{{baseUrl}}/api/v1/costs/health` | 1 | 200 | public |
| `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | 15 | 200, 400, 400/500, 401, 403, 409 | ADMIN, OPERATIONS_USER, QUOTATION_USER, VIEW_ONLY, invalid token, none, operationsToken |
| `GET` | `{{baseUrl}}/api/v1/costs/{{missingShipmentId}}` | 1 | 404 | OPERATIONS_USER |
| `GET` | `{{baseUrl}}/api/v1/costs/{{shipmentIdAir}}` | 1 | 200 | viewOnlyToken |
| `GET` | `{{baseUrl}}/api/v1/costs/{{shipmentIdFcl}}` | 1 | 200 | operationsToken |
| `GET` | `{{baseUrl}}/api/v1/costs/{{shipmentIdLcl}}` | 1 | 200 | quotationToken |
| `GET` | `{{baseUrl}}/api/v1/costs?clientId=CLIENT-001` | 1 | 200 | operationsToken |
| `GET` | `{{baseUrl}}/api/v1/costs?modality=FCL` | 1 | 200 | operationsToken |
| `GET` | `{{baseUrl}}/api/v1/costs?page=-5&size=5` | 1 | 200 | operationsToken |
| `GET` | `{{baseUrl}}/api/v1/costs?page=0&size=999` | 1 | 200 | operationsToken |
| `GET` | `{{baseUrl}}/api/v1/invoices` | 2 | 200 | QUOTATION_USER, mixed |
| `GET` | `{{baseUrl}}/api/v1/invoices/{{shipmentIdFcl}}` | 1 | 200/404 | QUOTATION_USER |
| `GET` | `{{baseUrl}}/api/v1/quotations` | 6 | 200, 401, 403 | mixed, quotationToken |
| `GET` | `{{baseUrl}}/api/v1/quotations/auth/me` | 1 | 200 | VIEW_ONLY |
| `GET` | `{{baseUrl}}/api/v1/quotations/health` | 1 | 200 | public |
| `GET` | `{{baseUrl}}/api/v1/quotations/{{missingShipmentId}}/documents/csv` | 1 | 404 | mixed |
| `GET` | `{{baseUrl}}/api/v1/quotations/{{missingShipmentId}}/documents/pdf` | 1 | 404 | mixed |
| `POST` | `{{baseUrl}}/api/v1/quotations/{{missingShipmentId}}/generate` | 1 | 404 | mixed |
| `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdAir}}/documents/csv` | 1 | 200 | ADMIN |
| `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdAir}}/documents/pdf` | 1 | 200 | ADMIN |
| `POST` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdAir}}/generate` | 1 | 200 | ADMIN |
| `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}` | 1 | 200/404 | quotationToken |
| `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}/documents/csv` | 2 | 200 | QUOTATION_USER, quotationToken |
| `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}/documents/pdf` | 2 | 200 | QUOTATION_USER, quotationToken |
| `POST` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}/generate` | 2 | 200, 403 | QUOTATION_USER, mixed |
| `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdLcl}}/documents/csv` | 1 | 200 | VIEW_ONLY |
| `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdLcl}}/documents/pdf` | 1 | 200 | ADMIN |
| `POST` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdLcl}}/generate` | 1 | 200 | QUOTATION_USER |
| `GET` | `{{baseUrl}}/api/v1/quotations?page=-5&size=5` | 1 | 200 | quotationToken |
| `GET` | `{{baseUrl}}/api/v1/quotations?page=0&size=999` | 1 | 200 | quotationToken |
| `GET` | `{{baseUrl}}/api/v1/quotations?status=GENERATED` | 1 | 200 | quotationToken |
| `GET` | `{{baseUrl}}/api/v1/rate-repository/cards` | 5 | 200, 401 | invalid token, none, operationsToken, ratesAdminToken, viewOnlyToken |
| `GET` | `{{baseUrl}}/api/v1/rate-repository/cards?modality=AIR&shipmentType=IMPORT` | 1 | 200 | adminUserToken |
| `GET` | `{{baseUrl}}/api/v1/rate-repository/cards?modality=FCL&shipmentType=IMPORT` | 1 | 200 | quotationToken |
| `GET` | `{{baseUrl}}/api/v1/rate-repository/cards?modality=LCL&shipmentType=IMPORT` | 1 | 200 | quotationToken |
| `GET` | `{{baseUrl}}/api/v1/rate-repository/health` | 2 | 200 | public |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/auth/me` | 1 | 200 | RATES_ADMIN |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/batches` | 4 | 200, 401 | RATES_ADMIN, mixed |
| `POST` | `{{baseUrl}}/api/v1/rates-importer/batches` | 2 | 200, 403 | RATES_ADMIN, mixed |
| `POST` | `{{baseUrl}}/api/v1/rates-importer/batches/upload` | 5 | 200, 400/500, 403 | RATES_ADMIN, mixed |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{invalidUploadBatchReference}}` | 1 | 200 | RATES_ADMIN |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{invalidUploadBatchReference}}/errors` | 1 | 200 | RATES_ADMIN |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{manualBatchReference}}` | 1 | 200 | RATES_ADMIN |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{missingBatchReference}}` | 1 | 404/500 | mixed |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{missingBatchReference}}/errors` | 1 | 200 | mixed |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{validUploadBatchReference}}` | 1 | 200 | RATES_ADMIN |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{validUploadBatchReference}}/errors` | 1 | 200 | RATES_ADMIN |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/health` | 2 | 200 | public |
| `GET` | `{{baseUrl}}/api/v1/rates-importer/template` | 3 | 200, 403 | RATES_ADMIN, VIEW_ONLY, mixed |
| `GET` | `{{baseUrl}}/api/v1/shipments` | 2 | 200 | QUOTATION_USER, VIEW_ONLY |
| `POST` | `{{baseUrl}}/api/v1/shipments` | 16 | 200, 400, 400/500, 401, 403, 409 | ADMIN, OPERATIONS_USER, invalid token, none, operationsToken, quotationToken, viewOnlyToken |
| `GET` | `{{baseUrl}}/api/v1/shipments/auth/me` | 1 | 200 | OPERATIONS_USER |
| `GET` | `{{baseUrl}}/api/v1/shipments/health` | 2 | 200 | public |
| `GET` | `{{baseUrl}}/api/v1/shipments/{{missingShipmentId}}` | 1 | 404 | OPERATIONS_USER |
| `GET` | `{{baseUrl}}/api/v1/shipments/{{shipmentIdFcl}}` | 1 | 200 | OPERATIONS_USER |
| `GET` | `{{baseUrl}}/api/v1/shipments?clientId=CLIENT-001` | 1 | 200 | OPERATIONS_USER |
| `GET` | `{{baseUrl}}/api/v1/shipments?modality=FCL` | 1 | 200 | OPERATIONS_USER |
| `GET` | `{{baseUrl}}/api/v1/shipments?page=-5&size=5` | 1 | 200 | operationsToken |
| `GET` | `{{baseUrl}}/api/v1/shipments?page=0&size=1` | 1 | 200 | OPERATIONS_USER |
| `GET` | `{{baseUrl}}/api/v1/shipments?page=0&size=999` | 1 | 200 | operationsToken |
| `GET` | `{{baseUrl}}/api/v1/tariffs/health` | 1 | 200 | public |
| `GET` | `{{keycloakBaseUrl}}/health/ready` | 1 | 200 | public |
| `POST` | `{{keycloakBaseUrl}}/realms/master/protocol/openid-connect/token` | 1 | 200 | admin-cli |
| `POST` | `{{keycloakBaseUrl}}/realms/{{realm}}/protocol/openid-connect/token` | 5 | 200 | ADMIN, OPERATIONS_USER, QUOTATION_USER, RATES_ADMIN, VIEW_ONLY |

## Detailed request-by-request matrix

### 00 Setup & Tokens
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Keycloak Ready Check | `GET` | `{{keycloakBaseUrl}}/health/ready` | public | 200 | Check Keycloak readiness |
| 2 | Get Keycloak Admin Token | `POST` | `{{keycloakBaseUrl}}/realms/master/protocol/openid-connect/token` | admin-cli | 200 | Get admin token |
| 3 | Get Admin User Token | `POST` | `{{keycloakBaseUrl}}/realms/{{realm}}/protocol/openid-connect/token` | ADMIN | 200 | Get ADMIN token |
| 4 | Get Operations User Token | `POST` | `{{keycloakBaseUrl}}/realms/{{realm}}/protocol/openid-connect/token` | OPERATIONS_USER | 200 | Get OPERATIONS_USER token |
| 5 | Get Quotation User Token | `POST` | `{{keycloakBaseUrl}}/realms/{{realm}}/protocol/openid-connect/token` | QUOTATION_USER | 200 | Get QUOTATION_USER token |
| 6 | Get Rates Admin User Token | `POST` | `{{keycloakBaseUrl}}/realms/{{realm}}/protocol/openid-connect/token` | RATES_ADMIN | 200 | Get RATES_ADMIN token |
| 7 | Get View Only User Token | `POST` | `{{keycloakBaseUrl}}/realms/{{realm}}/protocol/openid-connect/token` | VIEW_ONLY | 200 | Get VIEW_ONLY token |

### 01 Public Health
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Gateway Actuator Health | `GET` | `{{baseUrl}}/actuator/health` | public | 200 | Health check for {{baseUrl}}/actuator/health |
| 2 | Shipment Health via Gateway | `GET` | `{{baseUrl}}/api/v1/shipments/health` | public | 200 | Health check for {{baseUrl}}/api/v1/shipments/health |
| 3 | Tariff Health via Gateway | `GET` | `{{baseUrl}}/api/v1/tariffs/health` | public | 200 | Health check for {{baseUrl}}/api/v1/tariffs/health |
| 4 | Costing Health via Gateway | `GET` | `{{baseUrl}}/api/v1/costs/health` | public | 200 | Health check for {{baseUrl}}/api/v1/costs/health |
| 5 | Quotation Health via Gateway | `GET` | `{{baseUrl}}/api/v1/quotations/health` | public | 200 | Health check for {{baseUrl}}/api/v1/quotations/health |
| 6 | Rate Repository Health via Gateway | `GET` | `{{baseUrl}}/api/v1/rate-repository/health` | public | 200 | Health check for {{baseUrl}}/api/v1/rate-repository/health |
| 7 | Rates Importer Health via Gateway | `GET` | `{{baseUrl}}/api/v1/rates-importer/health` | public | 200 | Health check for {{baseUrl}}/api/v1/rates-importer/health |

### 02 Auth Introspection
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Gateway Auth Me as Admin | `GET` | `{{baseUrl}}/api/v1/auth/me` | ADMIN | 200 | Validate ADMIN token |
| 2 | Gateway Auth Me as Operations | `GET` | `{{baseUrl}}/api/v1/auth/me` | OPERATIONS_USER | 200 | Validate OPERATIONS_USER token |
| 3 | Shipment Auth Me as Operations | `GET` | `{{baseUrl}}/api/v1/shipments/auth/me` | OPERATIONS_USER | 200 | Validate OPERATIONS_USER token |
| 4 | Costing Auth Me as Quotation | `GET` | `{{baseUrl}}/api/v1/costs/auth/me` | QUOTATION_USER | 200 | Validate QUOTATION_USER token |
| 5 | Quotation Auth Me as View Only | `GET` | `{{baseUrl}}/api/v1/quotations/auth/me` | VIEW_ONLY | 200 | Validate VIEW_ONLY token |
| 6 | Rates Importer Auth Me as Rates Admin | `GET` | `{{baseUrl}}/api/v1/rates-importer/auth/me` | RATES_ADMIN | 200 | Validate RATES_ADMIN token |
| 7 | Gateway Auth Me No Token | `GET` | `{{baseUrl}}/api/v1/auth/me` | none | 401 | Reject missing auth token |
| 8 | Gateway Auth Me Invalid Token | `GET` | `{{baseUrl}}/api/v1/auth/me` | invalid token | 401 | Reject invalid auth token |

### 03 Shipment End-to-End
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Create FCL Shipment as Operations | `POST` | `{{baseUrl}}/api/v1/shipments` | OPERATIONS_USER | 200 | Create FCL shipment |
| 2 | Replay FCL Shipment with Same Idempotency Key | `POST` | `{{baseUrl}}/api/v1/shipments` | OPERATIONS_USER | 200 | Replay same shipment request |
| 3 | Get FCL Shipment as Operations | `GET` | `{{baseUrl}}/api/v1/shipments/{{shipmentIdFcl}}` | OPERATIONS_USER | 200 | Fetch the created FCL shipment |
| 4 | Search Shipments by clientId | `GET` | `{{baseUrl}}/api/v1/shipments?clientId=CLIENT-001` | OPERATIONS_USER | 200 | Search shipments by clientId |
| 5 | Search Shipments by modality FCL | `GET` | `{{baseUrl}}/api/v1/shipments?modality=FCL` | OPERATIONS_USER | 200 | Search shipments by modality |
| 6 | Search Shipments page size 1 | `GET` | `{{baseUrl}}/api/v1/shipments?page=0&size=1` | OPERATIONS_USER | 200 | Check pageable shipment search |
| 7 | Create AIR Shipment as Operations | `POST` | `{{baseUrl}}/api/v1/shipments` | OPERATIONS_USER | 200 | Create AIR shipment |
| 8 | Get AIR Shipment | `GET` | `{{baseUrl}}/api/v1/shipments/{{shipmentIdAir}}` | VIEW_ONLY/OPERATIONS_USER | 200 | Read AIR shipment |
| 9 | Create LCL Shipment as Admin | `POST` | `{{baseUrl}}/api/v1/shipments` | ADMIN | 200 | Create LCL shipment |
| 10 | Get LCL Shipment | `GET` | `{{baseUrl}}/api/v1/shipments/{{shipmentIdLcl}}` | VIEW_ONLY/OPERATIONS_USER | 200 | Read LCL shipment |

### 04 Shipment Validation & Security
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Create Shipment No Auth | `POST` | `{{baseUrl}}/api/v1/shipments` | none | 401 | Reject shipment creation without a token |
| 2 | Create Shipment Invalid Token | `POST` | `{{baseUrl}}/api/v1/shipments` | invalid token | 401 | Reject shipment creation with an invalid token |
| 3 | Create Shipment Missing Idempotency Key | `POST` | `{{baseUrl}}/api/v1/shipments` | operationsToken | 400/500 | Reveal missing idempotency-key behavior |
| 4 | Create Shipment Invalid Modality | `POST` | `{{baseUrl}}/api/v1/shipments` | operationsToken | 400 | Reject invalid modality |
| 5 | Create Shipment Invalid Shipment Type | `POST` | `{{baseUrl}}/api/v1/shipments` | operationsToken | 400 | Reject invalid shipment type |
| 6 | Create Shipment Invalid Incoterm | `POST` | `{{baseUrl}}/api/v1/shipments` | operationsToken | 400 | Reject invalid incoterm |
| 7 | Create Shipment Invalid Currency | `POST` | `{{baseUrl}}/api/v1/shipments` | operationsToken | 400 | Reject invalid currency |
| 8 | Create Shipment Missing shipmentId | `POST` | `{{baseUrl}}/api/v1/shipments` | operationsToken | 400 | Reject missing shipmentId |
| 9 | Create Shipment Idempotency Conflict Baseline | `POST` | `{{baseUrl}}/api/v1/shipments` | OPERATIONS_USER | 200 | Seed shipment idempotency conflict |
| 10 | Create Shipment Idempotency Conflict Different Payload | `POST` | `{{baseUrl}}/api/v1/shipments` | OPERATIONS_USER | 409 | Enforce shipment idempotency conflict |
| 11 | Get Missing Shipment | `GET` | `{{baseUrl}}/api/v1/shipments/{{missingShipmentId}}` | OPERATIONS_USER | 404 | Unknown shipment not found |
| 12 | Search Shipments as View Only | `GET` | `{{baseUrl}}/api/v1/shipments` | VIEW_ONLY | 200 | View-only shipment search |
| 13 | Search Shipments as Quotation User | `GET` | `{{baseUrl}}/api/v1/shipments` | QUOTATION_USER | 200 | Quotation-user shipment search |
| 14 | Create Shipment as View Only | `POST` | `{{baseUrl}}/api/v1/shipments` | viewOnlyToken | 403 | VIEW_ONLY must not create shipments |
| 15 | Create Shipment as Quotation User | `POST` | `{{baseUrl}}/api/v1/shipments` | quotationToken | 403 | QUOTATION_USER must not create shipments |

### 05 Costing End-to-End
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Recalculate FCL Cost as Operations | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | OPERATIONS_USER | 200 | Recalculate FCL cost |
| 2 | Recalculate AIR Cost as Quotation | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | QUOTATION_USER | 200 | Recalculate AIR cost |
| 3 | Recalculate LCL Cost as Admin | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | ADMIN | 200 | Recalculate LCL cost |
| 4 | Replay FCL Cost with Same Idempotency Key | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | OPERATIONS_USER | 200 | Replay same cost request |
| 5 | Get FCL Cost as Operations | `GET` | `{{baseUrl}}/api/v1/costs/{{shipmentIdFcl}}` | operationsToken | 200 | Read FCL cost |
| 6 | Get AIR Cost as View Only | `GET` | `{{baseUrl}}/api/v1/costs/{{shipmentIdAir}}` | viewOnlyToken | 200 | VIEW_ONLY can read AIR cost |
| 7 | Get LCL Cost as Quotation User | `GET` | `{{baseUrl}}/api/v1/costs/{{shipmentIdLcl}}` | quotationToken | 200 | QUOTATION_USER can read LCL cost |
| 8 | Search Costs by clientId | `GET` | `{{baseUrl}}/api/v1/costs?clientId=CLIENT-001` | operationsToken | 200 | Search costs by client |
| 9 | Search Costs by modality FCL | `GET` | `{{baseUrl}}/api/v1/costs?modality=FCL` | operationsToken | 200 | Search costs by modality |

### 06 Costing Validation & Security
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Recalculate Cost No Auth | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | none | 401 | Reject cost recalculation without a token |
| 2 | Recalculate Cost Invalid Token | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | invalid token | 401 | Reject cost recalculation with invalid token |
| 3 | Recalculate Cost Missing Idempotency Key | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | operationsToken | 400/500 | Reveal missing cost idempotency behavior |
| 4 | Recalculate Cost Invalid Modality | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | operationsToken | 400 | Reject invalid cost modality |
| 5 | Recalculate Cost Invalid Shipment Type | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | operationsToken | 400 | Reject invalid cost shipment type |
| 6 | Recalculate Cost Invalid Incoterm | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | operationsToken | 400 | Reject invalid cost incoterm |
| 7 | Recalculate Cost Invalid Currency | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | operationsToken | 400 | Reject invalid cost currency |
| 8 | Recalculate Cost Missing shipmentId | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | operationsToken | 400 | Reject missing shipmentId on cost payload |
| 9 | Recalculate Cost Idempotency Conflict Baseline | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | OPERATIONS_USER | 200 | Seed cost idempotency conflict |
| 10 | Recalculate Cost Idempotency Conflict Different Payload | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | OPERATIONS_USER | 409 | Enforce cost idempotency conflict |
| 11 | Get Missing Cost | `GET` | `{{baseUrl}}/api/v1/costs/{{missingShipmentId}}` | OPERATIONS_USER | 404 | Unknown cost not found |
| 12 | Search Costs as View Only | `GET` | `{{baseUrl}}/api/v1/costs` | VIEW_ONLY | 200 | View-only cost search |
| 13 | Recalculate Cost as View Only | `POST` | `{{baseUrl}}/api/v1/costs/recalculate` | VIEW_ONLY | 403 | View-only cost recalculation forbidden |

### 07 Quotation End-to-End
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Get FCL Quotation Projection as Quotation | `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}` | quotationToken | 200/404 | Read the FCL quotation projection; may still be asynchronous. |
| 2 | Search Quotations as Quotation | `GET` | `{{baseUrl}}/api/v1/quotations` | quotationToken | 200 | List quotation projections |
| 3 | Search Quotations by status GENERATED | `GET` | `{{baseUrl}}/api/v1/quotations?status=GENERATED` | quotationToken | 200 | Filter quotation projections by status |
| 4 | Generate FCL Quotation as Quotation | `POST` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}/generate` | QUOTATION_USER | 200 | Generate quotation documents for shipmentIdFcl |
| 5 | Generate AIR Quotation as Admin | `POST` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdAir}}/generate` | ADMIN | 200 | Generate quotation documents for shipmentIdAir |
| 6 | Generate LCL Quotation as Quotation | `POST` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdLcl}}/generate` | QUOTATION_USER | 200 | Generate quotation documents for shipmentIdLcl |
| 7 | Download FCL CSV as Quotation | `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}/documents/csv` | QUOTATION_USER | 200 | Download FCL CSV document |
| 8 | Download FCL PDF as Quotation | `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}/documents/pdf` | QUOTATION_USER | 200 | Download FCL PDF document |
| 9 | Download AIR CSV as Admin | `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdAir}}/documents/csv` | ADMIN | 200 | Download AIR CSV document |
| 10 | Download AIR PDF as Admin | `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdAir}}/documents/pdf` | ADMIN | 200 | Download AIR PDF document |
| 11 | Download LCL CSV as View Only | `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdLcl}}/documents/csv` | VIEW_ONLY | 200 | VIEW_ONLY can download LCL CSV |
| 12 | Download LCL PDF as Admin | `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdLcl}}/documents/pdf` | ADMIN | 200 | Download LCL PDF document |
| 13 | Search Invoices Alias as Quotation | `GET` | `{{baseUrl}}/api/v1/invoices` | QUOTATION_USER | 200 | Exercise invoice alias route |
| 14 | Get Invoice Alias for FCL as Quotation | `GET` | `{{baseUrl}}/api/v1/invoices/{{shipmentIdFcl}}` | QUOTATION_USER | 200/404 | Read invoice alias for FCL; may be asynchronous |

### 08 Quotation Validation & Security
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Get Quotations No Auth | `GET` | `{{baseUrl}}/api/v1/quotations` | mixed | 401 | Reject quotation search without a token |
| 2 | Get Quotations Invalid Token | `GET` | `{{baseUrl}}/api/v1/quotations` | mixed | 401 | Reject quotation search with invalid token |
| 3 | Get Quotations as Operations | `GET` | `{{baseUrl}}/api/v1/quotations` | mixed | 403 | OPERATIONS_USER must not read quotations |
| 4 | Generate Quotation as View Only | `POST` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}/generate` | mixed | 403 | VIEW_ONLY must not generate quotations |
| 5 | Generate Quotation Missing Shipment | `POST` | `{{baseUrl}}/api/v1/quotations/{{missingShipmentId}}/generate` | mixed | 404 | Generating for a missing shipment should fail |
| 6 | Download CSV Missing Shipment | `GET` | `{{baseUrl}}/api/v1/quotations/{{missingShipmentId}}/documents/csv` | mixed | 404 | Downloading CSV for missing shipment should fail |
| 7 | Download PDF Missing Shipment | `GET` | `{{baseUrl}}/api/v1/quotations/{{missingShipmentId}}/documents/pdf` | mixed | 404 | Downloading PDF for missing shipment should fail |
| 8 | Search Quotations as View Only | `GET` | `{{baseUrl}}/api/v1/quotations` | mixed | 200 | VIEW_ONLY can read quotations |
| 9 | Search Quotations as Admin | `GET` | `{{baseUrl}}/api/v1/quotations` | mixed | 200 | ADMIN can read quotations |
| 10 | Search Invoices as View Only | `GET` | `{{baseUrl}}/api/v1/invoices` | mixed | 200 | VIEW_ONLY can read invoices |

### 09 Rate Repository
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Get Rate Cards as Rates Admin | `GET` | `{{baseUrl}}/api/v1/rate-repository/cards` | ratesAdminToken | 200 | RATES_ADMIN reads all rate cards |
| 2 | Get Rate Cards as View Only | `GET` | `{{baseUrl}}/api/v1/rate-repository/cards` | viewOnlyToken | 200 | VIEW_ONLY reads rate cards |
| 3 | Get Rate Cards as Operations | `GET` | `{{baseUrl}}/api/v1/rate-repository/cards` | operationsToken | 200 | OPERATIONS_USER reads rate cards |
| 4 | Get Rate Cards FCL IMPORT as Quotation | `GET` | `{{baseUrl}}/api/v1/rate-repository/cards?modality=FCL&shipmentType=IMPORT` | quotationToken | 200 | QUOTATION_USER filters FCL import cards |
| 5 | Get Rate Cards AIR IMPORT as Admin | `GET` | `{{baseUrl}}/api/v1/rate-repository/cards?modality=AIR&shipmentType=IMPORT` | adminUserToken | 200 | ADMIN filters AIR import cards |
| 6 | Get Rate Cards LCL IMPORT as Quotation | `GET` | `{{baseUrl}}/api/v1/rate-repository/cards?modality=LCL&shipmentType=IMPORT` | quotationToken | 200 | QUOTATION_USER filters LCL import cards |
| 7 | Get Rate Cards No Auth | `GET` | `{{baseUrl}}/api/v1/rate-repository/cards` | none | 401 | Reject missing token for rate cards |
| 8 | Get Rate Cards Invalid Token | `GET` | `{{baseUrl}}/api/v1/rate-repository/cards` | invalid token | 401 | Reject invalid token for rate cards |

### 10 Rates Importer End-to-End
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Rates Importer Template as Rates Admin | `GET` | `{{baseUrl}}/api/v1/rates-importer/template` | RATES_ADMIN | 200 | Get importer template |
| 2 | Rates Importer Template as View Only | `GET` | `{{baseUrl}}/api/v1/rates-importer/template` | VIEW_ONLY | 200 | Get importer template as view-only |
| 3 | Create Manual Import Batch as Rates Admin | `POST` | `{{baseUrl}}/api/v1/rates-importer/batches` | RATES_ADMIN | 200 | Create manual import batch |
| 4 | List Import Batches as Rates Admin | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches` | RATES_ADMIN | 200 | List import batches |
| 5 | Get Manual Batch Details | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{manualBatchReference}}` | RATES_ADMIN | 200 | Get manual batch details |
| 6 | Upload Valid CSV as Rates Admin | `POST` | `{{baseUrl}}/api/v1/rates-importer/batches/upload` | RATES_ADMIN | 200 | Upload valid CSV |
| 7 | List Import Batches After Valid Upload | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches` | RATES_ADMIN | 200 | List batches after upload |
| 8 | Get Valid Upload Batch Details | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{validUploadBatchReference}}` | RATES_ADMIN | 200 | Get valid upload batch details |
| 9 | Get Valid Upload Batch Errors | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{validUploadBatchReference}}/errors` | RATES_ADMIN | 200 | Get valid upload batch errors |

### 11 Rates Importer Validation & Security
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | List Import Batches No Auth | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches` | mixed | 401 | Reject importer list reads without a token |
| 2 | List Import Batches Invalid Token | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches` | mixed | 401 | Reject importer list reads with invalid token |
| 3 | Read Template as Operations | `GET` | `{{baseUrl}}/api/v1/rates-importer/template` | mixed | 403 | OPERATIONS_USER must not read importer template |
| 4 | Create Batch as View Only | `POST` | `{{baseUrl}}/api/v1/rates-importer/batches` | mixed | 403 | VIEW_ONLY must not create import batches |
| 5 | Upload CSV as View Only | `POST` | `{{baseUrl}}/api/v1/rates-importer/batches/upload` | mixed | 403 | VIEW_ONLY must not upload files |
| 6 | Upload Missing File as Rates Admin | `POST` | `{{baseUrl}}/api/v1/rates-importer/batches/upload` | mixed | 400/500 | Reveal missing file-part behavior |
| 7 | Upload Wrong Extension as Rates Admin | `POST` | `{{baseUrl}}/api/v1/rates-importer/batches/upload` | mixed | 400/500 | Reject non-CSV uploads |
| 8 | Get Missing Batch Details | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{missingBatchReference}}` | mixed | 404/500 | Missing batch details may expose current error handling |
| 9 | Get Missing Batch Errors | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{missingBatchReference}}/errors` | mixed | 200 | Missing batch errors may return empty list |
| 10 | Upload Invalid CSV with Row Errors as Rates Admin | `POST` | `{{baseUrl}}/api/v1/rates-importer/batches/upload` | RATES_ADMIN | 200 | Upload invalid CSV with row errors |
| 11 | Get Invalid Upload Batch Details | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{invalidUploadBatchReference}}` | RATES_ADMIN | 200 | Get invalid upload batch details |
| 12 | Get Invalid Upload Batch Errors | `GET` | `{{baseUrl}}/api/v1/rates-importer/batches/{{invalidUploadBatchReference}}/errors` | RATES_ADMIN | 200 | Get invalid upload errors |

### 12 Pagination & Sanity
| # | Request | Method | Endpoint | Role / token | Expected result | Purpose |
|---:|---|---|---|---|---|---|
| 1 | Search Shipments size clamps to 100 | `GET` | `{{baseUrl}}/api/v1/shipments?page=0&size=999` | operationsToken | 200 | Shipment search should clamp size to 100 |
| 2 | Search Costs size clamps to 100 | `GET` | `{{baseUrl}}/api/v1/costs?page=0&size=999` | operationsToken | 200 | Cost search should clamp size to 100 |
| 3 | Search Quotations size clamps to 100 | `GET` | `{{baseUrl}}/api/v1/quotations?page=0&size=999` | quotationToken | 200 | Quotation search should clamp size to 100 |
| 4 | Search Shipments negative page normalizes to 0 | `GET` | `{{baseUrl}}/api/v1/shipments?page=-5&size=5` | operationsToken | 200 | Shipment search should normalize negative page |
| 5 | Search Costs negative page normalizes to 0 | `GET` | `{{baseUrl}}/api/v1/costs?page=-5&size=5` | operationsToken | 200 | Cost search should normalize negative page |
| 6 | Search Quotations negative page normalizes to 0 | `GET` | `{{baseUrl}}/api/v1/quotations?page=-5&size=5` | quotationToken | 200 | Quotation search should normalize negative page |
| 7 | Download FCL CSV content headers | `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}/documents/csv` | quotationToken | 200 | CSV download should include correct headers |
| 8 | Download FCL PDF content headers | `GET` | `{{baseUrl}}/api/v1/quotations/{{shipmentIdFcl}}/documents/pdf` | quotationToken | 200 | PDF download should include correct headers |
| 9 | Gateway Auth Me authorities include roles array | `GET` | `{{baseUrl}}/api/v1/auth/me` | ADMIN | 200 | Gateway auth returns authorities |
| 10 | Shipment Health remains public | `GET` | `{{baseUrl}}/api/v1/shipments/health` | public | 200 | Public health endpoint remains open |
| 11 | Rate Repository Health remains public | `GET` | `{{baseUrl}}/api/v1/rate-repository/health` | public | 200 | Public health endpoint remains open |
| 12 | Rates Importer Health remains public | `GET` | `{{baseUrl}}/api/v1/rates-importer/health` | public | 200 | Public health endpoint remains open |

## Endpoint explanation by business area

### Gateway / Auth
- `GET /actuator/health` — Gateway health status. Expected `200` with `UP`.
- `GET /api/v1/auth/me` — JWT introspection view from the gateway. Expected `200` with subject, username, email, and authorities when a valid token is supplied. Expected `401` without a token or with an invalid token.

### Shipments
- `POST /api/v1/shipments` — Creates a shipment and requires `Idempotency-Key` plus a valid token with `OPERATIONS_USER` or `ADMIN`. Expected `200` on success, `409` on idempotency conflict with a different payload, and validation errors on malformed bodies.
- `GET /api/v1/shipments/{{shipmentId}}` — Reads a shipment by ID. Expected `200` for existing shipments and `404` for unknown ones.
- `GET /api/v1/shipments` — Paged shipment search. Expected `200` with `content`, `page`, `size`, `totalElements`, and `totalPages`.
- `GET /api/v1/shipments/health` — Public shipment service health route via the gateway. Expected `200`.

### Costs
- `POST /api/v1/costs/recalculate` — Explicit cost recalculation endpoint. Requires `Idempotency-Key`. Expected `200` on success, `409` on idempotency conflict, and validation errors on malformed bodies.
- `GET /api/v1/costs/{{shipmentId}}` — Reads the cost record for a shipment. Expected `200` for existing records and `404` for missing ones.
- `GET /api/v1/costs` — Paged cost search. Expected `200` with page metadata and a content array.
- `GET /api/v1/costs/health` — Public costing health route via the gateway. Expected `200`.

### Quotations / Invoices
- `GET /api/v1/quotations/{{shipmentId}}` — Reads the quotation projection. In practice it may return `200` or `404` immediately after async costing events.
- `GET /api/v1/quotations` — Paged quotation search. Expected `200`.
- `POST /api/v1/quotations/{{shipmentId}}/generate` — Generates the quotation documents for a shipment. Expected `200` with `status`, `csvUrl`, and `pdfUrl` when shipment and cost data exist.
- `GET /api/v1/quotations/{{shipmentId}}/documents/csv` — Downloads the generated CSV document. Expected `200` with `text/csv`.
- `GET /api/v1/quotations/{{shipmentId}}/documents/pdf` — Downloads the generated PDF document. Expected `200` with `application/pdf`.
- `GET /api/v1/invoices` and `GET /api/v1/invoices/{{shipmentId}}` — Alias routes backed by quotation-service. Covered for read access and projection visibility.
- `GET /api/v1/quotations/health` — Public quotation health route via the gateway. Expected `200`.

### Rate Repository
- `GET /api/v1/rate-repository/cards` — Returns rate cards. Expected `200` for allowed roles and supports filter parameters `modality` and `shipmentType`.
- `GET /api/v1/rate-repository/health` — Public rate repository health route via the gateway. Expected `200`.

### Rates Importer
- `GET /api/v1/rates-importer/template` — Returns template headers and a sample row. Expected `200` for `RATES_ADMIN`, `VIEW_ONLY`, and `ADMIN`.
- `POST /api/v1/rates-importer/batches` — Creates a manual import batch. Expected `200` for `RATES_ADMIN` or `ADMIN`.
- `POST /api/v1/rates-importer/batches/upload` — Uploads a CSV file for import. Expected `200` for valid and row-error CSV scenarios; malformed uploads may expose `400/500` behavior.
- `GET /api/v1/rates-importer/batches` — Lists batches. Expected `200` for permitted roles.
- `GET /api/v1/rates-importer/batches/{{batchReference}}` — Gets batch details. Expected `200` for valid references and `404/500` for missing ones depending on current handler behavior.
- `GET /api/v1/rates-importer/batches/{{batchReference}}/errors` — Gets row-level import errors. Expected `200`, often with an empty array for successful batches.
- `GET /api/v1/rates-importer/health` — Public rates importer health route via the gateway. Expected `200`.

## Suggested presentation subset
For a live presentation, these are the cleanest requests to demo in order:
1. `Keycloak Ready Check`
2. `Get Operations User Token`
3. `Create FCL Shipment as Operations`
4. `Recalculate FCL Cost as Operations`
5. `Generate FCL Quotation as Quotation`
6. `Download FCL CSV as Quotation`
7. `Download FCL PDF as Quotation`
8. `Get Rate Cards FCL IMPORT as Quotation`
9. `Upload Valid CSV as Rates Admin`

## Final note
This pack is intentionally broad. It is useful both as a presentation/demo asset and as a regression pack to keep expanding as the platform hardens.
