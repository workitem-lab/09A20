# Run and Test

## Start
From the repo root:
```bash
cp .env.example .env
docker compose build --no-cache
docker compose up -d
```

## Health checks
```bash
curl http://localhost:8090
curl http://localhost:8080/actuator/health
curl http://localhost:8080/api/v1/customers/health
curl http://localhost:8080/api/v1/shipments/health
curl http://localhost:8080/api/v1/costs/health
curl http://localhost:8080/api/v1/quotations/health
```

## Create a prospect customer
```bash
curl -X POST http://localhost:8080/api/v1/customers/prospects \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "easyEstimateClientId": "EE-PROSPECT-001",
    "customerName": "Prospect Customer",
    "sourceSystem": "EASY_ESTIMATE"
  }'
```

## Link a prospect to a ShipShip registered customer
```bash
curl -X POST http://localhost:8080/api/v1/customers/EE-PROSPECT-001/link \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "shipshipClientCode": "SHIP001",
    "customerName": "Registered Customer",
    "sourceSystem": "SHIPSHIP"
  }'
```

## Create shipment
```bash
curl -X POST http://localhost:8080/api/v1/shipments \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: shipment-create-001" \
  -d @samples/fcl-import-shipment.json
```

## Fetch results
```bash
sleep 5
curl -H "Authorization: Bearer <access_token>" http://localhost:8080/api/v1/costs/SHIP-1001
curl -H "Authorization: Bearer <access_token>" http://localhost:8080/api/v1/quotations/SHIP-1001
```
