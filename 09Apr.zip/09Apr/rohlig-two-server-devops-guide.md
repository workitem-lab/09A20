# Röhlig Two-Server DevOps Deployment Guide
**Production-style implementation guide for Ubuntu, Bitbucket, Spring Boot, Angular, Kafka, and Docker Compose**

**Document purpose:** This guide describes a practical two-server deployment model for the Röhlig platform using one CI/CD server and one application server. It is written as an implementation document, not a concept note, and is meant to be usable by engineering, operations, and management.

**Target audience:** Engineering managers, platform engineers, backend engineers, frontend engineers, DevOps engineers, and support teams.

**Deployment model covered in this document:**
- **Server 1:** CI/CD server
- **Server 2:** Application server
- **Source control and CI/CD:** Bitbucket + Bitbucket Pipelines + self-hosted runner
- **Optional:** Jenkins on the CI/CD server
- **Runtime:** Docker Engine + Docker Compose plugin
- **Application stack:** Spring Boot backend services, Angular frontend, Kafka, PostgreSQL, reverse proxy, monitoring

---

# 1. Executive context

Röhlig needs a deployment model that is reliable enough for internal production-style operations without forcing a full Kubernetes footprint on day one. A two-server design is a sensible middle ground when the goal is to move quickly, keep infrastructure understandable, and still enforce discipline around builds, image versioning, deployment control, monitoring, rollback, and security.

This guide assumes the Röhlig platform consists of a gateway and several domain services, for example:

- `gateway`
- `shipment-service`
- `costing-service`
- `tariff-service`
- `quotation-service`
- `rate-repository-service`
- `rates-importer-service`
- `frontend`

The same approach works whether the platform is deployed as one repository or multiple repositories, but the examples below assume one primary platform repository and versioned Docker images for each deployable component.

In this design, the **CI/CD server** is responsible for running builds, tests, container image creation, and deployment automation. The **application server** is responsible for running the platform workload. Because this is a two-server design, platform dependencies like Kafka and PostgreSQL are colocated with the application workloads. That is acceptable for an internal production-style environment, but it must be understood as a stepping stone, not the final target state for large-scale enterprise production.

---

# 2. Target architecture

## 2.1 Logical architecture

```mermaid
flowchart LR
    Dev[Developers] --> BB[Bitbucket Repository]
    BB --> BP[Bitbucket Pipelines]
    BP --> Runner[Self-Hosted Runner on CI/CD Server]

    Runner --> Registry[Container Registry]
    Runner --> SSH[SSH Deployment Channel]

    SSH --> App[Application Server]
    Registry --> App

    subgraph CI_CD_Server
        Runner
        Jenkins[Jenkins - Optional]
    end

    subgraph Application_Server
        Proxy[Nginx Reverse Proxy]
        Frontend[Angular Frontend Container]
        Gateway[Spring Cloud Gateway]
        Ship[Shipment Service]
        Cost[Costing Service]
        Tariff[Tariff Service]
        Quote[Quotation Service]
        RateRepo[Rate Repository Service]
        Importer[Rates Importer Service]
        Kafka[Kafka]
        Postgres[PostgreSQL]
        Prom[Prometheus]
        Grafana[Grafana]
        cAdvisor[cAdvisor]
        NodeExp[node-exporter]
    end

    App --> Proxy
    Proxy --> Frontend
    Proxy --> Gateway
    Gateway --> Ship
    Gateway --> Cost
    Gateway --> Tariff
    Gateway --> Quote
    Gateway --> RateRepo
    Gateway --> Importer
    Ship --> Kafka
    Cost --> Kafka
    Tariff --> Postgres
    Quote --> Postgres
    RateRepo --> Postgres
    Importer --> Kafka
    Prom --> Grafana
```

## 2.2 Physical server responsibilities

### Server 1 — CI/CD server
This server hosts the build and deployment control plane. It should not run the business workload. Its responsibilities are:

- Host the Bitbucket self-hosted runner
- Run build tooling, Docker client and deployment scripts
- Hold deployment SSH keys securely
- Optionally run Jenkins if a second pipeline engine is required
- Act as the control plane for releases

### Server 2 — Application server
This server hosts the runtime platform. Its responsibilities are:

- Run Nginx as reverse proxy
- Run Angular frontend
- Run Spring Boot services
- Run Kafka
- Run PostgreSQL
- Run Prometheus, Grafana, and exporters
- Keep persistent volumes for database and observability state

## 2.3 Suggested sizing

For a serious internal environment, start with the following baseline and scale after load observation.

### CI/CD server
- 4 to 8 vCPU
- 16 GB RAM
- 150 GB SSD
- Ubuntu 22.04 LTS or 24.04 LTS

### Application server
- 8 to 16 vCPU
- 32 GB RAM minimum
- 300 GB SSD minimum
- Ubuntu 22.04 LTS or 24.04 LTS

If Kafka, PostgreSQL, Prometheus, and all services are on the same application host, do not under-size memory. Docker Compose makes deployment simple, but resource contention is still real.

---

# 3. Naming, DNS, and network plan

Use predictable naming from the start.

## 3.1 Example hostnames

- `ci-cd-01.rohlig.internal` — CI/CD server
- `app-01.rohlig.internal` — application server

## 3.2 Example public and internal endpoints

- `estimate.rohlig.example.com` — user-facing Angular UI
- `api.estimate.rohlig.example.com` — API gateway endpoint
- `grafana.rohlig.example.com` — monitoring dashboard
- `ci.rohlig.example.com` — Jenkins if enabled

## 3.3 Required network rules

Open only what is required.

### CI/CD server inbound
- `22/tcp` from admin IP ranges only
- `443/tcp` only if Jenkins or other web tooling is exposed
- No application workload ports

### Application server inbound
- `22/tcp` from CI/CD server and admin IP ranges only
- `80/tcp` and `443/tcp` from approved client networks or internet, depending on exposure policy
- Monitoring ports should not be open publicly if routed through Nginx or private access only

### East-west rules
- CI/CD server must SSH to application server
- Application server must be able to pull images from the chosen registry
- Services should communicate over an internal Docker network instead of host-exposed ports

---

# 4. Operating principles for this deployment

Before touching commands, align on these rules:

1. **Everything deploys from versioned container images.** No manual copying of jars or frontend static files to production.
2. **The application server never builds images.** It only pulls tagged images and runs them.
3. **Every release is traceable to a Git commit.**
4. **Configuration is externalized through environment variables and `.env` files.**
5. **Rollback is image-tag based.**
6. **Access is least-privilege.**
7. **Observability is mandatory, not optional.**
8. **Data volumes are explicit and protected.**
9. **The CI/CD server is not the same as the application server.**
10. **Manual fixes on the app server must be treated as incidents, documented, and folded back into automation.**

---

# 5. Server preparation on both Ubuntu hosts

Perform these steps on both servers before application-specific work begins.

## 5.1 Create an admin user and disable casual root usage

Log in as the initial privileged account and create a named admin account.

```bash
sudo adduser devopsadmin
sudo usermod -aG sudo devopsadmin
```

Copy your SSH public key to the new user.

```bash
ssh-copy-id devopsadmin@ci-cd-01.rohlig.internal
ssh-copy-id devopsadmin@app-01.rohlig.internal
```

Test login, then harden SSH later in this guide.

## 5.2 Update base packages

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget unzip git jq ca-certificates gnupg lsb-release \
  software-properties-common apt-transport-https vim htop net-tools ufw fail2ban
```

## 5.3 Set timezone and hostname

```bash
sudo timedatectl set-timezone Africa/Johannesburg
sudo hostnamectl set-hostname ci-cd-01.rohlig.internal
```

Run the equivalent hostname command on the application server.

## 5.4 Basic firewall rules

### On the CI/CD server
```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow from <YOUR_ADMIN_IP>/32 to any port 22 proto tcp
sudo ufw allow 443/tcp
sudo ufw enable
sudo ufw status verbose
```

### On the application server
```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow from <YOUR_ADMIN_IP>/32 to any port 22 proto tcp
sudo ufw allow from <CI_CD_SERVER_IP>/32 to any port 22 proto tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
sudo ufw status verbose
```

Do not open PostgreSQL or Kafka ports publicly unless there is a documented and approved reason.

## 5.5 Enable automatic security updates

```bash
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure --priority=low unattended-upgrades
```

## 5.6 Enable fail2ban

```bash
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
sudo systemctl status fail2ban
```

---

# 6. Install Docker Engine and Docker Compose plugin on both servers

Use Docker’s official repository method.

## 6.1 Remove older Docker packages if present

```bash
for pkg in docker.io docker-doc docker-compose docker-compose-v2 podman-docker containerd runc; do
  sudo apt-get remove -y $pkg
done
```

## 6.2 Add Docker repository

```bash
sudo install -m 0755 -d /etc/apt/keyrings
sudo apt update
sudo apt install -y ca-certificates curl
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
  https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "${UBUNTU_CODENAME:-$VERSION_CODENAME}") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
```

## 6.3 Install Docker Engine, Buildx, and Compose plugin

```bash
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

## 6.4 Enable and verify Docker

```bash
sudo systemctl enable docker
sudo systemctl start docker
sudo systemctl status docker
sudo docker run hello-world
docker compose version
```

## 6.5 Allow the deployment account to run Docker without sudo

Create a service account or use the admin account on each server.

```bash
sudo usermod -aG docker devopsadmin
newgrp docker
docker ps
```

---

# 7. CI/CD server setup

The CI/CD server will host the self-hosted runner and deployment scripts. It may also host Jenkins if required.

## 7.1 Create a deployment service account

```bash
sudo adduser --system --group --home /opt/rohlig-ci rohligci
sudo usermod -aG docker rohligci
```

Create working folders.

```bash
sudo mkdir -p /opt/rohlig-ci/{runner,scripts,logs,workspace}
sudo chown -R rohligci:rohligci /opt/rohlig-ci
```

## 7.2 Create an SSH key pair for deployments

Switch to the deployment account.

```bash
sudo -u rohligci -H bash
ssh-keygen -t ed25519 -C "rohlig-ci-deploy" -f ~/.ssh/id_ed25519
```

Copy the public key to the application server deployment user after that user exists.

## 7.3 Install utility tools for deployment operations

```bash
sudo apt install -y openssh-client rsync make
```

## 7.4 Choose the deployment pattern

For this two-server model, the simplest reliable pattern is:

- Bitbucket Pipelines triggers build and test
- A self-hosted runner on the CI/CD server handles privileged or internal deployment work
- Images are pushed to a registry
- The runner opens an SSH session to the application server
- The application server updates `.env`, pulls the release tag, and runs `docker compose up -d`

This keeps deployment control off the app server while still keeping production runtime simple.

---

# 8. Bitbucket repository and variable setup

Before configuring the runner, prepare the repository settings in Bitbucket.

## 8.1 Create repository or workspace variables

Create these as secured variables in Bitbucket:

- `REGISTRY_URL`
- `REGISTRY_USERNAME`
- `REGISTRY_PASSWORD`
- `APP_SERVER_HOST`
- `APP_SERVER_USER`
- `APP_SERVER_PORT`
- `SSH_PRIVATE_KEY`
- `SPRING_PROFILE`
- `IMAGE_TAG_PREFIX` if desired
- `GRAFANA_ADMIN_PASSWORD`
- `POSTGRES_PASSWORD`
- `KEYCLOAK_CLIENT_SECRET` if used later
- `JWT_SECRET` or equivalent if not externalized to secret management

Do not store secrets in source control. Keep `.env` files out of Git unless they are non-secret templates such as `.env.example`.

## 8.2 Recommended branch and release policy

Use a controlled branch policy:

- `feature/*` for work in progress
- `develop` for integration
- `main` for release-ready code
- Git tag releases such as `v1.0.0`, `v1.0.1`, `v1.1.0`

A simple internal production pattern is:

- auto-build on pull requests
- auto-build on `develop`
- build + publish + deploy on `main`
- manual approval for production deployment if governance requires it

---

# 9. Register the Bitbucket self-hosted runner on the CI/CD server

Use a **Linux Docker runner** for the CI/CD server. In Bitbucket, go to repository or workspace settings and create the runner. Bitbucket will generate a ready-to-run Docker command that registers the runner.

The exact tokenized command is generated by Bitbucket and should be copied from the Bitbucket UI at the time of registration. Store it securely because Bitbucket shows it once during setup.

## 9.1 Example working directory

```bash
sudo mkdir -p /opt/rohlig-ci/runner
sudo chown -R rohligci:rohligci /opt/rohlig-ci/runner
cd /opt/rohlig-ci/runner
```

## 9.2 Start the runner

From the Bitbucket UI, copy the runner installation command and run it on the CI/CD server as the deployment account or another controlled service account. The command typically pulls the Atlassian runner image and mounts local directories for runner state.

After registration, verify in Bitbucket that the runner status changes to **online**.

## 9.3 Runner labels

Use labels intentionally. Good examples:

- `self.hosted`
- `linux`
- `ci.rohlig`
- `deploy`
- `docker`

This allows you to send sensitive deployment steps only to this runner.

## 9.4 Runner housekeeping

The runner host needs regular hygiene.

Create a cleanup script:

```bash
sudo tee /opt/rohlig-ci/scripts/docker-cleanup.sh > /dev/null <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
docker system prune -af --volumes || true
EOF
sudo chmod +x /opt/rohlig-ci/scripts/docker-cleanup.sh
```

Add a cron entry:

```bash
sudo crontab -e
```

Example:
```cron
0 3 * * 0 /opt/rohlig-ci/scripts/docker-cleanup.sh >> /var/log/docker-cleanup.log 2>&1
```

---

# 10. Optional Jenkins setup on the CI/CD server

If Bitbucket Pipelines is sufficient, skip this section. Use Jenkins only when you have a specific reason, such as advanced pipeline orchestration, plugin-based governance, or enterprise workflow requirements.

## 10.1 Jenkins directories

```bash
sudo mkdir -p /opt/jenkins/{home,nginx}
sudo chown -R 1000:1000 /opt/jenkins/home
```

## 10.2 Jenkins Docker Compose example

Create `/opt/jenkins/docker-compose.yml`.

```yaml
services:
  jenkins:
    image: jenkins/jenkins:lts-jdk21
    container_name: jenkins
    restart: unless-stopped
    user: root
    ports:
      - "8080:8080"
      - "50000:50000"
    volumes:
      - /opt/jenkins/home:/var/jenkins_home
      - /var/run/docker.sock:/var/run/docker.sock
    environment:
      JAVA_OPTS: "-Djenkins.install.runSetupWizard=false"

  jenkins-agent-tools:
    image: docker:27-dind
    container_name: jenkins-agent-tools
    privileged: true
    restart: unless-stopped
    command: ["dockerd-entrypoint.sh"]
```

Start Jenkins:

```bash
cd /opt/jenkins
docker compose up -d
docker compose ps
docker logs -f jenkins
```

If exposing Jenkins externally, place it behind Nginx and TLS, and require SSO or at least strong authentication with IP controls.

## 10.3 Initial Jenkins admin password

```bash
docker exec jenkins cat /var/jenkins_home/secrets/initialAdminPassword
```

## 10.4 Jenkins recommendation

For this two-server Röhlig setup, prefer **Bitbucket Pipelines + self-hosted runner** as the primary path. Keep Jenkins optional, not parallel, unless there is a firm business reason to operate both.

---

# 11. Application server setup

The application server hosts the runtime platform. We want one predictable structure on disk.

## 11.1 Create deployment account

```bash
sudo adduser --system --group --home /opt/rohlig-app rohligapp
sudo usermod -aG docker rohligapp
```

Create directories:

```bash
sudo mkdir -p /opt/rohlig-app/{config,compose,data,logs,releases,backup,scripts}
sudo mkdir -p /opt/rohlig-app/data/{postgres,kafka,prometheus,grafana}
sudo chown -R rohligapp:rohligapp /opt/rohlig-app
```

## 11.2 Authorize CI/CD server SSH access

Append the CI/CD server public key to the app server deployment user.

```bash
sudo -u rohligapp -H bash -c 'mkdir -p ~/.ssh && chmod 700 ~/.ssh'
sudo -u rohligapp -H bash -c 'touch ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys'
sudo -u rohligapp -H bash -c 'echo "<CI_CD_PUBLIC_KEY>" >> ~/.ssh/authorized_keys'
```

Test from the CI/CD server:

```bash
sudo -u rohligci ssh rohligapp@app-01.rohlig.internal 'hostname && whoami'
```

---

# 12. Reverse proxy and TLS approach

The application server should expose only a reverse proxy externally. All business services remain on the internal Docker network.

For this guide, Nginx will do the following:

- terminate TLS
- serve the Angular frontend
- route `/api` traffic to the gateway
- optionally route `/grafana` if allowed internally only

You can run Nginx as a container so the entire platform is managed through Compose.

---

# 13. Application server environment file

Create `/opt/rohlig-app/config/platform.env`.

```bash
sudo tee /opt/rohlig-app/config/platform.env > /dev/null <<'EOF'
COMPOSE_PROJECT_NAME=rohlig
APP_ENV=prod
IMAGE_TAG=latest

POSTGRES_DB=rohlig
POSTGRES_USER=rohlig
POSTGRES_PASSWORD=change_me_now

KAFKA_NODE_ID=1
KAFKA_CLUSTER_ID=abcdefghijklmno1234567
KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT
KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://kafka:9092,PLAINTEXT_HOST://app-01.rohlig.internal:29092

SPRING_PROFILES_ACTIVE=prod
JAVA_OPTS=-Xms256m -Xmx1024m

GRAFANA_ADMIN_USER=admin
GRAFANA_ADMIN_PASSWORD=change_me_now

ROHLIG_GATEWAY_IMAGE=registry.example.com/rohlig/gateway
ROHLIG_SHIPMENT_IMAGE=registry.example.com/rohlig/shipment-service
ROHLIG_COSTING_IMAGE=registry.example.com/rohlig/costing-service
ROHLIG_TARIFF_IMAGE=registry.example.com/rohlig/tariff-service
ROHLIG_QUOTATION_IMAGE=registry.example.com/rohlig/quotation-service
ROHLIG_RATE_REPOSITORY_IMAGE=registry.example.com/rohlig/rate-repository-service
ROHLIG_RATES_IMPORTER_IMAGE=registry.example.com/rohlig/rates-importer-service
ROHLIG_FRONTEND_IMAGE=registry.example.com/rohlig/frontend

API_BASE_URL=https://api.estimate.rohlig.example.com
UI_BASE_URL=https://estimate.rohlig.example.com
EOF
```

Set permissions:

```bash
sudo chown rohligapp:rohligapp /opt/rohlig-app/config/platform.env
sudo chmod 640 /opt/rohlig-app/config/platform.env
```

---

# 14. Main Docker Compose deployment on the application server

Create `/opt/rohlig-app/compose/docker-compose.yml`.

```yaml
services:
  reverse-proxy:
    image: nginx:1.27-alpine
    container_name: rohlig-reverse-proxy
    restart: unless-stopped
    depends_on:
      - frontend
      - gateway
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - /opt/rohlig-app/config/nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - /opt/rohlig-app/config/nginx/conf.d:/etc/nginx/conf.d:ro
      - /opt/rohlig-app/config/nginx/certs:/etc/nginx/certs:ro
    networks:
      - rohlig-public
      - rohlig-internal

  frontend:
    image: ${ROHLIG_FRONTEND_IMAGE}:${IMAGE_TAG}
    container_name: rohlig-frontend
    restart: unless-stopped
    networks:
      - rohlig-internal

  gateway:
    image: ${ROHLIG_GATEWAY_IMAGE}:${IMAGE_TAG}
    container_name: rohlig-gateway
    restart: unless-stopped
    env_file:
      - /opt/rohlig-app/config/platform.env
    environment:
      SPRING_PROFILES_ACTIVE: ${SPRING_PROFILES_ACTIVE}
      SERVER_PORT: 8080
      JAVA_OPTS: ${JAVA_OPTS}
    depends_on:
      - shipment-service
      - costing-service
      - tariff-service
      - quotation-service
      - rate-repository-service
      - rates-importer-service
    networks:
      - rohlig-internal

  shipment-service:
    image: ${ROHLIG_SHIPMENT_IMAGE}:${IMAGE_TAG}
    container_name: rohlig-shipment-service
    restart: unless-stopped
    env_file:
      - /opt/rohlig-app/config/platform.env
    environment:
      SPRING_PROFILES_ACTIVE: ${SPRING_PROFILES_ACTIVE}
      SERVER_PORT: 8081
      SPRING_DATASOURCE_URL: jdbc:postgresql://postgres:5432/${POSTGRES_DB}
      SPRING_DATASOURCE_USERNAME: ${POSTGRES_USER}
      SPRING_DATASOURCE_PASSWORD: ${POSTGRES_PASSWORD}
      SPRING_KAFKA_BOOTSTRAP_SERVERS: kafka:9092
      JAVA_OPTS: ${JAVA_OPTS}
    depends_on:
      - postgres
      - kafka
    networks:
      - rohlig-internal

  costing-service:
    image: ${ROHLIG_COSTING_IMAGE}:${IMAGE_TAG}
    container_name: rohlig-costing-service
    restart: unless-stopped
    env_file:
      - /opt/rohlig-app/config/platform.env
    environment:
      SPRING_PROFILES_ACTIVE: ${SPRING_PROFILES_ACTIVE}
      SERVER_PORT: 8082
      SPRING_DATASOURCE_URL: jdbc:postgresql://postgres:5432/${POSTGRES_DB}
      SPRING_DATASOURCE_USERNAME: ${POSTGRES_USER}
      SPRING_DATASOURCE_PASSWORD: ${POSTGRES_PASSWORD}
      SPRING_KAFKA_BOOTSTRAP_SERVERS: kafka:9092
      JAVA_OPTS: ${JAVA_OPTS}
    depends_on:
      - postgres
      - kafka
    networks:
      - rohlig-internal

  tariff-service:
    image: ${ROHLIG_TARIFF_IMAGE}:${IMAGE_TAG}
    container_name: rohlig-tariff-service
    restart: unless-stopped
    env_file:
      - /opt/rohlig-app/config/platform.env
    environment:
      SPRING_PROFILES_ACTIVE: ${SPRING_PROFILES_ACTIVE}
      SERVER_PORT: 8083
      SPRING_DATASOURCE_URL: jdbc:postgresql://postgres:5432/${POSTGRES_DB}
      SPRING_DATASOURCE_USERNAME: ${POSTGRES_USER}
      SPRING_DATASOURCE_PASSWORD: ${POSTGRES_PASSWORD}
      JAVA_OPTS: ${JAVA_OPTS}
    depends_on:
      - postgres
    networks:
      - rohlig-internal

  quotation-service:
    image: ${ROHLIG_QUOTATION_IMAGE}:${IMAGE_TAG}
    container_name: rohlig-quotation-service
    restart: unless-stopped
    env_file:
      - /opt/rohlig-app/config/platform.env
    environment:
      SPRING_PROFILES_ACTIVE: ${SPRING_PROFILES_ACTIVE}
      SERVER_PORT: 8084
      SPRING_DATASOURCE_URL: jdbc:postgresql://postgres:5432/${POSTGRES_DB}
      SPRING_DATASOURCE_USERNAME: ${POSTGRES_USER}
      SPRING_DATASOURCE_PASSWORD: ${POSTGRES_PASSWORD}
      JAVA_OPTS: ${JAVA_OPTS}
    depends_on:
      - postgres
    networks:
      - rohlig-internal

  rate-repository-service:
    image: ${ROHLIG_RATE_REPOSITORY_IMAGE}:${IMAGE_TAG}
    container_name: rohlig-rate-repository-service
    restart: unless-stopped
    env_file:
      - /opt/rohlig-app/config/platform.env
    environment:
      SPRING_PROFILES_ACTIVE: ${SPRING_PROFILES_ACTIVE}
      SERVER_PORT: 8085
      SPRING_DATASOURCE_URL: jdbc:postgresql://postgres:5432/${POSTGRES_DB}
      SPRING_DATASOURCE_USERNAME: ${POSTGRES_USER}
      SPRING_DATASOURCE_PASSWORD: ${POSTGRES_PASSWORD}
      JAVA_OPTS: ${JAVA_OPTS}
    depends_on:
      - postgres
    networks:
      - rohlig-internal

  rates-importer-service:
    image: ${ROHLIG_RATES_IMPORTER_IMAGE}:${IMAGE_TAG}
    container_name: rohlig-rates-importer-service
    restart: unless-stopped
    env_file:
      - /opt/rohlig-app/config/platform.env
    environment:
      SPRING_PROFILES_ACTIVE: ${SPRING_PROFILES_ACTIVE}
      SERVER_PORT: 8086
      SPRING_DATASOURCE_URL: jdbc:postgresql://postgres:5432/${POSTGRES_DB}
      SPRING_DATASOURCE_USERNAME: ${POSTGRES_USER}
      SPRING_DATASOURCE_PASSWORD: ${POSTGRES_PASSWORD}
      SPRING_KAFKA_BOOTSTRAP_SERVERS: kafka:9092
      JAVA_OPTS: ${JAVA_OPTS}
    depends_on:
      - postgres
      - kafka
    networks:
      - rohlig-internal

  postgres:
    image: postgres:15
    container_name: rohlig-postgres
    restart: unless-stopped
    environment:
      POSTGRES_DB: ${POSTGRES_DB}
      POSTGRES_USER: ${POSTGRES_USER}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    volumes:
      - /opt/rohlig-app/data/postgres:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}"]
      interval: 15s
      timeout: 5s
      retries: 10
    networks:
      - rohlig-internal

  kafka:
    image: bitnami/kafka:3.7
    container_name: rohlig-kafka
    restart: unless-stopped
    environment:
      KAFKA_CFG_NODE_ID: ${KAFKA_NODE_ID}
      KAFKA_CFG_PROCESS_ROLES: broker,controller
      KAFKA_CFG_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_CFG_LISTENERS: PLAINTEXT://:9092,CONTROLLER://:9093,PLAINTEXT_HOST://:29092
      KAFKA_CFG_LISTENER_SECURITY_PROTOCOL_MAP: ${KAFKA_LISTENER_SECURITY_PROTOCOL_MAP}
      KAFKA_CFG_ADVERTISED_LISTENERS: ${KAFKA_ADVERTISED_LISTENERS}
      KAFKA_CFG_CONTROLLER_QUORUM_VOTERS: 1@kafka:9093
      KAFKA_CFG_AUTO_CREATE_TOPICS_ENABLE: "true"
      KAFKA_KRAFT_CLUSTER_ID: ${KAFKA_CLUSTER_ID}
      ALLOW_PLAINTEXT_LISTENER: "yes"
    volumes:
      - /opt/rohlig-app/data/kafka:/bitnami/kafka
    networks:
      - rohlig-internal

  prometheus:
    image: prom/prometheus:v2.54.1
    container_name: rohlig-prometheus
    restart: unless-stopped
    volumes:
      - /opt/rohlig-app/config/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - /opt/rohlig-app/data/prometheus:/prometheus
    command:
      - "--config.file=/etc/prometheus/prometheus.yml"
      - "--storage.tsdb.path=/prometheus"
    networks:
      - rohlig-internal

  grafana:
    image: grafana/grafana:11.1.4
    container_name: rohlig-grafana
    restart: unless-stopped
    environment:
      GF_SECURITY_ADMIN_USER: ${GRAFANA_ADMIN_USER}
      GF_SECURITY_ADMIN_PASSWORD: ${GRAFANA_ADMIN_PASSWORD}
    volumes:
      - /opt/rohlig-app/data/grafana:/var/lib/grafana
    networks:
      - rohlig-internal

  cadvisor:
    image: gcr.io/cadvisor/cadvisor:v0.49.1
    container_name: rohlig-cadvisor
    restart: unless-stopped
    privileged: true
    devices:
      - /dev/kmsg:/dev/kmsg
    volumes:
      - /:/rootfs:ro
      - /var/run:/var/run:rw
      - /sys:/sys:ro
      - /var/lib/docker:/var/lib/docker:ro
    networks:
      - rohlig-internal

  node-exporter:
    image: prom/node-exporter:v1.8.2
    container_name: rohlig-node-exporter
    restart: unless-stopped
    command:
      - "--path.rootfs=/host"
    volumes:
      - /:/host:ro,rslave
    networks:
      - rohlig-internal

networks:
  rohlig-public:
    driver: bridge
  rohlig-internal:
    driver: bridge
```

This Compose file intentionally keeps application ports off the host. Only the reverse proxy publishes host ports.

---

# 15. Nginx configuration

Create directories:

```bash
sudo mkdir -p /opt/rohlig-app/config/nginx/conf.d
sudo mkdir -p /opt/rohlig-app/config/nginx/certs
sudo chown -R rohligapp:rohligapp /opt/rohlig-app/config/nginx
```

## 15.1 Main Nginx config

Create `/opt/rohlig-app/config/nginx/nginx.conf`.

```nginx
user  nginx;
worker_processes  auto;

events {
    worker_connections 1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    server_tokens off;

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    include /etc/nginx/conf.d/*.conf;
}
```

## 15.2 Virtual host config

Create `/opt/rohlig-app/config/nginx/conf.d/rohlig.conf`.

```nginx
server {
    listen 80;
    server_name estimate.rohlig.example.com api.estimate.rohlig.example.com grafana.rohlig.example.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name estimate.rohlig.example.com;

    ssl_certificate     /etc/nginx/certs/fullchain.pem;
    ssl_certificate_key /etc/nginx/certs/privkey.pem;

    location / {
        proxy_pass http://frontend:80;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}

server {
    listen 443 ssl http2;
    server_name api.estimate.rohlig.example.com;

    ssl_certificate     /etc/nginx/certs/fullchain.pem;
    ssl_certificate_key /etc/nginx/certs/privkey.pem;

    client_max_body_size 20m;

    location / {
        proxy_pass http://gateway:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}

server {
    listen 443 ssl http2;
    server_name grafana.rohlig.example.com;

    ssl_certificate     /etc/nginx/certs/fullchain.pem;
    ssl_certificate_key /etc/nginx/certs/privkey.pem;

    allow <YOUR_ADMIN_IP>;
    deny all;

    location / {
        proxy_pass http://grafana:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

For internal-only environments, you may use internal PKI instead of public certificates. For internet-facing use, terminate with trusted TLS certificates.

---

# 16. Prometheus configuration

Create directories:

```bash
sudo mkdir -p /opt/rohlig-app/config/prometheus
```

Create `/opt/rohlig-app/config/prometheus/prometheus.yml`.

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: prometheus
    static_configs:
      - targets: ['prometheus:9090']

  - job_name: node-exporter
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: cadvisor
    static_configs:
      - targets: ['cadvisor:8080']

  - job_name: gateway
    metrics_path: /actuator/prometheus
    static_configs:
      - targets: ['gateway:8080']

  - job_name: shipment-service
    metrics_path: /actuator/prometheus
    static_configs:
      - targets: ['shipment-service:8081']

  - job_name: costing-service
    metrics_path: /actuator/prometheus
    static_configs:
      - targets: ['costing-service:8082']

  - job_name: tariff-service
    metrics_path: /actuator/prometheus
    static_configs:
      - targets: ['tariff-service:8083']

  - job_name: quotation-service
    metrics_path: /actuator/prometheus
    static_configs:
      - targets: ['quotation-service:8084']

  - job_name: rate-repository-service
    metrics_path: /actuator/prometheus
    static_configs:
      - targets: ['rate-repository-service:8085']

  - job_name: rates-importer-service
    metrics_path: /actuator/prometheus
    static_configs:
      - targets: ['rates-importer-service:8086']
```

This assumes each Spring Boot service exposes actuator metrics.

---

# 17. Spring Boot production configuration expectations

For this deployment pattern, each Spring Boot service should already support:

- `management.endpoints.web.exposure.include=health,info,prometheus`
- health checks on `/actuator/health`
- metrics on `/actuator/prometheus`
- externalized database and Kafka settings
- log output to standard out
- graceful shutdown
- Flyway or Liquibase migrations
- idempotent startup where possible

Example application configuration fragment:

```yaml
server:
  shutdown: graceful

management:
  endpoints:
    web:
      exposure:
        include: health,info,prometheus
  endpoint:
    health:
      probes:
        enabled: true

spring:
  lifecycle:
    timeout-per-shutdown-phase: 30s
```

---

# 18. Angular frontend production build expectations

The frontend container should not run the Angular development server in production. It should serve built static files using Nginx or a lightweight web server.

A good production Dockerfile pattern is:

```dockerfile
FROM node:22-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:1.27-alpine
COPY --from=build /app/dist/rohlig-frontend/browser /usr/share/nginx/html
COPY nginx/default.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
```

The frontend should read the correct API base URL either through build-time environment replacement or runtime configuration injection.

---

# 19. Container registry strategy

The deployment model requires a container registry. Valid options include:

- Docker Hub private repositories
- GitHub Container Registry
- AWS ECR
- Azure Container Registry
- a self-hosted registry

For this guide, use a private registry and tag each image with:

- commit SHA
- semantic version tag if released
- optionally `latest` on `main`

A good example:

- `registry.example.com/rohlig/gateway:1.2.4`
- `registry.example.com/rohlig/gateway:8f41d9c`
- `registry.example.com/rohlig/gateway:latest`

Never deploy untraceable local-only images to production-style environments.

---

# 20. Bitbucket Pipelines configuration

Below is a practical `bitbucket-pipelines.yml` example for a monorepo containing backend services and Angular frontend. Adjust paths and build commands to your repository structure.

Create `bitbucket-pipelines.yml` in the repository root.

```yaml
image: atlassian/default-image:4

definitions:
  caches:
    maven: ~/.m2/repository
    node: ~/.npm

  services:
    docker:
      memory: 3072

pipelines:
  pull-requests:
    '**':
      - parallel:
          - step:
              name: Backend Unit Tests
              image: maven:3.9.9-eclipse-temurin-21
              caches:
                - maven
              script:
                - mvn -B -ntp clean test
          - step:
              name: Frontend Build Validation
              image: node:22-alpine
              caches:
                - node
              script:
                - cd frontend
                - npm ci
                - npm run lint || true
                - npm run build

  branches:
    develop:
      - parallel:
          - step:
              name: Backend Tests
              image: maven:3.9.9-eclipse-temurin-21
              caches:
                - maven
              script:
                - mvn -B -ntp clean test
          - step:
              name: Frontend Tests
              image: node:22-alpine
              caches:
                - node
              script:
                - cd frontend
                - npm ci
                - npm run build

    main:
      - parallel:
          - step:
              name: Backend Tests
              image: maven:3.9.9-eclipse-temurin-21
              caches:
                - maven
              script:
                - mvn -B -ntp clean test
          - step:
              name: Frontend Build
              image: node:22-alpine
              caches:
                - node
              script:
                - cd frontend
                - npm ci
                - npm run build

      - step:
          name: Build and Push Images
          services:
            - docker
          script:
            - export IMAGE_TAG=${BITBUCKET_COMMIT}
            - echo "${REGISTRY_PASSWORD}" | docker login ${REGISTRY_URL} -u "${REGISTRY_USERNAME}" --password-stdin

            - docker build -t ${REGISTRY_URL}/rohlig/gateway:${IMAGE_TAG} ./gateway
            - docker push ${REGISTRY_URL}/rohlig/gateway:${IMAGE_TAG}

            - docker build -t ${REGISTRY_URL}/rohlig/shipment-service:${IMAGE_TAG} ./shipment-service
            - docker push ${REGISTRY_URL}/rohlig/shipment-service:${IMAGE_TAG}

            - docker build -t ${REGISTRY_URL}/rohlig/costing-service:${IMAGE_TAG} ./costing-service
            - docker push ${REGISTRY_URL}/rohlig/costing-service:${IMAGE_TAG}

            - docker build -t ${REGISTRY_URL}/rohlig/tariff-service:${IMAGE_TAG} ./tariff-service
            - docker push ${REGISTRY_URL}/rohlig/tariff-service:${IMAGE_TAG}

            - docker build -t ${REGISTRY_URL}/rohlig/quotation-service:${IMAGE_TAG} ./quotation-service
            - docker push ${REGISTRY_URL}/rohlig/quotation-service:${IMAGE_TAG}

            - docker build -t ${REGISTRY_URL}/rohlig/rate-repository-service:${IMAGE_TAG} ./rate-repository-service
            - docker push ${REGISTRY_URL}/rohlig/rate-repository-service:${IMAGE_TAG}

            - docker build -t ${REGISTRY_URL}/rohlig/rates-importer-service:${IMAGE_TAG} ./rates-importer-service
            - docker push ${REGISTRY_URL}/rohlig/rates-importer-service:${IMAGE_TAG}

            - docker build -t ${REGISTRY_URL}/rohlig/frontend:${IMAGE_TAG} ./frontend
            - docker push ${REGISTRY_URL}/rohlig/frontend:${IMAGE_TAG}

      - step:
          name: Deploy to App Server
          image: alpine:3.20
          runs-on:
            - self.hosted
            - linux
            - ci.rohlig
            - deploy
          script:
            - apk add --no-cache openssh-client bash
            - mkdir -p ~/.ssh
            - chmod 700 ~/.ssh
            - echo "${SSH_PRIVATE_KEY}" > ~/.ssh/id_ed25519
            - chmod 600 ~/.ssh/id_ed25519
            - ssh-keyscan -p ${APP_SERVER_PORT} ${APP_SERVER_HOST} >> ~/.ssh/known_hosts

            - |
              ssh -p ${APP_SERVER_PORT} ${APP_SERVER_USER}@${APP_SERVER_HOST} <<EOF
              set -euo pipefail
              export IMAGE_TAG=${BITBUCKET_COMMIT}
              cd /opt/rohlig-app/compose
              sed -i "s/^IMAGE_TAG=.*/IMAGE_TAG=${BITBUCKET_COMMIT}/" /opt/rohlig-app/config/platform.env
              docker login ${REGISTRY_URL} -u "${REGISTRY_USERNAME}" -p "${REGISTRY_PASSWORD}"
              docker compose --env-file /opt/rohlig-app/config/platform.env pull
              docker compose --env-file /opt/rohlig-app/config/platform.env up -d --remove-orphans
              docker compose ps
              curl -fsS https://api.estimate.rohlig.example.com/actuator/health || exit 1
              EOF
```

## 20.1 Notes on this pipeline

This pipeline does four important things:

1. validates backend and frontend
2. builds and pushes versioned images
3. deploys only from the self-hosted runner
4. updates the application server using the Git commit SHA as the release tag

That is the foundation of traceable deployment.

---

# 21. Deployment flow

This section describes the expected operational flow from commit to running workload.

## 21.1 Developer flow

A developer pushes code to a feature branch. Bitbucket opens a pull request and automatically validates the branch. Backend tests and frontend build verification run. If they pass, code is reviewed and merged.

## 21.2 Build flow on `main`

When code lands on `main`, the pipeline:

- re-runs tests
- builds all deployable Docker images
- pushes each image to the registry with the commit SHA tag
- sends the deploy step to the self-hosted runner

## 21.3 Deployment flow to the application server

The self-hosted runner:

- connects by SSH to the application server
- updates `IMAGE_TAG` in `platform.env`
- logs into the registry
- pulls the tagged images
- recreates containers with `docker compose up -d --remove-orphans`
- runs health checks

## 21.4 Smoke testing

At minimum, run:

- UI reachability check
- gateway health check
- one business API call that proves application behavior is alive
- one Kafka-related workflow check if event processing is central to the release

Example smoke test commands:

```bash
curl -I https://estimate.rohlig.example.com
curl -fsS https://api.estimate.rohlig.example.com/actuator/health
curl -fsS https://api.estimate.rohlig.example.com/api/v1/shipments/health || true
```

---

# 22. First deployment procedure

Once both servers are prepared, perform the first controlled deployment.

## 22.1 Copy configuration files to the app server

```bash
scp -r /opt/rohlig-app/config rohligapp@app-01.rohlig.internal:/opt/rohlig-app/
scp /opt/rohlig-app/compose/docker-compose.yml rohligapp@app-01.rohlig.internal:/opt/rohlig-app/compose/
```

## 22.2 Log in to the registry on the app server

```bash
ssh rohligapp@app-01.rohlig.internal
docker login registry.example.com
```

## 22.3 Start the stack

```bash
cd /opt/rohlig-app/compose
docker compose --env-file /opt/rohlig-app/config/platform.env pull
docker compose --env-file /opt/rohlig-app/config/platform.env up -d
docker compose ps
```

## 22.4 Verify logs

```bash
docker compose logs -f reverse-proxy
docker compose logs -f gateway
docker compose logs -f shipment-service
docker compose logs -f postgres
docker compose logs -f kafka
```

## 22.5 Verify health

```bash
curl -fsS http://localhost
curl -fsS http://localhost:80 || true
docker compose ps
```

If TLS and DNS are ready, validate externally:

```bash
curl -I https://estimate.rohlig.example.com
curl -fsS https://api.estimate.rohlig.example.com/actuator/health
```

---

# 23. Monitoring and operational visibility

Monitoring is essential because Docker Compose does not provide the operational abstractions that Kubernetes would normally provide.

## 23.1 Minimum telemetry set

The platform should track at least:

- CPU and memory usage by host
- CPU and memory usage by container
- HTTP response times and error rates
- service health status
- database availability
- Kafka broker availability
- disk usage
- container restart counts
- JVM memory and thread metrics
- business flow metrics such as quote creation, shipment pricing time, import job counts

## 23.2 Grafana dashboards

At minimum, create dashboards for:

- application server health
- gateway traffic
- Spring Boot service metrics
- PostgreSQL basics
- Kafka basics
- Docker/container status

## 23.3 Alerting recommendations

Set alerts for:

- application server CPU > 85%
- application server disk > 80%
- PostgreSQL down
- Kafka down
- any critical service health check failing
- repeated container restart loops
- gateway 5xx surge
- deployment failure on `main`

If email or Slack alerting is not yet available, set it up early. Silent failure is unacceptable.

---

# 24. Security hardening

A production-style environment is not only about successful deployment. It is also about controlled exposure and recoverability.

## 24.1 SSH hardening

Edit `/etc/ssh/sshd_config` on both servers.

```text
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
ChallengeResponseAuthentication no
UsePAM yes
X11Forwarding no
AllowUsers devopsadmin rohligci rohligapp
```

Restart SSH:

```bash
sudo systemctl restart ssh
```

## 24.2 Secrets handling

Do not hardcode secrets in Dockerfiles, source control, or Nginx configs. Prefer one of these approaches:

- secured Bitbucket variables
- a protected `.env` file deployed by automation
- an external secret manager later, such as Vault or cloud-native secret storage

For the two-server model, a protected `.env` file plus Bitbucket secured variables is acceptable as a first phase.

## 24.3 Principle of least privilege

- CI/CD server gets only deploy access, not business data admin rights
- Application server user should not be a general admin account
- Only Nginx exposes public ports
- PostgreSQL and Kafka stay private to the Docker network unless there is a reviewed exception

## 24.4 TLS and certificates

Terminate HTTPS at the reverse proxy. Use:

- internal PKI for internal-only environments, or
- publicly trusted certificates for public exposure

Renewal must be automated if using public ACME certificates.

## 24.5 Container image hygiene

- pin major versions for base images
- rebuild regularly for security patches
- scan images before promotion if your toolchain supports it
- remove unused images and stopped containers

## 24.6 Host backups

At minimum, back up:

- `/opt/rohlig-app/config`
- PostgreSQL data
- Grafana data if dashboard state is important
- release records and deployment logs

Do not treat Docker volumes as a backup strategy by themselves.

---

# 25. Data backup and recovery

A platform without recovery steps is not production-style.

## 25.1 PostgreSQL logical backup script

Create `/opt/rohlig-app/scripts/backup-postgres.sh`.

```bash
#!/usr/bin/env bash
set -euo pipefail

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/opt/rohlig-app/backup/postgres"
mkdir -p "${BACKUP_DIR}"

docker exec rohlig-postgres pg_dump -U rohlig rohlig > "${BACKUP_DIR}/rohlig_${TIMESTAMP}.sql"
gzip "${BACKUP_DIR}/rohlig_${TIMESTAMP}.sql"
find "${BACKUP_DIR}" -type f -mtime +14 -delete
```

Set permissions and test it.

```bash
chmod +x /opt/rohlig-app/scripts/backup-postgres.sh
/opt/rohlig-app/scripts/backup-postgres.sh
```

Add cron:

```cron
0 1 * * * /opt/rohlig-app/scripts/backup-postgres.sh >> /var/log/rohlig-postgres-backup.log 2>&1
```

## 25.2 Recovery basics

To restore:

```bash
gunzip -c /opt/rohlig-app/backup/postgres/rohlig_YYYYMMDD_HHMMSS.sql.gz | \
docker exec -i rohlig-postgres psql -U rohlig rohlig
```

For production-grade recovery, also consider filesystem snapshots or block storage snapshots depending on hosting platform.

---

# 26. Rollback strategy

Rollback must be simple, fast, and documented. The easiest rollback model for this setup is **image-tag rollback**.

## 26.1 Keep prior successful release tags

Record the last known good release tag in a release log, for example:

```text
2026-04-08 15:00 SAST | main | 8f41d9c | SUCCESS
2026-04-09 09:20 SAST | main | 2b7a1c2 | FAILED - rolled back
```

Store this in `/opt/rohlig-app/releases/releases.log` or an equivalent deployment tracking system.

## 26.2 Manual rollback steps

On the application server:

```bash
sed -i 's/^IMAGE_TAG=.*/IMAGE_TAG=8f41d9c/' /opt/rohlig-app/config/platform.env
cd /opt/rohlig-app/compose
docker compose --env-file /opt/rohlig-app/config/platform.env pull
docker compose --env-file /opt/rohlig-app/config/platform.env up -d --remove-orphans
docker compose ps
```

## 26.3 Automated rollback script

Create `/opt/rohlig-app/scripts/rollback.sh`.

```bash
#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: rollback.sh <image_tag>"
  exit 1
fi

TAG="$1"
ENV_FILE="/opt/rohlig-app/config/platform.env"
COMPOSE_DIR="/opt/rohlig-app/compose"

sed -i "s/^IMAGE_TAG=.*/IMAGE_TAG=${TAG}/" "${ENV_FILE}"
cd "${COMPOSE_DIR}"
docker compose --env-file "${ENV_FILE}" pull
docker compose --env-file "${ENV_FILE}" up -d --remove-orphans
docker compose ps
```

Make it executable:

```bash
chmod +x /opt/rohlig-app/scripts/rollback.sh
```

## 26.4 Rollback decision rule

Rollback when:

- health checks fail after deployment
- major functionality fails in smoke testing
- error rate spikes materially
- database migration issue breaks startup
- UI is reachable but API contracts are broken
- Kafka-related processing fails critically

Do not wait for a “perfect diagnosis” when a known-good image tag can restore service faster.

---

# 27. Release management and change control

A controlled delivery process matters just as much as the commands.

## 27.1 Recommended release record

For every deployment, record:

- date and time
- environment
- Git commit
- image tag
- operator or pipeline id
- change summary
- result
- rollback required or not

## 27.2 Recommended deployment gates

For `main` deployments, use these minimum gates:

- tests passed
- image build passed
- registry push passed
- manual approval for production if required by governance
- smoke checks passed
- alerting checked after deployment

---

# 28. Troubleshooting guide

This section is intentionally practical. Use it when things break.

## 28.1 Service will not start

Check container status:

```bash
cd /opt/rohlig-app/compose
docker compose ps
docker compose logs -f gateway
```

Common causes:
- bad environment variables
- database unavailable
- Kafka unavailable
- invalid image tag
- port or DNS mismatch
- startup migration failure

## 28.2 Reverse proxy returns 502 Bad Gateway

Check whether the upstream container is alive:

```bash
docker compose ps
docker compose logs -f reverse-proxy
docker compose logs -f gateway
```

Check Nginx upstream names. In Compose, the service name is the hostname. If Nginx points to `gateway:8080`, the service name must really be `gateway`.

## 28.3 Spring Boot service cannot connect to PostgreSQL

Check the database container:

```bash
docker compose logs -f postgres
docker exec -it rohlig-postgres pg_isready -U rohlig -d rohlig
```

Check the app config:

```bash
docker inspect rohlig-shipment-service | jq '.[0].Config.Env'
```

Confirm:
- correct `SPRING_DATASOURCE_URL`
- correct username and password
- database healthy
- migrations not failing

## 28.4 Spring Boot service cannot connect to Kafka

Check Kafka logs:

```bash
docker compose logs -f kafka
```

Check that services use `kafka:9092`, not a public host address, when talking inside Compose.

Confirm topic creation and advertised listeners are consistent with the network path being used.

## 28.5 Bitbucket deploy step fails with SSH issues

From the CI/CD server, test directly:

```bash
sudo -u rohligci ssh -p 22 rohligapp@app-01.rohlig.internal 'hostname'
```

Check:
- private key format
- `known_hosts`
- correct app server user
- firewall allowing SSH from CI/CD server
- file permissions in `~/.ssh`

## 28.6 Docker Compose deployment succeeds but old version is still running

Verify the tag in the environment file:

```bash
grep IMAGE_TAG /opt/rohlig-app/config/platform.env
```

Confirm the pulled image matches:

```bash
docker images | grep rohlig/gateway
```

Then recreate:

```bash
docker compose --env-file /opt/rohlig-app/config/platform.env up -d --force-recreate
```

## 28.7 High disk usage on the app server

Check disk space:

```bash
df -h
docker system df
```

Clean unused Docker objects carefully:

```bash
docker image prune -af
docker container prune -f
```

Never remove volumes casually on a running environment unless you fully understand the data impact.

## 28.8 Container restart loops

```bash
docker compose ps
docker inspect rohlig-gateway --format='{{.State.RestartCount}}'
docker compose logs --tail=200 gateway
```

Common causes:
- missing config
- bad database migration
- bad JVM memory settings
- dependency unavailable
- application startup exception

## 28.9 Application reachable but slow

Check:
- host CPU and RAM
- JVM heap sizing
- PostgreSQL contention
- Kafka backlog
- frontend asset caching
- database indexes
- log volume and disk pressure

Commands:

```bash
htop
docker stats
docker compose logs --tail=200 gateway
docker compose logs --tail=200 postgres
```

## 28.10 Pipeline Docker builds fail with memory errors

Increase Docker service memory in `bitbucket-pipelines.yml` and reduce build concurrency if necessary.

---

# 29. Operational runbook commands

These are the commands the team should know.

## 29.1 Basic application server commands

```bash
cd /opt/rohlig-app/compose
docker compose --env-file /opt/rohlig-app/config/platform.env ps
docker compose --env-file /opt/rohlig-app/config/platform.env logs -f gateway
docker compose --env-file /opt/rohlig-app/config/platform.env restart gateway
docker compose --env-file /opt/rohlig-app/config/platform.env pull
docker compose --env-file /opt/rohlig-app/config/platform.env up -d --remove-orphans
docker compose --env-file /opt/rohlig-app/config/platform.env down
```

## 29.2 Targeted logs

```bash
docker logs -f rohlig-gateway
docker logs -f rohlig-shipment-service
docker logs -f rohlig-postgres
docker logs -f rohlig-kafka
docker logs -f rohlig-reverse-proxy
```

## 29.3 Database access

```bash
docker exec -it rohlig-postgres psql -U rohlig -d rohlig
```

## 29.4 Check health endpoints

```bash
curl -fsS http://localhost:8080/actuator/health
curl -fsS https://api.estimate.rohlig.example.com/actuator/health
```

## 29.5 Docker diagnostics

```bash
docker ps -a
docker images
docker network ls
docker volume ls
docker stats
docker inspect rohlig-gateway
```

---

# 30. Hardening the deployment scripts

Use wrappers instead of typing long commands repeatedly.

## 30.1 Deployment script on the app server

Create `/opt/rohlig-app/scripts/deploy.sh`.

```bash
#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: deploy.sh <image_tag>"
  exit 1
fi

TAG="$1"
ENV_FILE="/opt/rohlig-app/config/platform.env"
COMPOSE_DIR="/opt/rohlig-app/compose"
RELEASE_LOG="/opt/rohlig-app/releases/releases.log"

sed -i "s/^IMAGE_TAG=.*/IMAGE_TAG=${TAG}/" "${ENV_FILE}"

cd "${COMPOSE_DIR}"
docker compose --env-file "${ENV_FILE}" pull
docker compose --env-file "${ENV_FILE}" up -d --remove-orphans

if curl -fsS https://api.estimate.rohlig.example.com/actuator/health > /dev/null; then
  echo "$(date '+%F %T') | ${TAG} | SUCCESS" >> "${RELEASE_LOG}"
else
  echo "$(date '+%F %T') | ${TAG} | FAILED" >> "${RELEASE_LOG}"
  exit 1
fi
```

Make it executable:

```bash
chmod +x /opt/rohlig-app/scripts/deploy.sh
```

Then your pipeline deploy step can simply call:

```bash
ssh rohligapp@app-01.rohlig.internal '/opt/rohlig-app/scripts/deploy.sh '"${BITBUCKET_COMMIT}"
```

This is cleaner and easier to support than packing too much logic directly into the pipeline YAML.

---

# 31. Example repository structure

A practical repository shape for this guide is:

```text
rohlig-platform/
├── gateway/
├── shipment-service/
├── costing-service/
├── tariff-service/
├── quotation-service/
├── rate-repository-service/
├── rates-importer-service/
├── frontend/
├── deploy/
│   ├── docker-compose.yml
│   ├── nginx/
│   ├── prometheus/
│   ├── scripts/
│   └── env/
├── bitbucket-pipelines.yml
└── README.md
```

Keep deployment assets versioned with the application. That helps ensure infra and app changes evolve together.

---

# 32. Production-readiness checklist for go-live

Use this as the final validation before calling the environment “production-style ready”.

## 32.1 Infrastructure readiness
- Both Ubuntu servers patched
- Docker Engine and Compose plugin installed
- Firewalls configured
- SSH hardened
- Hostnames and DNS confirmed
- Time synchronized correctly

## 32.2 CI/CD readiness
- Bitbucket runner online
- secured variables configured
- pipeline passes on `main`
- image push works
- deploy step works without manual shell fixes

## 32.3 Application readiness
- Angular frontend served through reverse proxy
- gateway reachable
- all services healthy
- PostgreSQL persistent volume working
- Kafka healthy
- logs visible
- health and metrics endpoints exposed internally

## 32.4 Monitoring readiness
- Prometheus scraping targets
- Grafana login works
- basic dashboards created
- alert rules configured

## 32.5 Recovery readiness
- database backups tested
- rollback tested with previous image tag
- release log retained
- support team knows the runbook commands

---

# 33. Recommended next-step evolution after this two-server phase

This two-server model is a solid starting point, but Röhlig should plan an evolution path.

Phase 1 is this document:
- Bitbucket
- self-hosted runner
- Docker Compose
- app + data + monitoring on one app server

Phase 2 should separate duties:
- database moved to managed PostgreSQL or dedicated server
- Kafka moved to a dedicated node or managed platform
- secrets moved to Vault or cloud-native secret storage
- SSO integrated with Keycloak or enterprise identity
- registry hardened and standardized
- log aggregation improved

Phase 3 should consider platform scale:
- Kubernetes or OpenShift
- GitOps-based deployment
- managed observability
- autoscaling
- higher availability across nodes

That said, do not skip operational discipline now just because future Kubernetes plans exist. A well-run Docker Compose environment is far better than a poorly run Kubernetes cluster.

---

# 34. Final recommendation

For the Röhlig platform, the best immediate implementation choice is:

- **Bitbucket** as the source of truth
- **Bitbucket Pipelines** for CI
- **Bitbucket self-hosted Linux Docker runner** on the CI/CD server for privileged and internal deployment work
- **Docker image registry** for release artifacts
- **Docker Compose** on the application server for runtime
- **Nginx** as reverse proxy and TLS termination
- **Prometheus + Grafana** for observability
- **PostgreSQL + Kafka** on the app server initially, with a clear plan to split them out later

This gives the team a controlled, repeatable, supportable path that is strong enough for a production-style internal environment, while still being realistic to implement quickly.

---

# 35. Appendix A — Quick command summary

## CI/CD server
```bash
docker ps
docker images
docker compose version
ssh rohligapp@app-01.rohlig.internal
```

## App server
```bash
cd /opt/rohlig-app/compose
docker compose --env-file /opt/rohlig-app/config/platform.env ps
docker compose --env-file /opt/rohlig-app/config/platform.env pull
docker compose --env-file /opt/rohlig-app/config/platform.env up -d --remove-orphans
docker compose --env-file /opt/rohlig-app/config/platform.env logs -f
```

## Rollback
```bash
/opt/rohlig-app/scripts/rollback.sh <previous_tag>
```

## Backup
```bash
/opt/rohlig-app/scripts/backup-postgres.sh
```

---

# 36. Appendix B — Example management deployment note

**Deployment summary**

The Röhlig platform is deployed using a two-server model. One server handles build and release control through Bitbucket Pipelines and a self-hosted runner. The second server runs the application stack using versioned Docker images orchestrated by Docker Compose. The design supports controlled releases, rollback, monitoring, and operational support without requiring Kubernetes in the first phase.

**Business value**

This gives the organization a repeatable and auditable release process, reduces manual production changes, improves supportability, and provides a clear path to future platform scale.

---

**End of document**
