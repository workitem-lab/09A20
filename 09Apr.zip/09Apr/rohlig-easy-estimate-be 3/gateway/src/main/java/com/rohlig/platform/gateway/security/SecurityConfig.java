package com.rohlig.platform.gateway.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.web.server.SecurityWebFilterChain;
import reactor.core.publisher.Mono;

@Configuration
@EnableReactiveMethodSecurity
public class SecurityConfig {

    @Bean
    SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        return http
                .csrf(ServerHttpSecurity.CsrfSpec::disable)
                .authorizeExchange(exchanges -> exchanges
                        .pathMatchers(
                                "/actuator/health",
                                "/actuator/info",
                                "/v3/api-docs/**",
                                "/swagger-ui.html",
                                "/swagger-ui/**",
                                "/api/v1/customers/health",
                                "/api/v1/shipments/health",
                                "/api/v1/tariffs/health",
                                "/api/v1/costs/health",
                                "/api/v1/quotations/health",
                                "/api/v1/rate-repository/health",
                                "/api/v1/rates-importer/health"
                        ).permitAll()
                        .pathMatchers(HttpMethod.GET, "/api/v1/auth/me").authenticated()
                        .pathMatchers(HttpMethod.POST, "/api/v1/customers/prospects").hasAnyRole("OPERATIONS_USER", "QUOTATION_USER", "CUSTOMER_ADMIN", "ADMIN")
                        .pathMatchers(HttpMethod.POST, "/api/v1/customers/registered/sync").hasAnyRole("CUSTOMER_ADMIN", "ADMIN")
                        .pathMatchers(HttpMethod.POST, "/api/v1/customers/**/link").hasAnyRole("CUSTOMER_ADMIN", "ADMIN")
                        .pathMatchers(HttpMethod.GET, "/api/v1/customers/**").hasAnyRole("OPERATIONS_USER", "QUOTATION_USER", "VIEW_ONLY", "CUSTOMER_ADMIN", "ADMIN")
                        .pathMatchers(HttpMethod.POST, "/api/v1/shipments").hasAnyRole("OPERATIONS_USER", "ADMIN")
                        .pathMatchers(HttpMethod.GET, "/api/v1/shipments/**").hasAnyRole("OPERATIONS_USER", "QUOTATION_USER", "VIEW_ONLY", "ADMIN")
                        .pathMatchers(HttpMethod.POST, "/api/v1/costs/**").hasAnyRole("OPERATIONS_USER", "QUOTATION_USER", "ADMIN")
                        .pathMatchers(HttpMethod.GET, "/api/v1/costs/**").hasAnyRole("OPERATIONS_USER", "QUOTATION_USER", "VIEW_ONLY", "ADMIN")
                        .pathMatchers(HttpMethod.GET, "/api/v1/quotations/**", "/api/v1/invoices/**").hasAnyRole("QUOTATION_USER", "VIEW_ONLY", "ADMIN")
                        .pathMatchers(HttpMethod.POST, "/api/v1/quotations/**", "/api/v1/invoices/**").hasAnyRole("QUOTATION_USER", "ADMIN")
                        .pathMatchers(HttpMethod.GET, "/api/v1/rate-repository/**").hasAnyRole("RATES_ADMIN", "OPERATIONS_USER", "QUOTATION_USER", "VIEW_ONLY", "ADMIN")
                        .pathMatchers(HttpMethod.GET, "/api/v1/rates-importer/**").hasAnyRole("RATES_ADMIN", "VIEW_ONLY", "ADMIN")
                        .pathMatchers(HttpMethod.POST, "/api/v1/rates-importer/**").hasAnyRole("RATES_ADMIN", "ADMIN")
                        .anyExchange().authenticated()
                )
                .oauth2ResourceServer(oauth2 ->
                        oauth2.jwt(jwt -> jwt.jwtAuthenticationConverter(this::jwtAuthenticationConverter))
                )
                .build();
    }

    private Mono<AbstractAuthenticationToken> jwtAuthenticationConverter(Jwt jwt) {
        return Mono.just(new JwtAuthenticationToken(jwt, KeycloakAuthorities.extract(jwt), principalName(jwt)));
    }

    private String principalName(Jwt jwt) {
        String preferredUsername = jwt.getClaimAsString("preferred_username");
        if (preferredUsername != null && !preferredUsername.isBlank()) {
            return preferredUsername;
        }

        String email = jwt.getClaimAsString("email");
        if (email != null && !email.isBlank()) {
            return email;
        }

        return jwt.getSubject();
    }
}