package com.rohlig.platform.gateway.api;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

@RestController
public class AuthController {

    @GetMapping("/api/v1/auth/me")
    public Mono<Map<String, Object>> me(Authentication authentication) {
        Jwt jwt = (Jwt) authentication.getPrincipal();
        List<String> authorities = authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).sorted().toList();
        return Mono.just(Map.of(
                "authenticated", true,
                "subject", jwt.getSubject(),
                "username", firstNonBlank(jwt.getClaimAsString("preferred_username"), jwt.getClaimAsString("email"), jwt.getSubject()),
                "name", firstNonBlank(jwt.getClaimAsString("name"), jwt.getClaimAsString("preferred_username")),
                "email", firstNonBlank(jwt.getClaimAsString("email"), jwt.getClaimAsString("preferred_username")),
                "issuer", jwt.getIssuer() == null ? "" : jwt.getIssuer().toString(),
                "authorities", authorities
        ));
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return "";
    }
}
