package com.rohlig.platform.quotation.service;

import com.rohlig.platform.quotation.domain.QuotationProjectionEntity;
import com.rohlig.platform.quotation.domain.QuotationProjectionRepository;
import com.rohlig.platform.quotation.events.CostCalculatedEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class QuotationProjectionConsumer {
    private final QuotationProjectionRepository repository;
    private final QuotationTemplateResolver templateResolver;

    public QuotationProjectionConsumer(QuotationProjectionRepository repository,
                                      QuotationTemplateResolver templateResolver) {
        this.repository = repository;
        this.templateResolver = templateResolver;
    }

    @KafkaListener(topics = "costing.calculated")
    public void handle(CostCalculatedEvent event) {
        QuotationProjectionEntity entity = new QuotationProjectionEntity();
        entity.setShipmentId(event.shipmentId());
        entity.setClientId(event.clientId());
        entity.setTotal(event.total());
        entity.setStatus("PROJECTED");
        entity.setTemplateCode(templateResolver.resolve(event.modality(), event.shipmentType()));
        repository.save(entity);
    }
}
