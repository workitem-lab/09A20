package com.rohlig.platform.quotation.events;

import java.math.BigDecimal;
import java.util.List;

public record CostCalculatedEvent(
        String shipmentId,
        String clientId,
        String modality,
        String shipmentType,
        BigDecimal freight,
        BigDecimal cartage,
        BigDecimal destinationCharges,
        BigDecimal applicableCharges,
        BigDecimal customsValue,
        BigDecimal duty,
        BigDecimal adValorem,
        BigDecimal customsVat,
        BigDecimal financeFee,
        BigDecimal total,
        List<CostLineEvent> lines
) {}
