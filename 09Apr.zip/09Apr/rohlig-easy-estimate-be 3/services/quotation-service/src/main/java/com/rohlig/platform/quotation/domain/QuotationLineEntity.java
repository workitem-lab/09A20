package com.rohlig.platform.quotation.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "quotation_lines", schema = "quotation")
public class QuotationLineEntity {
    @Id private UUID id;
    @Column(name = "snapshot_id", nullable = false) private UUID snapshotId;
    @Column(name = "section_code", nullable = false) private String sectionCode;
    @Column(name = "line_order", nullable = false) private int lineOrder;
    @Column(name = "description", nullable = false) private String description;
    @Column(name = "vat_code") private String vatCode;
    @Column(name = "calculation_basis") private String calculationBasis;
    @Column(name = "foreign_currency") private String foreignCurrency;
    @Column(name = "foreign_amount") private BigDecimal foreignAmount;
    @Column(name = "local_currency", nullable = false) private String localCurrency;
    @Column(name = "local_amount_excl", nullable = false) private BigDecimal localAmountExcl;
    @Column(name = "vat_amount", nullable = false) private BigDecimal vatAmount = BigDecimal.ZERO;
    public UUID getId() { return id; } public void setId(UUID id) { this.id = id; }
    public UUID getSnapshotId() { return snapshotId; } public void setSnapshotId(UUID snapshotId) { this.snapshotId = snapshotId; }
    public String getSectionCode() { return sectionCode; } public void setSectionCode(String sectionCode) { this.sectionCode = sectionCode; }
    public int getLineOrder() { return lineOrder; } public void setLineOrder(int lineOrder) { this.lineOrder = lineOrder; }
    public String getDescription() { return description; } public void setDescription(String description) { this.description = description; }
    public String getVatCode() { return vatCode; } public void setVatCode(String vatCode) { this.vatCode = vatCode; }
    public String getCalculationBasis() { return calculationBasis; } public void setCalculationBasis(String calculationBasis) { this.calculationBasis = calculationBasis; }
    public String getForeignCurrency() { return foreignCurrency; } public void setForeignCurrency(String foreignCurrency) { this.foreignCurrency = foreignCurrency; }
    public BigDecimal getForeignAmount() { return foreignAmount; } public void setForeignAmount(BigDecimal foreignAmount) { this.foreignAmount = foreignAmount; }
    public String getLocalCurrency() { return localCurrency; } public void setLocalCurrency(String localCurrency) { this.localCurrency = localCurrency; }
    public BigDecimal getLocalAmountExcl() { return localAmountExcl; } public void setLocalAmountExcl(BigDecimal localAmountExcl) { this.localAmountExcl = localAmountExcl; }
    public BigDecimal getVatAmount() { return vatAmount; } public void setVatAmount(BigDecimal vatAmount) { this.vatAmount = vatAmount; }
}
