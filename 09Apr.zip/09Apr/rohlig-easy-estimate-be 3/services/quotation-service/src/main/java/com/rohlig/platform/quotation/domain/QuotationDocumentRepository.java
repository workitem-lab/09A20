package com.rohlig.platform.quotation.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

public interface QuotationDocumentRepository extends JpaRepository<QuotationDocumentEntity, UUID> {
    Optional<QuotationDocumentEntity> findFirstBySnapshotIdAndFormatOrderByCreatedAtDesc(UUID snapshotId, String format);
}
