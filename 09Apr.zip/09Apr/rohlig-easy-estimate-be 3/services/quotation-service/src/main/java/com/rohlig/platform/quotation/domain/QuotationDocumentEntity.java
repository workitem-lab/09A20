package com.rohlig.platform.quotation.domain;

import jakarta.persistence.*;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "quotation_documents", schema = "quotation")
public class QuotationDocumentEntity {
    @Id private UUID id;
    @Column(name = "snapshot_id", nullable = false) private UUID snapshotId;
    @Column(name = "format", nullable = false) private String format;
    @Column(name = "file_name", nullable = false) private String fileName;
    @Column(name = "mime_type", nullable = false) private String mimeType;

    @Column(name = "file_content", nullable = false, columnDefinition = "bytea")

    private byte[] fileContent;
    @Column(name = "sha256", nullable = false) private String sha256;
    @Column(name = "created_at", nullable = false) private OffsetDateTime createdAt = OffsetDateTime.now();
    public UUID getId() { return id; } public void setId(UUID id) { this.id = id; }
    public UUID getSnapshotId() { return snapshotId; } public void setSnapshotId(UUID snapshotId) { this.snapshotId = snapshotId; }
    public String getFormat() { return format; } public void setFormat(String format) { this.format = format; }
    public String getFileName() { return fileName; } public void setFileName(String fileName) { this.fileName = fileName; }
    public String getMimeType() { return mimeType; } public void setMimeType(String mimeType) { this.mimeType = mimeType; }
    public byte[] getFileContent() { return fileContent; } public void setFileContent(byte[] fileContent) { this.fileContent = fileContent; }
    public String getSha256() { return sha256; } public void setSha256(String sha256) { this.sha256 = sha256; }
    public OffsetDateTime getCreatedAt() { return createdAt; } public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }
}
