package com.rohlig.platform.quotation.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

public interface QuotationSnapshotRepository extends JpaRepository<QuotationSnapshotEntity, UUID> {
    Optional<QuotationSnapshotEntity> findFirstByShipmentIdOrderByCreatedAtDesc(String shipmentId);
}
