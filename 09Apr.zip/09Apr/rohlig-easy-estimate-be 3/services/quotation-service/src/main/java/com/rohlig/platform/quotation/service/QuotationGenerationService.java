package com.rohlig.platform.quotation.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rohlig.platform.quotation.api.GeneratedDocumentResponse;
import com.rohlig.platform.quotation.client.CostingClient;
import com.rohlig.platform.quotation.client.ShipmentClient;
import com.rohlig.platform.quotation.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.MessageDigest;
import java.time.OffsetDateTime;
import java.util.HexFormat;
import java.util.UUID;

@Service
public class QuotationGenerationService {
    private final ShipmentClient shipmentClient;
    private final CostingClient costingClient;
    private final QuotationAssembler assembler;
    private final CsvQuotationRenderer csvRenderer;
    private final PdfQuotationRenderer pdfRenderer;
    private final QuotationSnapshotRepository snapshotRepository;
    private final QuotationLineRepository lineRepository;
    private final QuotationDocumentRepository documentRepository;
    private final QuotationProjectionRepository projectionRepository;
    private final ObjectMapper objectMapper;
    public QuotationGenerationService(ShipmentClient shipmentClient, CostingClient costingClient, QuotationAssembler assembler,
                                      CsvQuotationRenderer csvRenderer, PdfQuotationRenderer pdfRenderer,
                                      QuotationSnapshotRepository snapshotRepository, QuotationLineRepository lineRepository,
                                      QuotationDocumentRepository documentRepository, QuotationProjectionRepository projectionRepository,
                                      ObjectMapper objectMapper) {
        this.shipmentClient = shipmentClient; this.costingClient = costingClient; this.assembler = assembler;
        this.csvRenderer = csvRenderer; this.pdfRenderer = pdfRenderer; this.snapshotRepository = snapshotRepository;
        this.lineRepository = lineRepository; this.documentRepository = documentRepository; this.projectionRepository = projectionRepository;
        this.objectMapper = objectMapper;
    }
    @Transactional
    public GeneratedDocumentResponse generate(String shipmentId) {
        var shipment = shipmentClient.get(shipmentId);
        var cost = costingClient.get(shipmentId);
        var model = assembler.assemble(shipment, cost);
        var renderedCsv = csvRenderer.render(model);
        byte[] pdfBytes = pdfRenderer.render(model.estimateNumber(), renderedCsv.rows());
        UUID snapshotId = UUID.randomUUID();
        QuotationSnapshotEntity snapshot = new QuotationSnapshotEntity();
        snapshot.setId(snapshotId); snapshot.setShipmentId(model.shipmentId()); snapshot.setClientId(model.clientId());
        snapshot.setTemplateCode(model.templateCode()); snapshot.setEstimateNumber(model.estimateNumber()); snapshot.setRevision(model.revision());
        snapshot.setCurrency(model.totals().currency()); snapshot.setSubtotal(model.totals().subtotal()); snapshot.setVat(model.totals().vat());
        snapshot.setTotal(model.totals().total()); snapshot.setStatus("GENERATED");
        try { snapshot.setPayload(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(model)); }
        catch (Exception ex) { throw new IllegalStateException("Unable to serialize quotation payload", ex); }
        snapshot.setUpdatedAt(OffsetDateTime.now()); snapshotRepository.save(snapshot);
        int order = 1;
        for (var section : model.sections()) for (var line : section.lines()) {
            QuotationLineEntity entity = new QuotationLineEntity();
            entity.setId(UUID.randomUUID()); entity.setSnapshotId(snapshotId); entity.setSectionCode(section.sectionCode()); entity.setLineOrder(order++);
            entity.setDescription(line.description()); entity.setVatCode(line.vatCode()); entity.setCalculationBasis(line.calculationBasis());
            entity.setForeignCurrency(line.foreignCurrency()); entity.setForeignAmount(line.foreignAmount()); entity.setLocalCurrency(line.localCurrency());
            entity.setLocalAmountExcl(line.localAmountExcl()); entity.setVatAmount(line.vatAmount()); lineRepository.save(entity);
        }
        save(snapshotId, "CSV", model.estimateNumber()+"_Rev"+model.revision()+".csv", "text/csv", renderedCsv.bytes());
        save(snapshotId, "PDF", model.estimateNumber()+"_Rev"+model.revision()+".pdf", "application/pdf", pdfBytes);
        projectionRepository.findById(shipmentId).ifPresent(projection -> { projection.setStatus("GENERATED"); projection.setTemplateCode(model.templateCode()); projection.setTotal(model.totals().total()); projectionRepository.save(projection); });
        return new GeneratedDocumentResponse(snapshotId, shipmentId, model.estimateNumber(), "/api/v1/quotations/"+shipmentId+"/documents/csv", "/api/v1/quotations/"+shipmentId+"/documents/pdf", "GENERATED");
    }
    public byte[] download(String shipmentId, String format) {
        var snapshot = snapshotRepository.findFirstByShipmentIdOrderByCreatedAtDesc(shipmentId).orElseThrow(() -> new java.util.NoSuchElementException("Generated quotation snapshot not found"));
        return documentRepository.findFirstBySnapshotIdAndFormatOrderByCreatedAtDesc(snapshot.getId(), format.toUpperCase()).orElseThrow(() -> new java.util.NoSuchElementException("Generated document not found")).getFileContent();
    }
    private void save(UUID snapshotId, String format, String fileName, String mimeType, byte[] content) {
        QuotationDocumentEntity doc = new QuotationDocumentEntity();
        doc.setId(UUID.randomUUID()); doc.setSnapshotId(snapshotId); doc.setFormat(format); doc.setFileName(fileName); doc.setMimeType(mimeType); doc.setFileContent(content); doc.setSha256(hash(content)); documentRepository.save(doc);
    }
    private String hash(byte[] bytes) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
        catch (Exception ex) { throw new IllegalStateException("Unable to hash document bytes", ex); }
    }
}
