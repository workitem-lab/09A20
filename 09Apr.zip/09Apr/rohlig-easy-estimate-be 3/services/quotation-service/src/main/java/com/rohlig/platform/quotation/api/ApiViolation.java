package com.rohlig.platform.quotation.api;
public record ApiViolation(String field, String message) {}
