package com.rohlig.platform.quotation.client;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

public record CostRecordDto(String shipmentId, String clientId, String modality, String shipmentType,
                            BigDecimal freight, BigDecimal cartage, BigDecimal destinationCharges,
                            BigDecimal applicableCharges, BigDecimal customsValue, BigDecimal duty,
                            BigDecimal adValorem, BigDecimal customsVat, BigDecimal financeFee,
                            BigDecimal total, BigDecimal operationalTotal, BigDecimal customsTotal,
                            BigDecimal financeTotal, BigDecimal valuationBase, BigDecimal payableTotal,
                            OffsetDateTime calculatedAt, List<CostLineDto> lines) {
    public record CostLineDto(String lineType, BigDecimal amount, String currencyCode, String notes) {}
}
