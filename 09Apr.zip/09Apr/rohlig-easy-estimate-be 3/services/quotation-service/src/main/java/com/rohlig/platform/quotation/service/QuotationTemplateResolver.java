package com.rohlig.platform.quotation.service;

import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class QuotationTemplateResolver {
    private static final Map<String, String> TEMPLATE_PATHS = Map.of(
            "QUOTE_FCL_IMPORT", "quotation-templates/fcl-import/template.csv",
            "QUOTE_FCL_EXPORT", "quotation-templates/fcl-export/template.csv",
            "QUOTE_LCL_IMPORT", "quotation-templates/lcl-import/template.csv",
            "QUOTE_AIR_IMPORT", "quotation-templates/air-import/template.csv",
            "QUOTE_AIR_EXPORT", "quotation-templates/air-export/template.csv",
            "QUOTE_GENERIC", "quotation-templates/generic/template.csv"
    );

    public String resolve(String modality, String shipmentType) {
        String mod = modality == null ? "UNKNOWN" : modality.toUpperCase();
        String type = shipmentType == null ? "UNKNOWN" : shipmentType.toUpperCase();
        return switch (mod + "_" + type) {
            case "FCL_IMPORT" -> "QUOTE_FCL_IMPORT";
            case "FCL_EXPORT" -> "QUOTE_FCL_EXPORT";
            case "LCL_IMPORT" -> "QUOTE_LCL_IMPORT";
            case "AIR_IMPORT" -> "QUOTE_AIR_IMPORT";
            case "AIR_EXPORT" -> "QUOTE_AIR_EXPORT";
            default -> "QUOTE_GENERIC";
        };
    }

    public String templatePathFor(String templateCode) {
        return TEMPLATE_PATHS.getOrDefault(templateCode, TEMPLATE_PATHS.get("QUOTE_GENERIC"));
    }
}
