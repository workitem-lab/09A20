package com.rohlig.platform.quotation.document;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record QuotationDocumentModel(
        String shipmentId,
        String clientId,
        String templateCode,
        String estimateNumber,
        int revision,
        LocalDate estimateDate,
        String companyName,
        String companyVatNumber,
        String companyAddress,
        String accountTerms,
        LocalDate validUntil,
        ShipmentDetails shipment,
        List<ChargeSection> sections,
        Totals totals,
        List<String> remarks,
        List<String> termsAndConditions
) {
    public record ShipmentDetails(String shipper, String consignee, String originCountry, String destinationCountry,
                                  String portOfLoading, String portOfDestination, String finalDeliveryArea,
                                  String modality, String shipmentType, String incoterm, String carrier,
                                  BigDecimal chargeableWeight, Integer container20Qty, Integer container40Qty,
                                  BigDecimal cbm, BigDecimal goodsValue, String currency, String hsCode,
                                  BigDecimal unitQuantity) {}
    public record ChargeSection(String sectionCode, String title, List<ChargeLine> lines) {}
    public record ChargeLine(String description, String vatCode, String calculationBasis, String foreignCurrency,
                             BigDecimal foreignAmount, String localCurrency, BigDecimal localAmountExcl,
                             BigDecimal vatAmount) {}
    public record Totals(BigDecimal subtotal, BigDecimal vat, BigDecimal total, String currency) {}
}
