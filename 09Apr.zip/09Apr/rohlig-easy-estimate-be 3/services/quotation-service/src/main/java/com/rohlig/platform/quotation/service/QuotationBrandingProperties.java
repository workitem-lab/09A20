package com.rohlig.platform.quotation.service;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.math.BigDecimal;

@ConfigurationProperties(prefix = "quotation.branding")
public record QuotationBrandingProperties(
        String companyName,
        String vatNumber,
        String companyAddress,
        String accountTerms,
        int validityDays,
        String localCurrency,
        BigDecimal vatRate
) {
}
