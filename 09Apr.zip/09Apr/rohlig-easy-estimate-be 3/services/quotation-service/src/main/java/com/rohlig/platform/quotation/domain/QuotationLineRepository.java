package com.rohlig.platform.quotation.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface QuotationLineRepository extends JpaRepository<QuotationLineEntity, UUID> {
    List<QuotationLineEntity> findBySnapshotIdOrderBySectionCodeAscLineOrderAsc(UUID snapshotId);
}
