package com.rohlig.platform.quotation.service;

import com.rohlig.platform.quotation.domain.QuotationProjectionEntity;
import com.rohlig.platform.quotation.domain.QuotationProjectionRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.NoSuchElementException;

@Service
public class QuotationService {
    private final QuotationProjectionRepository repository;

    public QuotationService(QuotationProjectionRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public QuotationProjectionEntity get(String shipmentId) {
        return repository.findById(shipmentId).orElseThrow(() -> new NoSuchElementException("Quotation projection not found"));
    }

    @Transactional(readOnly = true)
    public Page<QuotationProjectionEntity> search(String clientId, String status, Pageable pageable) {
        return repository.search(clientId, status, pageable);
    }
}
