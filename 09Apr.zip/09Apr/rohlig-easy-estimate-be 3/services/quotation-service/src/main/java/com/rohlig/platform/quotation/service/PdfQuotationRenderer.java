package com.rohlig.platform.quotation.service;

import com.lowagie.text.Document;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Component
public class PdfQuotationRenderer {
    public byte[] render(String title, List<String> csvRows) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            Document document = new Document();
            PdfWriter.getInstance(document, out);
            document.open();
            document.add(new Paragraph(title, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16)));
            document.add(new Paragraph("Generated from quotation data"));
            document.add(new Paragraph(" "));

            PdfPTable table = new PdfPTable(6);
            table.setWidthPercentage(100);
            for (String header : new String[]{"Section", "Description", "VAT", "Basis", "Currency", "Amount"}) {
                PdfPCell cell = new PdfPCell(new Phrase(header, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10)));
                table.addCell(cell);
            }

            String csv = String.join(System.lineSeparator(), csvRows);
            try (CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader(csv))) {
                for (CSVRecord record : parser) {
                    if (record.size() < 6) {
                        continue;
                    }
                    String first = record.get(0);
                    if ("Field".equalsIgnoreCase(first) || "Section".equalsIgnoreCase(first) || first.isBlank()) {
                        continue;
                    }
                    for (int i = 0; i < 6; i++) {
                        table.addCell(record.get(i));
                    }
                }
            }

            document.add(table);
            document.close();
            return out.toByteArray();
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to render PDF", ex);
        }
    }
}
