package com.rohlig.platform.quotation.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "quotation_snapshots", schema = "quotation")
public class QuotationSnapshotEntity {
    @Id private UUID id;
    @Column(name = "shipment_id", nullable = false) private String shipmentId;
    @Column(name = "client_id", nullable = false) private String clientId;
    @Column(name = "template_code", nullable = false) private String templateCode;
    @Column(name = "estimate_number", nullable = false) private String estimateNumber;
    @Column(name = "revision", nullable = false) private int revision;
    @Column(name = "currency", nullable = false) private String currency;
    @Column(name = "subtotal", nullable = false) private BigDecimal subtotal;
    @Column(name = "vat", nullable = false) private BigDecimal vat;
    @Column(name = "total", nullable = false) private BigDecimal total;
    @Column(name = "status", nullable = false) private String status;
    @Column(name = "payload", nullable = false, columnDefinition = "TEXT") private String payload;
    @Column(name = "created_at", nullable = false) private OffsetDateTime createdAt = OffsetDateTime.now();
    @Column(name = "updated_at", nullable = false) private OffsetDateTime updatedAt = OffsetDateTime.now();
    public UUID getId() { return id; } public void setId(UUID id) { this.id = id; }
    public String getShipmentId() { return shipmentId; } public void setShipmentId(String shipmentId) { this.shipmentId = shipmentId; }
    public String getClientId() { return clientId; } public void setClientId(String clientId) { this.clientId = clientId; }
    public String getTemplateCode() { return templateCode; } public void setTemplateCode(String templateCode) { this.templateCode = templateCode; }
    public String getEstimateNumber() { return estimateNumber; } public void setEstimateNumber(String estimateNumber) { this.estimateNumber = estimateNumber; }
    public int getRevision() { return revision; } public void setRevision(int revision) { this.revision = revision; }
    public String getCurrency() { return currency; } public void setCurrency(String currency) { this.currency = currency; }
    public BigDecimal getSubtotal() { return subtotal; } public void setSubtotal(BigDecimal subtotal) { this.subtotal = subtotal; }
    public BigDecimal getVat() { return vat; } public void setVat(BigDecimal vat) { this.vat = vat; }
    public BigDecimal getTotal() { return total; } public void setTotal(BigDecimal total) { this.total = total; }
    public String getStatus() { return status; } public void setStatus(String status) { this.status = status; }
    public String getPayload() { return payload; } public void setPayload(String payload) { this.payload = payload; }
    public OffsetDateTime getCreatedAt() { return createdAt; } public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; } public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }
}
