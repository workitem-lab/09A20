package com.rohlig.platform.quotation.domain;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface QuotationProjectionRepository extends JpaRepository<QuotationProjectionEntity, String> {

    @Query("""
            select q from QuotationProjectionEntity q
            where (:clientId is null or q.clientId = :clientId)
              and (:status is null or upper(q.status) = upper(:status))
            """)
    Page<QuotationProjectionEntity> search(@Param("clientId") String clientId,
                                           @Param("status") String status,
                                           Pageable pageable);
}
