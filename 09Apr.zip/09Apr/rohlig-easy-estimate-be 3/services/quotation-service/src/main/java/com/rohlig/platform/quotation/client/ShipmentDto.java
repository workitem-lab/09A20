package com.rohlig.platform.quotation.client;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public record ShipmentDto(String shipmentId, String clientId, String modality, String shipmentType, String incoterm,
                          String originCountry, String destinationCountry, String portOfLoading,
                          String portOfDestination, String finalDeliveryArea, String carrier,
                          BigDecimal chargeableWeight, Integer container20Qty, Integer container40Qty,
                          BigDecimal cbm, BigDecimal goodsValue, String currency, String hsCode,
                          BigDecimal unitQuantity, boolean tradeLaneAgreement, OffsetDateTime createdAt) {}
