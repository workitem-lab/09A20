package com.rohlig.platform.quotation.api;

import java.util.UUID;

public record GeneratedDocumentResponse(UUID snapshotId, String shipmentId, String estimateNumber,
                                        String csvDownloadPath, String pdfDownloadPath, String status) {}
