package com.rohlig.platform.quotation;

import com.rohlig.platform.quotation.service.QuotationBrandingProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(QuotationBrandingProperties.class)
public class QuotationServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(QuotationServiceApplication.class, args);
    }
}
