package com.rohlig.platform.quotation.events;

import java.math.BigDecimal;

public record CostLineEvent(String type, BigDecimal amount, String currency, String notes) {}
