package com.rohlig.platform.quotation.client;

import com.rohlig.platform.quotation.security.ServiceAccessTokenProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class CostingClient {
    private final RestClient restClient;
    private final ServiceAccessTokenProvider tokenProvider;

    public CostingClient(@Value("${quotation.services.costing-base-url}") String baseUrl,
                         RestClient.Builder builder,
                         ServiceAccessTokenProvider tokenProvider) {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(5000);
        requestFactory.setReadTimeout(10000);
        this.restClient = builder.requestFactory(requestFactory).baseUrl(baseUrl).build();
        this.tokenProvider = tokenProvider;
    }

    public CostRecordDto get(String shipmentId) {
        return restClient.get()
                .uri("/api/v1/costs/{shipmentId}", shipmentId)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenProvider.getAccessToken())
                .retrieve()
                .body(CostRecordDto.class);
    }
}
