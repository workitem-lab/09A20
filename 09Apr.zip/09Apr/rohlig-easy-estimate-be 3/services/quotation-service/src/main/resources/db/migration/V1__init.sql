CREATE SCHEMA IF NOT EXISTS quotation;

CREATE TABLE quotation.quotation_projections (
    shipment_id VARCHAR(64) PRIMARY KEY,
    client_id VARCHAR(64) NOT NULL,
    template_code VARCHAR(64) NOT NULL,
    total NUMERIC(18,2) NOT NULL,
    status VARCHAR(32) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
