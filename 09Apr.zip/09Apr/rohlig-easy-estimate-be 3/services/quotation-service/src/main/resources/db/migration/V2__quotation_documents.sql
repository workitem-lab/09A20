CREATE TABLE IF NOT EXISTS quotation.quotation_snapshots (
    id UUID PRIMARY KEY,
    shipment_id VARCHAR(64) NOT NULL,
    client_id VARCHAR(64) NOT NULL,
    template_code VARCHAR(64) NOT NULL,
    estimate_number VARCHAR(64) NOT NULL,
    revision INTEGER NOT NULL DEFAULT 1,
    currency VARCHAR(16) NOT NULL,
    subtotal NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat NUMERIC(18,2) NOT NULL DEFAULT 0,
    total NUMERIC(18,2) NOT NULL DEFAULT 0,
    status VARCHAR(32) NOT NULL,
    payload TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_quotation_snapshots_shipment_id ON quotation.quotation_snapshots(shipment_id);
CREATE TABLE IF NOT EXISTS quotation.quotation_lines (
    id UUID PRIMARY KEY,
    snapshot_id UUID NOT NULL REFERENCES quotation.quotation_snapshots(id) ON DELETE CASCADE,
    section_code VARCHAR(32) NOT NULL,
    line_order INTEGER NOT NULL,
    description VARCHAR(500) NOT NULL,
    vat_code VARCHAR(32),
    calculation_basis VARCHAR(64),
    foreign_currency VARCHAR(16),
    foreign_amount NUMERIC(18,2),
    local_currency VARCHAR(16) NOT NULL,
    local_amount_excl NUMERIC(18,2) NOT NULL,
    vat_amount NUMERIC(18,2) NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_quotation_lines_snapshot ON quotation.quotation_lines(snapshot_id);
CREATE TABLE IF NOT EXISTS quotation.quotation_documents (
    id UUID PRIMARY KEY,
    snapshot_id UUID NOT NULL REFERENCES quotation.quotation_snapshots(id) ON DELETE CASCADE,
    format VARCHAR(16) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(128) NOT NULL,
    file_content BYTEA NOT NULL,
    sha256 VARCHAR(128) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
