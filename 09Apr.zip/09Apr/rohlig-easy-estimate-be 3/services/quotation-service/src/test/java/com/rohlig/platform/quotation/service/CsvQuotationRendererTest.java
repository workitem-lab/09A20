package com.rohlig.platform.quotation.service;

import com.rohlig.platform.quotation.document.QuotationDocumentModel;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

class CsvQuotationRendererTest {

    private final CsvQuotationRenderer renderer = new CsvQuotationRenderer(new QuotationTemplateResolver());

    @Test
    void shouldRenderConfiguredTemplate() {
        QuotationDocumentModel model = new QuotationDocumentModel(
                "SHIP-100",
                "CLIENT-100",
                "QUOTE_FCL_IMPORT",
                "EST-100",
                1,
                LocalDate.of(2026, 4, 7),
                "Rohlig",
                "VAT123",
                "Address",
                "30 DAYS",
                LocalDate.of(2026, 4, 14),
                new QuotationDocumentModel.ShipmentDetails(
                        "shipper", "consignee", "China", "South Africa", "Shanghai", "Johannesburg", "Johannesburg",
                        "FCL", "IMPORT", "FOB", "MAERSK", BigDecimal.ZERO, 1, 1, BigDecimal.ZERO, new BigDecimal("50000"),
                        "USD", "19019013", new BigDecimal("100")
                ),
                List.of(
                        new QuotationDocumentModel.ChargeSection("FREIGHT", "Freight Charges", List.of(
                                new QuotationDocumentModel.ChargeLine("Base Freight", "Z", "PER_SHIPMENT", null, null, "ZAR", new BigDecimal("3500.00"), BigDecimal.ZERO)
                        )),
                        new QuotationDocumentModel.ChargeSection("DESTINATION", "Destination Charges", List.of()),
                        new QuotationDocumentModel.ChargeSection("CUSTOMS", "Customs and Finance", List.of())
                ),
                new QuotationDocumentModel.Totals(new BigDecimal("3500.00"), new BigDecimal("525.00"), new BigDecimal("4025.00"), "ZAR"),
                List.of(),
                List.of()
        );

        var csv = renderer.render(model);
        String content = new String(csv.bytes());

        assertTrue(content.contains("EST-100"));
        assertTrue(content.contains("Freight Charges"));
        assertTrue(content.contains("3500.00"));
    }
}
