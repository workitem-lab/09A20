package com.rohlig.platform.quotation.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class QuotationTemplateResolverTest {

    private final QuotationTemplateResolver resolver = new QuotationTemplateResolver();

    @Test
    void shouldResolveKnownTemplateCodes() {
        assertEquals("QUOTE_FCL_IMPORT", resolver.resolve("FCL", "IMPORT"));
        assertEquals("quotation-templates/fcl-import/template.csv", resolver.templatePathFor("QUOTE_FCL_IMPORT"));
        assertEquals("QUOTE_GENERIC", resolver.resolve("ROAD", "EXPORT"));
        assertEquals("quotation-templates/generic/template.csv", resolver.templatePathFor("UNKNOWN_TEMPLATE"));
    }
}
