package com.rohlig.platform.customer.integration.service;

import com.rohlig.platform.customer.integration.api.CreateProspectCustomerRequest;
import com.rohlig.platform.customer.integration.api.LinkRegisteredCustomerRequest;
import com.rohlig.platform.customer.integration.domain.CustomerIdentityEntity;
import com.rohlig.platform.customer.integration.domain.CustomerIdentityRepository;
import com.rohlig.platform.customer.integration.domain.CustomerStatus;
import com.rohlig.platform.customer.integration.domain.CustomerSyncBatchRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

class CustomerIdentityServiceTest {
    @Test
    void createsProspectCustomer() {
        CustomerIdentityRepository repository = Mockito.mock(CustomerIdentityRepository.class);
        CustomerSyncBatchRepository batchRepository = Mockito.mock(CustomerSyncBatchRepository.class);
        Mockito.when(repository.save(any(CustomerIdentityEntity.class))).thenAnswer(i -> i.getArgument(0));
        Mockito.when(repository.findById(any())).thenReturn(Optional.empty());

        CustomerIdentityService service = new CustomerIdentityService(repository, batchRepository);
        CustomerIdentityEntity saved = service.createProspect(new CreateProspectCustomerRequest("EE-PROSPECT-001", "Prospect One", "EASY_ESTIMATE"));

        assertEquals(CustomerStatus.PROSPECT, saved.getCustomerStatus());
        assertEquals("EE-PROSPECT-001", saved.getEasyEstimateClientId());
    }

    @Test
    void linksProspectToRegisteredCustomer() {
        CustomerIdentityRepository repository = Mockito.mock(CustomerIdentityRepository.class);
        CustomerSyncBatchRepository batchRepository = Mockito.mock(CustomerSyncBatchRepository.class);
        CustomerIdentityEntity existing = new CustomerIdentityEntity();
        existing.setEasyEstimateClientId("EE-PROSPECT-001");
        existing.setCustomerStatus(CustomerStatus.PROSPECT);
        existing.setCustomerName("Prospect One");
        existing.setSourceSystem("EASY_ESTIMATE");
        Mockito.when(repository.findById("EE-PROSPECT-001")).thenReturn(Optional.of(existing));
        Mockito.when(repository.save(any(CustomerIdentityEntity.class))).thenAnswer(i -> i.getArgument(0));

        CustomerIdentityService service = new CustomerIdentityService(repository, batchRepository);
        CustomerIdentityEntity linked = service.linkRegistered("EE-PROSPECT-001", new LinkRegisteredCustomerRequest("SHIP001", "Customer One", "SHIPSHIP"));

        assertEquals(CustomerStatus.REGISTERED, linked.getCustomerStatus());
        assertEquals("SHIP001", linked.getShipshipClientCode());
    }
}
