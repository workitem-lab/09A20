CREATE SCHEMA IF NOT EXISTS customer;

CREATE TABLE IF NOT EXISTS customer.customer_identity_mappings (
    easy_estimate_client_id VARCHAR(64) PRIMARY KEY,
    shipship_client_code VARCHAR(64) UNIQUE,
    customer_status VARCHAR(24) NOT NULL,
    customer_name VARCHAR(256) NOT NULL,
    source_system VARCHAR(64) NOT NULL,
    linked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS customer.customer_sync_batches (
    id BIGSERIAL PRIMARY KEY,
    batch_reference VARCHAR(128) NOT NULL UNIQUE,
    source_system VARCHAR(64) NOT NULL,
    status VARCHAR(32) NOT NULL,
    processed_count INTEGER NOT NULL DEFAULT 0,
    failed_count INTEGER NOT NULL DEFAULT 0,
    notes VARCHAR(1024),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_customer_identity_status ON customer.customer_identity_mappings(customer_status);
CREATE INDEX IF NOT EXISTS idx_customer_identity_shipship_code ON customer.customer_identity_mappings(shipship_client_code);
