package com.rohlig.platform.customer.integration.domain;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface CustomerIdentityRepository extends JpaRepository<CustomerIdentityEntity, String> {
    Optional<CustomerIdentityEntity> findByShipshipClientCode(String shipshipClientCode);

    @Query("""
            select c from CustomerIdentityEntity c
            where (:status is null or c.customerStatus = :status)
              and (:search is null or lower(c.easyEstimateClientId) like lower(concat('%', :search, '%'))
                   or lower(c.customerName) like lower(concat('%', :search, '%'))
                   or lower(coalesce(c.shipshipClientCode, '')) like lower(concat('%', :search, '%')))
            order by c.createdAt desc
            """)
    Page<CustomerIdentityEntity> search(@Param("status") CustomerStatus status, @Param("search") String search, Pageable pageable);
}
