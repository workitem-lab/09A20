package com.rohlig.platform.customer.integration.api;

import jakarta.validation.constraints.NotBlank;

public record CreateProspectCustomerRequest(
        String easyEstimateClientId,
        @NotBlank String customerName,
        String sourceSystem
) {}
