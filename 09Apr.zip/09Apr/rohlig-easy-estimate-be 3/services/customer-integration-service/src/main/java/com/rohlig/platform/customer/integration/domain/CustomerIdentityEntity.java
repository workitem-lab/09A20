package com.rohlig.platform.customer.integration.domain;

import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(name = "customer_identity_mappings", schema = "customer")
public class CustomerIdentityEntity {
    @Id
    @Column(name = "easy_estimate_client_id", nullable = false, length = 64)
    private String easyEstimateClientId;

    @Column(name = "shipship_client_code", length = 64, unique = true)
    private String shipshipClientCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "customer_status", nullable = false, length = 24)
    private CustomerStatus customerStatus;

    @Column(name = "customer_name", nullable = false, length = 256)
    private String customerName;

    @Column(name = "source_system", nullable = false, length = 64)
    private String sourceSystem;

    @Column(name = "linked_at")
    private OffsetDateTime linkedAt;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt = OffsetDateTime.now();

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt = OffsetDateTime.now();

    @Column(name = "active", nullable = false)
    private boolean active = true;

    public String getEasyEstimateClientId() { return easyEstimateClientId; }
    public void setEasyEstimateClientId(String easyEstimateClientId) { this.easyEstimateClientId = easyEstimateClientId; }
    public String getShipshipClientCode() { return shipshipClientCode; }
    public void setShipshipClientCode(String shipshipClientCode) { this.shipshipClientCode = shipshipClientCode; }
    public CustomerStatus getCustomerStatus() { return customerStatus; }
    public void setCustomerStatus(CustomerStatus customerStatus) { this.customerStatus = customerStatus; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public String getSourceSystem() { return sourceSystem; }
    public void setSourceSystem(String sourceSystem) { this.sourceSystem = sourceSystem; }
    public OffsetDateTime getLinkedAt() { return linkedAt; }
    public void setLinkedAt(OffsetDateTime linkedAt) { this.linkedAt = linkedAt; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        if (createdAt == null) createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}
