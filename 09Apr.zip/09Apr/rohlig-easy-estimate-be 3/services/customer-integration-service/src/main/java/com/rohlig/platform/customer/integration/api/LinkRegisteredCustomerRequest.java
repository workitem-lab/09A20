package com.rohlig.platform.customer.integration.api;

import jakarta.validation.constraints.NotBlank;

public record LinkRegisteredCustomerRequest(
        @NotBlank String shipshipClientCode,
        @NotBlank String customerName,
        String sourceSystem
) {}
