package com.rohlig.platform.customer.integration.api;

import com.rohlig.platform.customer.integration.domain.CustomerStatus;
import com.rohlig.platform.customer.integration.service.CustomerIdentityService;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {
    private final CustomerIdentityService service;

    public CustomerController(CustomerIdentityService service) {
        this.service = service;
    }

    @GetMapping("/health")
    public String health() { return "customer-integration-service running"; }

    @PostMapping("/prospects")
    public CustomerIdentityResponse createProspect(@Valid @RequestBody CreateProspectCustomerRequest request) {
        return CustomerIdentityResponse.from(service.createProspect(request));
    }

    @PostMapping("/{easyEstimateClientId}/link")
    public CustomerIdentityResponse linkRegistered(@PathVariable String easyEstimateClientId,
                                                   @Valid @RequestBody LinkRegisteredCustomerRequest request) {
        return CustomerIdentityResponse.from(service.linkRegistered(easyEstimateClientId, request));
    }

    @PostMapping("/registered/sync")
    public SyncBatchResponse syncRegistered(@Valid @RequestBody SyncRegisteredCustomerRequest request) {
        return service.syncRegisteredCustomers(request);
    }

    @GetMapping("/{easyEstimateClientId}")
    public CustomerIdentityResponse get(@PathVariable String easyEstimateClientId) {
        return CustomerIdentityResponse.from(service.get(easyEstimateClientId));
    }

    @GetMapping("/resolve/by-shipship/{shipshipClientCode}")
    public CustomerIdentityResponse getByShipship(@PathVariable String shipshipClientCode) {
        return CustomerIdentityResponse.from(service.getByShipshipCode(shipshipClientCode));
    }

    @GetMapping
    public PageResponse<CustomerIdentityResponse> search(@RequestParam(required = false) CustomerStatus status,
                                                         @RequestParam(required = false) String search,
                                                         @RequestParam(defaultValue = "0") int page,
                                                         @RequestParam(defaultValue = "20") int size) {
        var result = service.search(status, search, PageRequest.of(page, Math.min(size, 100)));
        return new PageResponse<>(result.getContent().stream().map(CustomerIdentityResponse::from).toList(),
                result.getTotalElements(), result.getTotalPages(), result.getNumber(), result.getSize());
    }
}
