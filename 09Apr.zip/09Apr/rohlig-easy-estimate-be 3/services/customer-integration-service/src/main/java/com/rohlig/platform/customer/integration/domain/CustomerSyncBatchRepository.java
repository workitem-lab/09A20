package com.rohlig.platform.customer.integration.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerSyncBatchRepository extends JpaRepository<CustomerSyncBatchEntity, Long> {}
