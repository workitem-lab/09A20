package com.rohlig.platform.customer.integration.domain;

public enum CustomerStatus {
    PROSPECT,
    REGISTERED
}
