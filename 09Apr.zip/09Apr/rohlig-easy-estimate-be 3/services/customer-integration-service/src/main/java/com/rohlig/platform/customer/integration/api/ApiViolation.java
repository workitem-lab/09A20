package com.rohlig.platform.customer.integration.api;

public record ApiViolation(String field, String message) {}
