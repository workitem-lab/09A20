package com.rohlig.platform.customer.integration.service;

import com.rohlig.platform.customer.integration.api.CreateProspectCustomerRequest;
import com.rohlig.platform.customer.integration.api.LinkRegisteredCustomerRequest;
import com.rohlig.platform.customer.integration.api.SyncBatchResponse;
import com.rohlig.platform.customer.integration.api.SyncRegisteredCustomerRequest;
import com.rohlig.platform.customer.integration.domain.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.NoSuchElementException;
import java.util.UUID;

@Service
public class CustomerIdentityService {
    private final CustomerIdentityRepository repository;
    private final CustomerSyncBatchRepository syncBatchRepository;

    public CustomerIdentityService(CustomerIdentityRepository repository, CustomerSyncBatchRepository syncBatchRepository) {
        this.repository = repository;
        this.syncBatchRepository = syncBatchRepository;
    }

    @Transactional
    public CustomerIdentityEntity createProspect(CreateProspectCustomerRequest request) {
        String easyEstimateClientId = request.easyEstimateClientId() == null || request.easyEstimateClientId().isBlank()
                ? "EE-PROSPECT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase()
                : request.easyEstimateClientId();

        repository.findById(easyEstimateClientId).ifPresent(existing -> { throw new IllegalArgumentException("easy_estimate_client_id already exists"); });

        CustomerIdentityEntity entity = new CustomerIdentityEntity();
        entity.setEasyEstimateClientId(easyEstimateClientId);
        entity.setCustomerStatus(CustomerStatus.PROSPECT);
        entity.setCustomerName(request.customerName());
        entity.setSourceSystem(request.sourceSystem() == null || request.sourceSystem().isBlank() ? "EASY_ESTIMATE" : request.sourceSystem());
        entity.setLinkedAt(null);
        return repository.save(entity);
    }

    @Transactional
    public CustomerIdentityEntity linkRegistered(String easyEstimateClientId, LinkRegisteredCustomerRequest request) {
        CustomerIdentityEntity entity = repository.findById(easyEstimateClientId)
                .orElseThrow(() -> new NoSuchElementException("Customer mapping not found"));
        entity.setShipshipClientCode(request.shipshipClientCode());
        entity.setCustomerStatus(CustomerStatus.REGISTERED);
        entity.setCustomerName(request.customerName());
        entity.setSourceSystem(request.sourceSystem() == null || request.sourceSystem().isBlank() ? "SHIPSHIP" : request.sourceSystem());
        entity.setLinkedAt(OffsetDateTime.now());
        return repository.save(entity);
    }

    @Transactional
    public SyncBatchResponse syncRegisteredCustomers(SyncRegisteredCustomerRequest request) {
        int processed = 0;
        int failed = 0;
        for (var customer : request.customers()) {
            try {
                CustomerIdentityEntity entity = repository.findById(customer.easyEstimateClientId()).orElseGet(CustomerIdentityEntity::new);
                entity.setEasyEstimateClientId(customer.easyEstimateClientId());
                entity.setShipshipClientCode(customer.shipshipClientCode());
                entity.setCustomerStatus(CustomerStatus.REGISTERED);
                entity.setCustomerName(customer.customerName());
                entity.setSourceSystem(request.sourceSystem() == null || request.sourceSystem().isBlank() ? "SHIPSHIP" : request.sourceSystem());
                if (entity.getLinkedAt() == null) entity.setLinkedAt(OffsetDateTime.now());
                repository.save(entity);
                processed++;
            } catch (Exception ex) {
                failed++;
            }
        }

        CustomerSyncBatchEntity batch = new CustomerSyncBatchEntity();
        batch.setBatchReference(request.batchReference());
        batch.setSourceSystem(request.sourceSystem() == null || request.sourceSystem().isBlank() ? "SHIPSHIP" : request.sourceSystem());
        batch.setStatus(failed == 0 ? "COMPLETED" : (processed == 0 ? "FAILED" : "PARTIAL"));
        batch.setProcessedCount(processed);
        batch.setFailedCount(failed);
        batch.setNotes("Registered customer sync processed by Easy Estimate customer integration service");
        syncBatchRepository.save(batch);
        return new SyncBatchResponse(batch.getBatchReference(), batch.getStatus(), processed, failed, batch.getNotes());
    }

    @Transactional(readOnly = true)
    public CustomerIdentityEntity get(String easyEstimateClientId) {
        return repository.findById(easyEstimateClientId).orElseThrow(() -> new NoSuchElementException("Customer mapping not found"));
    }

    @Transactional(readOnly = true)
    public CustomerIdentityEntity getByShipshipCode(String shipshipClientCode) {
        return repository.findByShipshipClientCode(shipshipClientCode).orElseThrow(() -> new NoSuchElementException("ShipShip client not found"));
    }

    @Transactional(readOnly = true)
    public Page<CustomerIdentityEntity> search(CustomerStatus status, String search, Pageable pageable) {
        return repository.search(status, search, pageable);
    }
}
