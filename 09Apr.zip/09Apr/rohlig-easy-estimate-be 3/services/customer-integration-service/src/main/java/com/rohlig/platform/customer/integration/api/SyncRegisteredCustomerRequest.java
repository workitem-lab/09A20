package com.rohlig.platform.customer.integration.api;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record SyncRegisteredCustomerRequest(
        @NotBlank String batchReference,
        String sourceSystem,
        @NotEmpty List<@Valid RegisteredCustomerRecord> customers
) {
    public record RegisteredCustomerRecord(
            @NotBlank String easyEstimateClientId,
            @NotBlank String shipshipClientCode,
            @NotBlank String customerName
    ) {}
}
