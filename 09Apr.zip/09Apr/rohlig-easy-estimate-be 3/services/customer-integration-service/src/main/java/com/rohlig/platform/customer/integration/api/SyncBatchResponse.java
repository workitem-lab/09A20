package com.rohlig.platform.customer.integration.api;

public record SyncBatchResponse(String batchReference, String status, int processedCount, int failedCount, String notes) {}
