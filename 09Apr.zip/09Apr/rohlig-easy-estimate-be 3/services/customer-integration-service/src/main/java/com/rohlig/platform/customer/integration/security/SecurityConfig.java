package com.rohlig.platform.customer.integration.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.web.SecurityFilterChain;

import java.util.function.Function;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/actuator/health", "/actuator/info", "/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html", "/api/v1/customers/health").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/v1/customers/prospects").hasAnyRole("OPERATIONS_USER", "QUOTATION_USER", "CUSTOMER_ADMIN", "ADMIN")
                        .requestMatchers(HttpMethod.POST, "/api/v1/customers/registered/sync").hasAnyRole("CUSTOMER_ADMIN", "ADMIN")
                        .requestMatchers(HttpMethod.POST, "/api/v1/customers/*/link").hasAnyRole("CUSTOMER_ADMIN", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/v1/customers/**").hasAnyRole("OPERATIONS_USER", "QUOTATION_USER", "VIEW_ONLY", "CUSTOMER_ADMIN", "ADMIN")
                        .anyRequest().authenticated())
                .oauth2ResourceServer(oauth -> oauth.jwt(jwt -> jwt.jwtAuthenticationConverter(jwtAuthenticationConverter())))
                .build();
    }

    private Function<Jwt, AbstractAuthenticationToken> jwtAuthenticationConverter() {
        return jwt -> new JwtAuthenticationToken(jwt, KeycloakAuthorities.extract(jwt), jwt.getClaimAsString("preferred_username"));
    }
}
