package com.rohlig.platform.customer.integration.api;

import java.time.OffsetDateTime;
import java.util.List;

public record ApiErrorResponse(OffsetDateTime timestamp, int status, String error, String message, String path, List<ApiViolation> violations) {}
