package com.rohlig.platform.customer.integration.api;

import com.rohlig.platform.customer.integration.domain.CustomerIdentityEntity;
import com.rohlig.platform.customer.integration.domain.CustomerStatus;

import java.time.OffsetDateTime;

public record CustomerIdentityResponse(
        String easyEstimateClientId,
        String shipshipClientCode,
        CustomerStatus customerStatus,
        String customerName,
        String sourceSystem,
        OffsetDateTime linkedAt,
        OffsetDateTime createdAt,
        OffsetDateTime updatedAt,
        boolean active
) {
    public static CustomerIdentityResponse from(CustomerIdentityEntity entity) {
        return new CustomerIdentityResponse(
                entity.getEasyEstimateClientId(),
                entity.getShipshipClientCode(),
                entity.getCustomerStatus(),
                entity.getCustomerName(),
                entity.getSourceSystem(),
                entity.getLinkedAt(),
                entity.getCreatedAt(),
                entity.getUpdatedAt(),
                entity.isActive()
        );
    }
}
