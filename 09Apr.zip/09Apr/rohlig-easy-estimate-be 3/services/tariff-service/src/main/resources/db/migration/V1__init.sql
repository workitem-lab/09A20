CREATE SCHEMA IF NOT EXISTS tariff;

CREATE TABLE tariff.freight_rates (
    id BIGSERIAL PRIMARY KEY,
    modality VARCHAR(16) NOT NULL,
    unit VARCHAR(32) NOT NULL,
    min_weight NUMERIC(18,3),
    max_weight NUMERIC(18,3),
    rate NUMERIC(18,2) NOT NULL
);

CREATE TABLE tariff.cartage_rates (
    id BIGSERIAL PRIMARY KEY,
    modality VARCHAR(16) NOT NULL,
    area VARCHAR(128) NOT NULL,
    amount NUMERIC(18,2) NOT NULL
);

CREATE TABLE tariff.destination_charge_rules (
    id BIGSERIAL PRIMARY KEY,
    modality VARCHAR(16) NOT NULL,
    shipment_type VARCHAR(16) NOT NULL,
    incoterm VARCHAR(16) NOT NULL,
    amount NUMERIC(18,2) NOT NULL,
    minimum_charge NUMERIC(18,2) DEFAULT 0
);

CREATE TABLE tariff.applicable_charge_rules (
    id BIGSERIAL PRIMARY KEY,
    client_id VARCHAR(64) NOT NULL,
    modality VARCHAR(16) NOT NULL,
    shipment_type VARCHAR(16) NOT NULL,
    code VARCHAR(32) NOT NULL,
    calc_type VARCHAR(32) NOT NULL,
    value NUMERIC(18,4) NOT NULL,
    minimum NUMERIC(18,2) DEFAULT 0,
    condition_value VARCHAR(64)
);

CREATE TABLE tariff.customs_rules (
    id BIGSERIAL PRIMARY KEY,
    hs_code VARCHAR(32) NOT NULL,
    region VARCHAR(64) NOT NULL,
    duty_type VARCHAR(32) NOT NULL,
    duty_value NUMERIC(18,4) NOT NULL,
    ad_valorem_type VARCHAR(32) NOT NULL,
    ad_valorem_value NUMERIC(18,4) NOT NULL
);

CREATE TABLE tariff.finance_rules (
    id BIGSERIAL PRIMARY KEY,
    client_id VARCHAR(64) NOT NULL,
    modality VARCHAR(16) NOT NULL,
    shipment_type VARCHAR(16) NOT NULL,
    percentage NUMERIC(18,4) NOT NULL,
    minimum_fee NUMERIC(18,2) NOT NULL
);

CREATE TABLE tariff.trade_lane_regions (
    id BIGSERIAL PRIMARY KEY,
    country VARCHAR(64) NOT NULL,
    region VARCHAR(64) NOT NULL
);

CREATE TABLE tariff.roe_rates (
    id BIGSERIAL PRIMARY KEY,
    currency VARCHAR(16) NOT NULL,
    roe NUMERIC(18,4) NOT NULL
);

INSERT INTO tariff.freight_rates (modality, unit, min_weight, max_weight, rate) VALUES
('AIR', 'MIN', 0, 44.999, 12.00),
('AIR', '+45KG', 45, 99.999, 10.00),
('AIR', '+100KG', 100, 299.999, 9.00),
('AIR', '+300KG', 300, 499.999, 8.50),
('AIR', '+500KG', 500, 999.999, 8.00),
('AIR', '+1000KG', 1000, 999999, 7.75),
('FCL', '20FT', NULL, NULL, 3500.00),
('FCL', '40FT', NULL, NULL, 6200.00),
('LCL', 'CBM', NULL, NULL, 550.00);

INSERT INTO tariff.cartage_rates (modality, area, amount) VALUES
('AIR', 'Johannesburg', 450.00),
('FCL', 'Johannesburg', 1800.00),
('LCL', 'Johannesburg', 900.00),
('AIR', 'Durban', 420.00),
('FCL', 'Durban', 1600.00),
('LCL', 'Durban', 850.00);

INSERT INTO tariff.destination_charge_rules (modality, shipment_type, incoterm, amount, minimum_charge) VALUES
('AIR', 'IMPORT', 'FOB', 800.00, 0),
('AIR', 'IMPORT', 'CIP', 0.00, 0),
('FCL', 'IMPORT', 'FOB', 1200.00, 0),
('LCL', 'IMPORT', 'FOB', 900.00, 6284.50),
('FCL', 'EXPORT', 'FOB', 0.00, 0);

INSERT INTO tariff.applicable_charge_rules (client_id, modality, shipment_type, code, calc_type, value, minimum, condition_value) VALUES
('CLIENT-001', 'FCL', 'IMPORT', 'DOCFEE', 'PER_SHIPMENT', 250.00, 0, NULL),
('CLIENT-001', 'FCL', 'IMPORT', 'HANDLING20', 'PER_CONTAINER', 180.00, 0, '20FT'),
('CLIENT-001', 'FCL', 'IMPORT', 'HANDLING40', 'PER_CONTAINER', 260.00, 0, '40FT'),
('CLIENT-001', 'FCL', 'IMPORT', 'AGENCY', 'PERCENT_OF_BASE', 5.00, 100.00, NULL),
('CLIENT-001', 'AIR', 'IMPORT', 'PERKG', 'PER_UNIT', 0.55, 100.00, NULL),
('CLIENT-001', 'AIR', 'IMPORT', 'CARTA', 'PER_SHIPMENT', 0.00, 0, NULL),
('CLIENT-001', 'LCL', 'IMPORT', 'LCLDOC', 'PER_SHIPMENT', 150.00, 0, NULL),
('CLIENT-001', 'LCL', 'IMPORT', 'LCLWM', 'PER_UNIT', 25.00, 100.00, NULL);

INSERT INTO tariff.customs_rules (hs_code, region, duty_type, duty_value, ad_valorem_type, ad_valorem_value) VALUES
('19019013', 'SADC', 'FREE', 0.00, 'NONE', 0.00),
('19019013', 'GENERAL', 'PERCENT', 20.00, 'PERCENT', 5.00),
('19019013', 'EU', 'PERCENT', 10.00, 'PERCENT', 2.50);

INSERT INTO tariff.finance_rules (client_id, modality, shipment_type, percentage, minimum_fee) VALUES
('CLIENT-001', 'FCL', 'IMPORT', 2.00, 100.00),
('CLIENT-001', 'AIR', 'IMPORT', 1.50, 75.00),
('CLIENT-001', 'LCL', 'IMPORT', 1.75, 80.00);

INSERT INTO tariff.trade_lane_regions (country, region) VALUES
('South Africa', 'SADC'),
('Botswana', 'SADC'),
('Germany', 'EU'),
('France', 'EU');

INSERT INTO tariff.roe_rates (currency, roe) VALUES
('USD', 18.50),
('EUR', 20.10),
('ZAR', 1.00);


INSERT INTO tariff.applicable_charge_rules (client_id, modality, shipment_type, code, calc_type, value, minimum, condition_value) VALUES
('PROSPECT_DEFAULT', 'FCL', 'IMPORT', 'DOCFEE', 'PER_SHIPMENT', 300.00, 0, NULL),
('PROSPECT_DEFAULT', 'AIR', 'IMPORT', 'PERKG', 'PER_UNIT', 0.65, 100.00, NULL),
('PROSPECT_DEFAULT', 'LCL', 'IMPORT', 'LCLDOC', 'PER_SHIPMENT', 175.00, 0, NULL)
ON CONFLICT DO NOTHING;

INSERT INTO tariff.finance_rules (client_id, modality, shipment_type, percentage, minimum_fee) VALUES
('PROSPECT_DEFAULT', 'FCL', 'IMPORT', 2.50, 120.00),
('PROSPECT_DEFAULT', 'AIR', 'IMPORT', 1.75, 85.00),
('PROSPECT_DEFAULT', 'LCL', 'IMPORT', 2.00, 90.00)
ON CONFLICT DO NOTHING;
