package com.rohlig.platform.tariff.api;

import com.rohlig.platform.tariff.events.TariffResolutionRequest;
import com.rohlig.platform.tariff.events.TariffResolutionResponse;
import com.rohlig.platform.tariff.service.TariffJdbcService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class TariffController {
    private final TariffJdbcService service;

    public TariffController(TariffJdbcService service) {
        this.service = service;
    }

    @PostMapping("/internal/tariffs/resolve")
    public TariffResolutionResponse resolve(@RequestBody TariffResolutionRequest request) {
        return service.resolve(request);
    }

    @GetMapping("/tariffs/health")
    public String health() {
        return "tariff-service running";
    }
}
