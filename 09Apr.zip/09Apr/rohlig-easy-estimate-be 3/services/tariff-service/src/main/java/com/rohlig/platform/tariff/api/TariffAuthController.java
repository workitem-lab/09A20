package com.rohlig.platform.tariff.api;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class TariffAuthController {
    @GetMapping("/api/v1/auth/me")
    public Map<String, Object> me(@AuthenticationPrincipal Jwt jwt) {
        return Map.of(
                "subject", jwt.getSubject(),
                "username", firstNonBlank(jwt.getClaimAsString("preferred_username"), jwt.getClaimAsString("email"), jwt.getSubject()),
                "name", firstNonBlank(jwt.getClaimAsString("name"), jwt.getClaimAsString("preferred_username")),
                "email", firstNonBlank(jwt.getClaimAsString("email"), jwt.getClaimAsString("preferred_username"))
        );
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return "";
    }
}
