package com.rohlig.platform.tariff.events;

import java.math.BigDecimal;

public record FinanceRuleDto(BigDecimal percentage, BigDecimal minimum) {}
