package com.rohlig.platform.tariff.events;

import java.math.BigDecimal;

public record ApplicableChargeRuleDto(String code, String calcType, BigDecimal value, BigDecimal minimum, String conditionValue) {}
