package com.rohlig.platform.tariff.events;

import java.math.BigDecimal;

public record CustomsRuleDto(String hsCode, String region, String dutyType, BigDecimal dutyValue, String adValoremType, BigDecimal adValoremValue) {}
