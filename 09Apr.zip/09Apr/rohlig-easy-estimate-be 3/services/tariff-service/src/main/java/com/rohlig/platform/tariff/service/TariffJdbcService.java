package com.rohlig.platform.tariff.service;

import com.rohlig.platform.tariff.events.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class TariffJdbcService {
    private final JdbcTemplate jdbcTemplate;

    public TariffJdbcService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public TariffResolutionResponse resolve(TariffResolutionRequest request) {
        String effectiveClientId = resolveEffectiveClientId(request.clientId());
        boolean carta = isCarta(effectiveClientId, request.modality(), request.shipmentType());
        String region = request.tradeLaneAgreement() ? resolveRegion(request.destinationCountry()) : "GENERAL";
        BigDecimal freight = switch (request.modality().toUpperCase()) {
            case "AIR" -> resolveAirFreight(request.chargeableWeight());
            case "FCL" -> resolveFclFreight(request.container20Qty(), request.container40Qty());
            case "LCL" -> resolveLclFreight(request.cbm());
            default -> BigDecimal.ZERO;
        };
        BigDecimal cartage = carta ? BigDecimal.ZERO : resolveCartage(request.modality(), request.finalDeliveryArea());
        BigDecimal destinationCharges = resolveDestinationCharges(request.modality(), request.shipmentType(), request.incoterm());
        List<ApplicableChargeRuleDto> rules = resolveApplicableRules(effectiveClientId, request.modality(), request.shipmentType());
        CustomsRuleDto customsRule = resolveCustomsRule(request.hsCode(), region);
        FinanceRuleDto financeRule = resolveFinanceRule(effectiveClientId, request.modality(), request.shipmentType());
        BigDecimal roe = resolveRoe(request.currency());
        return new TariffResolutionResponse(carta, region, freight, cartage, destinationCharges, roe, rules, customsRule, financeRule);
    }

    private String resolveEffectiveClientId(String clientId) {
        return clientId == null || clientId.isBlank() || clientId.startsWith("EE-PROSPECT-") ? "PROSPECT_DEFAULT" : clientId;
    }

    private boolean isCarta(String clientId, String modality, String shipmentType) {
        Integer count = jdbcTemplate.queryForObject(
                "select count(*) from tariff.applicable_charge_rules where client_id=? and modality=? and shipment_type=? and code='CARTA'",
                Integer.class, clientId, modality, shipmentType);
        return count != null && count > 0;
    }

    private String resolveRegion(String country) {
        return jdbcTemplate.query("select region from tariff.trade_lane_regions where country=? fetch first 1 row only",
                rs -> rs.next() ? rs.getString(1) : "GENERAL", country);
    }

    private BigDecimal resolveAirFreight(BigDecimal chargeableWeight) {
        return jdbcTemplate.query("select rate from tariff.freight_rates where modality='AIR' and ? between min_weight and max_weight order by max_weight fetch first 1 row only",
                rs -> rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO, chargeableWeight).multiply(chargeableWeight);
    }

    private BigDecimal resolveFclFreight(Integer qty20, Integer qty40) {
        BigDecimal r20 = jdbcTemplate.query("select rate from tariff.freight_rates where modality='FCL' and unit='20FT' fetch first 1 row only",
                rs -> rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO);
        BigDecimal r40 = jdbcTemplate.query("select rate from tariff.freight_rates where modality='FCL' and unit='40FT' fetch first 1 row only",
                rs -> rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO);
        return r20.multiply(BigDecimal.valueOf(qty20 == null ? 0 : qty20))
                .add(r40.multiply(BigDecimal.valueOf(qty40 == null ? 0 : qty40)));
    }

    private BigDecimal resolveLclFreight(BigDecimal cbm) {
        BigDecimal perCbm = jdbcTemplate.query("select rate from tariff.freight_rates where modality='LCL' and unit='CBM' fetch first 1 row only",
                rs -> rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO);
        BigDecimal minimum = jdbcTemplate.query("select minimum_charge from tariff.destination_charge_rules where modality='LCL' fetch first 1 row only",
                rs -> rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO);
        BigDecimal total = perCbm.multiply(cbm);
        return total.max(minimum);
    }

    private BigDecimal resolveCartage(String modality, String area) {
        return jdbcTemplate.query("select amount from tariff.cartage_rates where modality=? and area=? fetch first 1 row only",
                rs -> rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO, modality, area);
    }

    private BigDecimal resolveDestinationCharges(String modality, String shipmentType, String incoterm) {
        return jdbcTemplate.query("select amount from tariff.destination_charge_rules where modality=? and shipment_type=? and incoterm=? fetch first 1 row only",
                rs -> rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO, modality, shipmentType, incoterm);
    }

    private List<ApplicableChargeRuleDto> resolveApplicableRules(String clientId, String modality, String shipmentType) {
        return jdbcTemplate.query(
                "select code, calc_type, value, minimum, condition_value from tariff.applicable_charge_rules where client_id=? and modality=? and shipment_type=? and code<>'CARTA'",
                (rs, rowNum) -> new ApplicableChargeRuleDto(rs.getString("code"), rs.getString("calc_type"),
                        rs.getBigDecimal("value"), rs.getBigDecimal("minimum"), rs.getString("condition_value")),
                clientId, modality, shipmentType);
    }

    private CustomsRuleDto resolveCustomsRule(String hsCode, String region) {
        return jdbcTemplate.query("select hs_code, region, duty_type, duty_value, ad_valorem_type, ad_valorem_value from tariff.customs_rules where hs_code=? and region=? fetch first 1 row only",
                rs -> rs.next() ? new CustomsRuleDto(rs.getString("hs_code"), rs.getString("region"),
                        rs.getString("duty_type"), rs.getBigDecimal("duty_value"), rs.getString("ad_valorem_type"), rs.getBigDecimal("ad_valorem_value"))
                        : new CustomsRuleDto(hsCode, region, "FREE", BigDecimal.ZERO, "NONE", BigDecimal.ZERO),
                hsCode, region);
    }

    private FinanceRuleDto resolveFinanceRule(String clientId, String modality, String shipmentType) {
        return jdbcTemplate.query("select percentage, minimum_fee from tariff.finance_rules where client_id=? and modality=? and shipment_type=? fetch first 1 row only",
                rs -> rs.next() ? new FinanceRuleDto(rs.getBigDecimal("percentage"), rs.getBigDecimal("minimum_fee"))
                        : new FinanceRuleDto(BigDecimal.ZERO, BigDecimal.ZERO),
                clientId, modality, shipmentType);
    }

    private BigDecimal resolveRoe(String currency) {
        return jdbcTemplate.query("select roe from tariff.roe_rates where currency=? fetch first 1 row only",
                rs -> rs.next() ? rs.getBigDecimal(1) : BigDecimal.ONE, currency);
    }
}
