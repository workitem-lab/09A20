package com.rohlig.platform.tariff.api;
public record ApiViolation(String field, String message) {}
