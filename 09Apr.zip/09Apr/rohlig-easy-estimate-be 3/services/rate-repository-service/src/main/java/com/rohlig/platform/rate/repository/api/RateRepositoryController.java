package com.rohlig.platform.rate.repository.api;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/rate-repository")
public class RateRepositoryController {
    private final JdbcTemplate jdbcTemplate;

    public RateRepositoryController(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping("/health")
    public String health() {
        return "rate-repository-service running";
    }

    @GetMapping("/cards")
    public List<Map<String, Object>> cards(
            @RequestParam(required = false) String modality,
            @RequestParam(required = false) String shipmentType) {
        String sql =
                "select rate_card_code, modality, shipment_type, effective_from, effective_to, status " +
                        "from pricing.rate_cards " +
                        "where (? is null or modality = ?) " +
                        "and (? is null or shipment_type = ?) " +
                        "order by effective_from desc";
        return jdbcTemplate.queryForList(sql, modality, modality, shipmentType, shipmentType);
    }
}