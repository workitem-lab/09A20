package com.rohlig.platform.rate.repository;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RateRepositoryServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(RateRepositoryServiceApplication.class, args);
    }
}