ALTER TABLE pricing.rate_cards
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'uq_rate_cards_business'
    ) THEN
ALTER TABLE pricing.rate_cards
    ADD CONSTRAINT uq_rate_cards_business UNIQUE (rate_card_code);
END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uq_rate_card_lines_business_idx
    ON pricing.rate_card_lines(
    rate_card_code,
    charge_code,
    rate_basis,
    COALESCE(min_value, -1),
    COALESCE(max_value, -1),
    currency
    );