CREATE SCHEMA IF NOT EXISTS pricing;

CREATE TABLE IF NOT EXISTS pricing.rate_cards (
                                                  id BIGSERIAL PRIMARY KEY,
                                                  rate_card_code VARCHAR(64) NOT NULL,
    modality VARCHAR(16) NOT NULL,
    shipment_type VARCHAR(16) NOT NULL,
    effective_from DATE NOT NULL,
    effective_to DATE,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
    );

CREATE TABLE IF NOT EXISTS pricing.rate_card_lines (
                                                       id BIGSERIAL PRIMARY KEY,
                                                       rate_card_code VARCHAR(64) NOT NULL,
    charge_code VARCHAR(64) NOT NULL,
    rate_basis VARCHAR(32) NOT NULL,
    min_value NUMERIC(18,3),
    max_value NUMERIC(18,3),
    rate_value NUMERIC(18,4) NOT NULL,
    currency VARCHAR(16) NOT NULL DEFAULT 'ZAR'
    );

INSERT INTO pricing.rate_cards(rate_card_code, modality, shipment_type, effective_from, status) VALUES
                                                                                                    ('FCL_IMPORT_STD_2026', 'FCL', 'IMPORT', CURRENT_DATE, 'ACTIVE'),
                                                                                                    ('AIR_IMPORT_STD_2026', 'AIR', 'IMPORT', CURRENT_DATE, 'ACTIVE'),
                                                                                                    ('LCL_IMPORT_STD_2026', 'LCL', 'IMPORT', CURRENT_DATE, 'ACTIVE')
    ON CONFLICT DO NOTHING;
