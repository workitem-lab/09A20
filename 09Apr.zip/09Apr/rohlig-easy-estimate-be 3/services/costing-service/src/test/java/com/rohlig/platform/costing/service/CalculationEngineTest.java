package com.rohlig.platform.costing.service;

import com.rohlig.platform.costing.events.ApplicableChargeRuleDto;
import com.rohlig.platform.costing.events.CustomsRuleDto;
import com.rohlig.platform.costing.events.FinanceRuleDto;
import com.rohlig.platform.costing.events.ShipmentCreatedEvent;
import com.rohlig.platform.costing.events.TariffResolutionResponse;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CalculationEngineTest {

    private final CalculationEngine engine = new CalculationEngine();

    @Test
    void shouldCalculateTotalsForFclImport() {
        ShipmentCreatedEvent shipment = new ShipmentCreatedEvent(
                "SHIP-001", "CLIENT-001", "FCL", "IMPORT", "FOB",
                "China", "South Africa", "Shanghai", "Johannesburg", "Johannesburg",
                "MAERSK", BigDecimal.ZERO, 1, 1, BigDecimal.ZERO, new BigDecimal("50000"),
                "USD", "19019013", new BigDecimal("100"), true
        );

        TariffResolutionResponse tariff = new TariffResolutionResponse(
                false,
                "ROW",
                new BigDecimal("3500"),
                new BigDecimal("1200"),
                new BigDecimal("800"),
                new BigDecimal("18.50"),
                List.of(new ApplicableChargeRuleDto("DOC", "PER_SHIPMENT", new BigDecimal("150"), BigDecimal.ZERO, null)),
                new CustomsRuleDto("19019013", "ROW", "PERCENT", new BigDecimal("20"), "PERCENT", new BigDecimal("7")),
                new FinanceRuleDto(new BigDecimal("2.5"), new BigDecimal("300"))
        );

        var aggregate = engine.calculate(shipment, tariff);

        assertEquals(9, aggregate.lines().size());
        assertEquals(new BigDecimal("150.00"), aggregate.lines().stream().filter(l -> l.type().equals("APPLICABLE_CHARGES")).findFirst().orElseThrow().amount());
        assertEquals(new BigDecimal("1017500.00"), aggregate.lines().stream().filter(l -> l.type().equals("CUSTOMS_VALUE")).findFirst().orElseThrow().amount());
    }
}
