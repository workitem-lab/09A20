package com.rohlig.platform.costing.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "cost_lines")
public class CostLineEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String lineType;
    private BigDecimal amount;
    private String currencyCode;
    private String notes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shipment_id")
    private CostRecordEntity costRecord;

    public Long getId() { return id; }
    public String getLineType() { return lineType; }
    public void setLineType(String lineType) { this.lineType = lineType; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrencyCode() { return currencyCode; }
    public void setCurrencyCode(String currencyCode) { this.currencyCode = currencyCode; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public void setCostRecord(CostRecordEntity costRecord) { this.costRecord = costRecord; }
}
