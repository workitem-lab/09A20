package com.rohlig.platform.costing.service;

import com.rohlig.platform.costing.events.CostCalculatedEvent;

public record CostCalculatedCommittedEvent(CostCalculatedEvent payload) {
}
