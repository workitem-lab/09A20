package com.rohlig.platform.costing.events;

import java.math.BigDecimal;

public record ApplicableChargeRuleDto(String code, String calcType, BigDecimal value, BigDecimal minimum, String conditionValue) {}
