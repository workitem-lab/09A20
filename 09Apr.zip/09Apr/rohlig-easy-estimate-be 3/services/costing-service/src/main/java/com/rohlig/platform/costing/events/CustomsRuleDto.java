package com.rohlig.platform.costing.events;

import java.math.BigDecimal;

public record CustomsRuleDto(String hsCode, String region, String dutyType, BigDecimal dutyValue, String adValoremType, BigDecimal adValoremValue) {}
