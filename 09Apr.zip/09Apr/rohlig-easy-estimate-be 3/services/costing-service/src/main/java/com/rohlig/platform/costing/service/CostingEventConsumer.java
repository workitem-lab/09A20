package com.rohlig.platform.costing.service;

import com.rohlig.platform.costing.events.ShipmentCreatedEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class CostingEventConsumer {
    private final CostingService costingService;

    public CostingEventConsumer(CostingService costingService) {
        this.costingService = costingService;
    }

    @KafkaListener(topics = "shipment.created", groupId = "costing-service")
    public void consume(ShipmentCreatedEvent event) {
        costingService.process(event);
    }
}
