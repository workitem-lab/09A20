package com.rohlig.platform.costing.events;

import java.math.BigDecimal;

public record ShipmentCreatedEvent(
        String shipmentId,
        String clientId,
        String modality,
        String shipmentType,
        String incoterm,
        String originCountry,
        String destinationCountry,
        String portOfLoading,
        String portOfDestination,
        String finalDeliveryArea,
        String carrier,
        BigDecimal chargeableWeight,
        Integer container20Qty,
        Integer container40Qty,
        BigDecimal cbm,
        BigDecimal goodsValue,
        String currency,
        String hsCode,
        BigDecimal unitQuantity,
        boolean tradeLaneAgreement
) {}
