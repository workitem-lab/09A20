package com.rohlig.platform.costing.api;

import java.time.OffsetDateTime;
import java.util.List;

public record ApiErrorResponse(
        OffsetDateTime timestamp,
        int status,
        String error,
        String code,
        String message,
        String path,
        String correlationId,
        List<ApiViolation> violations
) {
    public static ApiErrorResponse of(int status, String error, String code, String message, String path, String correlationId, List<ApiViolation> violations) {
        return new ApiErrorResponse(OffsetDateTime.now(), status, error, code, message, path, correlationId, violations);
    }
}
