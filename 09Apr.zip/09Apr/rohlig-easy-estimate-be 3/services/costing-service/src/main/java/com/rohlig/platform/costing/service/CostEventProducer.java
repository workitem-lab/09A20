package com.rohlig.platform.costing.service;

import com.rohlig.platform.costing.events.CostCalculatedEvent;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class CostEventProducer {
    private final KafkaTemplate<String, Object> kafkaTemplate;

    public CostEventProducer(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publish(CostCalculatedEvent event) {
        kafkaTemplate.send("costing.calculated", event.shipmentId(), event);
    }
}
