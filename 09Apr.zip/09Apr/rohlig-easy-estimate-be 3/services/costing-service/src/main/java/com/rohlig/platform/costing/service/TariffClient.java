package com.rohlig.platform.costing.service;

import com.rohlig.platform.costing.events.TariffResolutionRequest;
import com.rohlig.platform.costing.events.TariffResolutionResponse;
import com.rohlig.platform.costing.security.ServiceAccessTokenProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class TariffClient {
    private final RestClient client;
    private final ServiceAccessTokenProvider tokenProvider;

    public TariffClient(RestClient.Builder builder,
                        ServiceAccessTokenProvider tokenProvider,
                        @Value("${TARIFF_SERVICE_BASE_URL:http://tariff-service:8082}") String baseUrl) {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(5000);
        requestFactory.setReadTimeout(10000);
        this.client = builder.requestFactory(requestFactory).baseUrl(baseUrl).build();
        this.tokenProvider = tokenProvider;
    }

    public TariffResolutionResponse resolve(TariffResolutionRequest request) {
        return client.post()
                .uri("/api/v1/internal/tariffs/resolve")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenProvider.getAccessToken())
                .body(request)
                .retrieve()
                .body(TariffResolutionResponse.class);
    }
}
