package com.rohlig.platform.costing.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "cost_records")
public class CostRecordEntity {
    @Id
    @Column(name = "shipment_id")
    private String shipmentId;
    @Column(name = "client_id")
    private String clientId;
    private String modality;
    @Column(name = "shipment_type")
    private String shipmentType;
    private BigDecimal freight;
    private BigDecimal cartage;
    @Column(name = "destination_charges")
    private BigDecimal destinationCharges;
    @Column(name = "applicable_charges")
    private BigDecimal applicableCharges;
    @Column(name = "customs_value")
    private BigDecimal customsValue;
    private BigDecimal duty;
    @Column(name = "ad_valorem")
    private BigDecimal adValorem;
    @Column(name = "customs_vat")
    private BigDecimal customsVat;
    @Column(name = "finance_fee")
    private BigDecimal financeFee;
    private BigDecimal total;
    @Column(name = "operational_total")
    private BigDecimal operationalTotal;
    @Column(name = "customs_total")
    private BigDecimal customsTotal;
    @Column(name = "finance_total")
    private BigDecimal financeTotal;
    @Column(name = "valuation_base")
    private BigDecimal valuationBase;
    @Column(name = "payable_total")
    private BigDecimal payableTotal;
    @Column(name = "calculated_at")
    private OffsetDateTime calculatedAt = OffsetDateTime.now();

    @OneToMany(mappedBy = "costRecord", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<CostLineEntity> lines = new ArrayList<>();

    public String getShipmentId() { return shipmentId; }
    public void setShipmentId(String shipmentId) { this.shipmentId = shipmentId; }
    public String getClientId() { return clientId; }
    public void setClientId(String clientId) { this.clientId = clientId; }
    public String getModality() { return modality; }
    public void setModality(String modality) { this.modality = modality; }
    public String getShipmentType() { return shipmentType; }
    public void setShipmentType(String shipmentType) { this.shipmentType = shipmentType; }
    public BigDecimal getFreight() { return freight; }
    public void setFreight(BigDecimal freight) { this.freight = freight; }
    public BigDecimal getCartage() { return cartage; }
    public void setCartage(BigDecimal cartage) { this.cartage = cartage; }
    public BigDecimal getDestinationCharges() { return destinationCharges; }
    public void setDestinationCharges(BigDecimal destinationCharges) { this.destinationCharges = destinationCharges; }
    public BigDecimal getApplicableCharges() { return applicableCharges; }
    public void setApplicableCharges(BigDecimal applicableCharges) { this.applicableCharges = applicableCharges; }
    public BigDecimal getCustomsValue() { return customsValue; }
    public void setCustomsValue(BigDecimal customsValue) { this.customsValue = customsValue; }
    public BigDecimal getDuty() { return duty; }
    public void setDuty(BigDecimal duty) { this.duty = duty; }
    public BigDecimal getAdValorem() { return adValorem; }
    public void setAdValorem(BigDecimal adValorem) { this.adValorem = adValorem; }
    public BigDecimal getCustomsVat() { return customsVat; }
    public void setCustomsVat(BigDecimal customsVat) { this.customsVat = customsVat; }
    public BigDecimal getFinanceFee() { return financeFee; }
    public void setFinanceFee(BigDecimal financeFee) { this.financeFee = financeFee; }
    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal total) { this.total = total; }
    public BigDecimal getOperationalTotal() { return operationalTotal; }
    public void setOperationalTotal(BigDecimal operationalTotal) { this.operationalTotal = operationalTotal; }
    public BigDecimal getCustomsTotal() { return customsTotal; }
    public void setCustomsTotal(BigDecimal customsTotal) { this.customsTotal = customsTotal; }
    public BigDecimal getFinanceTotal() { return financeTotal; }
    public void setFinanceTotal(BigDecimal financeTotal) { this.financeTotal = financeTotal; }
    public BigDecimal getValuationBase() { return valuationBase; }
    public void setValuationBase(BigDecimal valuationBase) { this.valuationBase = valuationBase; }
    public BigDecimal getPayableTotal() { return payableTotal; }
    public void setPayableTotal(BigDecimal payableTotal) { this.payableTotal = payableTotal; }
    public OffsetDateTime getCalculatedAt() { return calculatedAt; }
    public void setCalculatedAt(OffsetDateTime calculatedAt) { this.calculatedAt = calculatedAt; }
    public List<CostLineEntity> getLines() { return lines; }
    public void setLines(List<CostLineEntity> lines) { this.lines = lines; }
    public void clearLines() { this.lines.clear(); }
    public void addLine(CostLineEntity line) { line.setCostRecord(this); this.lines.add(line); }
}
