package com.rohlig.platform.costing.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CostAggregate {
    private final List<CostLine> lines = new ArrayList<>();

    public void addLine(String type, BigDecimal amount, String currency, String notes) {
        lines.add(new CostLine(type, amount, currency, notes));
    }

    public List<CostLine> lines() {
        return Collections.unmodifiableList(lines);
    }

    public BigDecimal totalExcludingCustomsValue() {
        return lines.stream()
                .filter(line -> !"CUSTOMS_VALUE".equals(line.type()))
                .map(CostLine::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
