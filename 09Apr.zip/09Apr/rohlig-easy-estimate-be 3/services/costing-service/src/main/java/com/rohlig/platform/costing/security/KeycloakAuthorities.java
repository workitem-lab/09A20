package com.rohlig.platform.costing.security;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.*;
import java.util.stream.Collectors;

public final class KeycloakAuthorities {
    private KeycloakAuthorities() {}

    public static Collection<GrantedAuthority> extract(Jwt jwt) {
        Set<String> roles = new LinkedHashSet<>();
        Object realmAccess = jwt.getClaims().get("realm_access");
        if (realmAccess instanceof Map<?, ?> realmMap) {
            Object realmRoles = realmMap.get("roles");
            if (realmRoles instanceof Collection<?> values) {
                values.stream().filter(Objects::nonNull).map(Object::toString).forEach(roles::add);
            }
        }
        Object directRoles = jwt.getClaims().get("roles");
        if (directRoles instanceof Collection<?> values) {
            values.stream().filter(Objects::nonNull).map(Object::toString).forEach(roles::add);
        }
        Object resourceAccess = jwt.getClaims().get("resource_access");
        if (resourceAccess instanceof Map<?, ?> resourceMap) {
            for (Object clientEntry : resourceMap.values()) {
                if (clientEntry instanceof Map<?, ?> clientMap) {
                    Object clientRoles = clientMap.get("roles");
                    if (clientRoles instanceof Collection<?> values) {
                        values.stream().filter(Objects::nonNull).map(Object::toString).forEach(roles::add);
                    }
                }
            }
        }
        return roles.stream().map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role).map(SimpleGrantedAuthority::new).collect(Collectors.toCollection(LinkedHashSet::new));
    }
}
