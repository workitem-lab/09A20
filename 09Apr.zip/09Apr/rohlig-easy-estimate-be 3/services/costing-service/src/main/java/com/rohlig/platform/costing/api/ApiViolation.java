package com.rohlig.platform.costing.api;
public record ApiViolation(String field, String message) {}
