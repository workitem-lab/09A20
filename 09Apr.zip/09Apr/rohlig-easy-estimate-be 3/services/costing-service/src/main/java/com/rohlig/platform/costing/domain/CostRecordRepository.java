package com.rohlig.platform.costing.domain;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CostRecordRepository extends JpaRepository<CostRecordEntity, String> {

    @Query("""
            select c from CostRecordEntity c
            where (:clientId is null or c.clientId = :clientId)
              and (:modality is null or upper(c.modality) = upper(:modality))
              and (:shipmentType is null or upper(c.shipmentType) = upper(:shipmentType))
            """)
    Page<CostRecordEntity> search(@Param("clientId") String clientId,
                                  @Param("modality") String modality,
                                  @Param("shipmentType") String shipmentType,
                                  Pageable pageable);
}
