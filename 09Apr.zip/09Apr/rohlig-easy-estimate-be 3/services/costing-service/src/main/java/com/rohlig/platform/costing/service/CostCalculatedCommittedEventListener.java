package com.rohlig.platform.costing.service;

import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
public class CostCalculatedCommittedEventListener {
    private final CostEventProducer eventProducer;

    public CostCalculatedCommittedEventListener(CostEventProducer eventProducer) {
        this.eventProducer = eventProducer;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onCommitted(CostCalculatedCommittedEvent event) {
        eventProducer.publish(event.payload());
    }
}
