package com.rohlig.platform.costing.service;

import com.rohlig.platform.costing.domain.CostAggregate;
import com.rohlig.platform.costing.events.*;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Component
public class CalculationEngine {
    public CostAggregate calculate(ShipmentCreatedEvent shipment, TariffResolutionResponse tariff) {
        CostAggregate aggregate = new CostAggregate();
        BigDecimal freight = nz(tariff.freightAmount());
        BigDecimal cartage = nz(tariff.cartageAmount());
        BigDecimal destinationCharges = nz(tariff.destinationChargesAmount());
        BigDecimal applicableCharges = calculateApplicableCharges(shipment, tariff, freight, cartage, destinationCharges);
        BigDecimal customsValue = calculateCustomsValue(shipment, tariff);
        BigDecimal duty = calculateDuty(shipment, tariff, customsValue);
        BigDecimal adValorem = calculateAdValorem(shipment, tariff, customsValue);
        BigDecimal customsVat = customsValue.add(duty).add(adValorem).multiply(new BigDecimal("0.15")).setScale(2, RoundingMode.HALF_UP);
        BigDecimal baseBeforeFinance = freight.add(cartage).add(destinationCharges).add(applicableCharges).add(duty).add(adValorem).add(customsVat);
        BigDecimal financeFee = calculateFinanceFee(baseBeforeFinance, tariff.financeRule());

        aggregate.addLine("FREIGHT", freight, "ZAR", "Base freight");
        aggregate.addLine("CARTAGE", cartage, "ZAR", tariff.carta() ? "Suppressed by CARTA" : "Final delivery cartage");
        aggregate.addLine("DESTINATION_CHARGES", destinationCharges, "ZAR", "Destination / landside charges");
        aggregate.addLine("APPLICABLE_CHARGES", applicableCharges, "ZAR", "Client tariff applicable charges");
        aggregate.addLine("CUSTOMS_VALUE", customsValue, "ZAR", "Valuation base only; excluded from payable total");
        aggregate.addLine("DUTY", duty, "ZAR", "Customs duty");
        aggregate.addLine("AD_VALOREM", adValorem, "ZAR", "Ad valorem");
        aggregate.addLine("CUSTOMS_VAT", customsVat, "ZAR", "15% of customs value + duty + ad valorem");
        aggregate.addLine("FINANCE_FEE", financeFee, "ZAR", "Client FINAN rule");
        return aggregate;
    }

    private BigDecimal calculateApplicableCharges(ShipmentCreatedEvent shipment, TariffResolutionResponse tariff, BigDecimal freight, BigDecimal cartage, BigDecimal destinationCharges) {
        BigDecimal total = BigDecimal.ZERO;
        for (ApplicableChargeRuleDto rule : tariff.applicableChargeRules()) {
            BigDecimal value = nz(rule.value());
            BigDecimal minimum = nz(rule.minimum());
            BigDecimal computed = switch (rule.calcType()) {
                case "PER_SHIPMENT" -> value;
                case "PER_CONTAINER" -> {
                    int qty = "40FT".equalsIgnoreCase(rule.conditionValue()) ? nzInt(shipment.container40Qty()) : nzInt(shipment.container20Qty());
                    yield value.multiply(BigDecimal.valueOf(qty));
                }
                case "PER_UNIT" -> value.multiply(unitBase(shipment));
                case "PER_PACKAGE" -> value.multiply(unitBase(shipment));
                case "PERCENT_OF_FREIGHT" -> freight.multiply(value.divide(new BigDecimal("100"), 8, RoundingMode.HALF_UP));
                case "PERCENT_OF_BASE" -> freight.add(cartage).add(destinationCharges).multiply(value.divide(new BigDecimal("100"), 8, RoundingMode.HALF_UP));
                default -> BigDecimal.ZERO;
            };
            total = total.add(computed.max(minimum));
        }
        return total.setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculateCustomsValue(ShipmentCreatedEvent shipment, TariffResolutionResponse tariff) {
        BigDecimal base = nz(shipment.goodsValue()).multiply(nz(tariff.roe()));
        if (!"SADC".equalsIgnoreCase(tariff.region())) {
            base = base.multiply(new BigDecimal("1.10"));
        }
        return base.setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculateDuty(ShipmentCreatedEvent shipment, TariffResolutionResponse tariff, BigDecimal customsValue) {
        CustomsRuleDto rule = tariff.customsRule();
        if (rule == null || "FREE".equalsIgnoreCase(rule.dutyType())) return BigDecimal.ZERO;
        if ("PERCENT".equalsIgnoreCase(rule.dutyType())) {
            return customsValue.multiply(nz(rule.dutyValue()).divide(new BigDecimal("100"), 8, RoundingMode.HALF_UP)).setScale(2, RoundingMode.HALF_UP);
        }
        if ("PER_UNIT".equalsIgnoreCase(rule.dutyType())) {
            return nz(rule.dutyValue()).multiply(nz(shipment.unitQuantity())).setScale(2, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO;
    }

    private BigDecimal calculateAdValorem(ShipmentCreatedEvent shipment, TariffResolutionResponse tariff, BigDecimal customsValue) {
        CustomsRuleDto rule = tariff.customsRule();
        if (rule == null || "NONE".equalsIgnoreCase(rule.adValoremType())) return BigDecimal.ZERO;
        if ("PERCENT".equalsIgnoreCase(rule.adValoremType())) {
            return customsValue.multiply(nz(rule.adValoremValue()).divide(new BigDecimal("100"), 8, RoundingMode.HALF_UP)).setScale(2, RoundingMode.HALF_UP);
        }
        if ("PER_UNIT".equalsIgnoreCase(rule.adValoremType())) {
            return nz(rule.adValoremValue()).multiply(nz(shipment.unitQuantity())).setScale(2, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO;
    }

    private BigDecimal calculateFinanceFee(BigDecimal base, FinanceRuleDto financeRule) {
        if (financeRule == null) return BigDecimal.ZERO;
        BigDecimal derived = base.multiply(nz(financeRule.percentage()).divide(new BigDecimal("100"), 8, RoundingMode.HALF_UP));
        return derived.max(nz(financeRule.minimum())).setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal unitBase(ShipmentCreatedEvent shipment) {
        return switch (shipment.modality().toUpperCase()) {
            case "AIR" -> nz(shipment.chargeableWeight());
            case "LCL" -> nz(shipment.cbm());
            default -> BigDecimal.valueOf(nzInt(shipment.container20Qty()) + nzInt(shipment.container40Qty()));
        };
    }

    private static BigDecimal nz(BigDecimal value) { return value == null ? BigDecimal.ZERO : value; }
    private static int nzInt(Integer value) { return value == null ? 0 : value; }
}
