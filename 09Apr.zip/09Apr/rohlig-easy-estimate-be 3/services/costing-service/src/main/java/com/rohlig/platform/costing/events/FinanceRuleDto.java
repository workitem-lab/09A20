package com.rohlig.platform.costing.events;

import java.math.BigDecimal;

public record FinanceRuleDto(BigDecimal percentage, BigDecimal minimum) {}
