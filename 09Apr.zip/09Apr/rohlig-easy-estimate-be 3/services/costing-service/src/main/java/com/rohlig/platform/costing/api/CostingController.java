package com.rohlig.platform.costing.api;

import com.rohlig.platform.costing.domain.CostRecordEntity;
import com.rohlig.platform.costing.service.CostingService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/costs")
public class CostingController {
    private static final int MAX_PAGE_SIZE = 100;

    private final CostingService costingService;

    public CostingController(CostingService costingService) {
        this.costingService = costingService;
    }

    @PostMapping("/recalculate")
    public CostRecordEntity recalculate(@RequestHeader("Idempotency-Key") String idempotencyKey,
                                        @Valid @RequestBody RecalculateCostRequest request) {
        return costingService.recalculate(idempotencyKey, request);
    }

    @GetMapping("/{shipmentId}")
    public CostRecordEntity get(@PathVariable String shipmentId) {
        return costingService.get(shipmentId);
    }

    @GetMapping
    public PageResponse<CostRecordEntity> search(@RequestParam(required = false) String clientId,
                                                 @RequestParam(required = false) String modality,
                                                 @RequestParam(required = false) String shipmentType,
                                                 @RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "20") int size) {
        int safePage = Math.max(page, 0);
        int safeSize = Math.min(Math.max(size, 1), MAX_PAGE_SIZE);
        Page<CostRecordEntity> result = costingService.search(
                clientId,
                modality,
                shipmentType,
                PageRequest.of(safePage, safeSize, Sort.by(Sort.Direction.DESC, "calculatedAt"))
        );
        return new PageResponse<>(result.getContent(), result.getTotalElements(), result.getTotalPages(), result.getNumber(), result.getSize());
    }

    @GetMapping("/health")
    public String health() {
        return "costing-service running";
    }
}
