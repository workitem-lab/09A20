package com.rohlig.platform.costing.events;

import java.math.BigDecimal;
import java.util.List;

public record TariffResolutionResponse(
        boolean carta,
        String region,
        BigDecimal freightAmount,
        BigDecimal cartageAmount,
        BigDecimal destinationChargesAmount,
        BigDecimal roe,
        List<ApplicableChargeRuleDto> applicableChargeRules,
        CustomsRuleDto customsRule,
        FinanceRuleDto financeRule
) {}
