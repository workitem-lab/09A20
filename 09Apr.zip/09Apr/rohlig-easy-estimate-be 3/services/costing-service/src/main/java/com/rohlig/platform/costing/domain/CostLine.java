package com.rohlig.platform.costing.domain;

import java.math.BigDecimal;

public record CostLine(String type, BigDecimal amount, String currency, String notes) {}
