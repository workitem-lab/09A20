package com.rohlig.platform.costing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CostingServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(CostingServiceApplication.class, args);
    }
}
