CREATE SCHEMA IF NOT EXISTS costing;

CREATE TABLE costing.cost_records (
    shipment_id VARCHAR(64) PRIMARY KEY,
    client_id VARCHAR(64) NOT NULL,
    modality VARCHAR(16) NOT NULL,
    shipment_type VARCHAR(16) NOT NULL,
    freight NUMERIC(18,2) NOT NULL DEFAULT 0,
    cartage NUMERIC(18,2) NOT NULL DEFAULT 0,
    destination_charges NUMERIC(18,2) NOT NULL DEFAULT 0,
    applicable_charges NUMERIC(18,2) NOT NULL DEFAULT 0,
    customs_value NUMERIC(18,2) NOT NULL DEFAULT 0,
    duty NUMERIC(18,2) NOT NULL DEFAULT 0,
    ad_valorem NUMERIC(18,2) NOT NULL DEFAULT 0,
    customs_vat NUMERIC(18,2) NOT NULL DEFAULT 0,
    finance_fee NUMERIC(18,2) NOT NULL DEFAULT 0,
    total NUMERIC(18,2) NOT NULL DEFAULT 0,
    operational_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    customs_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    finance_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    valuation_base NUMERIC(18,2) NOT NULL DEFAULT 0,
    payable_total NUMERIC(18,2) NOT NULL DEFAULT 0,
    calculated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE costing.cost_lines (
    id BIGSERIAL PRIMARY KEY,
    shipment_id VARCHAR(64) NOT NULL REFERENCES costing.cost_records(shipment_id) ON DELETE CASCADE,
    line_type VARCHAR(64) NOT NULL,
    amount NUMERIC(18,2) NOT NULL,
    currency_code VARCHAR(16) NOT NULL,
    notes VARCHAR(256)
);

CREATE TABLE costing.idempotency_records (
    idempotency_key VARCHAR(200) PRIMARY KEY,
    request_hash VARCHAR(128) NOT NULL,
    resource_id VARCHAR(64) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
