ALTER TABLE pricing_import.import_files
    ADD COLUMN IF NOT EXISTS content_type VARCHAR(100),
    ADD COLUMN IF NOT EXISTS notes VARCHAR(500);