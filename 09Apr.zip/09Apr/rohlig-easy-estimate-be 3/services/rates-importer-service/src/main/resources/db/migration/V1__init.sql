CREATE SCHEMA IF NOT EXISTS pricing_import;

CREATE TABLE IF NOT EXISTS pricing_import.import_batches (
 id BIGSERIAL PRIMARY KEY,
 batch_reference VARCHAR(64) NOT NULL UNIQUE,
    source_type VARCHAR(32) NOT NULL,
    started_at TIMESTAMPTZ NOT NULL,
    completed_at TIMESTAMPTZ,
    status VARCHAR(16) NOT NULL
    );

CREATE TABLE IF NOT EXISTS pricing_import.import_files (
id BIGSERIAL PRIMARY KEY,
batch_reference VARCHAR(64) NOT NULL,
    file_name VARCHAR(256) NOT NULL,
    file_type VARCHAR(32),
    total_records INTEGER DEFAULT 0,
    success_records INTEGER DEFAULT 0,
    failed_records INTEGER DEFAULT 0,
    status VARCHAR(16) NOT NULL,
    imported_at TIMESTAMPTZ DEFAULT NOW()
    );

CREATE TABLE IF NOT EXISTS pricing_import.import_errors (
id BIGSERIAL PRIMARY KEY,
batch_reference VARCHAR(64) NOT NULL,
    row_number INTEGER,
    field_name VARCHAR(128),
    error_message VARCHAR(512),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );