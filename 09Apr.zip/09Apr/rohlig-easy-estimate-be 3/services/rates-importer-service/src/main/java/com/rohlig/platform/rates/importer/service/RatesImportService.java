package com.rohlig.platform.rates.importer.service;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class RatesImportService {
    private final JdbcTemplate jdbcTemplate;
    private final long maxFileSizeBytes;

    public RatesImportService(JdbcTemplate jdbcTemplate,
                              @Value("${app.importer.max-file-size-bytes:5242880}") long maxFileSizeBytes) {
        this.jdbcTemplate = jdbcTemplate;
        this.maxFileSizeBytes = maxFileSizeBytes;
    }

    public Map<String, Object> createBatch(String sourceType) {
        String ref = UUID.randomUUID().toString();
        jdbcTemplate.update("insert into pricing_import.import_batches(batch_reference, source_type, started_at, status) values (?,?,?,?)", ref, sourceType, OffsetDateTime.now(), "STARTED");
        return Map.of("batchReference", ref, "status", "STARTED");
    }

    @Transactional
    public Map<String, Object> importCsv(MultipartFile file, String sourceType) {
        validateFile(file);

        String ref = UUID.randomUUID().toString();
        jdbcTemplate.update("insert into pricing_import.import_batches(batch_reference, source_type, started_at, status) values (?,?,?,?)", ref, sourceType, OffsetDateTime.now(), "STARTED");
        int total = 0;
        int success = 0;
        int failed = 0;

        try (CSVParser parser = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .build()
                .parse(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            for (CSVRecord record : parser) {
                total++;
                try {
                    upsertRateCard(record);
                    upsertRateLine(record);
                    success++;
                } catch (Exception ex) {
                    failed++;
                    jdbcTemplate.update(
                            "insert into pricing_import.import_errors(batch_reference, row_number, field_name, error_message) values (?,?,?,?)",
                            ref,
                            (int) record.getRecordNumber(),
                            "row",
                            ex.getMessage()
                    );
                }
            }
            jdbcTemplate.update(
                    "insert into pricing_import.import_files(batch_reference, file_name, file_type, total_records, success_records, failed_records, status, imported_at, content_type, notes) values (?,?,?,?,?,?,?,?,?,?)",
                    ref,
                    file.getOriginalFilename(),
                    "CSV",
                    total,
                    success,
                    failed,
                    failed == 0 ? "COMPLETED" : "COMPLETED_WITH_ERRORS",
                    OffsetDateTime.now(),
                    file.getContentType(),
                    "Imported through API"
            );
            jdbcTemplate.update(
                    "update pricing_import.import_batches set completed_at=?, status=? where batch_reference=?",
                    OffsetDateTime.now(),
                    failed == 0 ? "COMPLETED" : "COMPLETED_WITH_ERRORS",
                    ref
            );
        } catch (Exception ex) {
            jdbcTemplate.update("update pricing_import.import_batches set completed_at=?, status=? where batch_reference=?", OffsetDateTime.now(), "FAILED", ref);
            throw new IllegalStateException("Unable to import CSV file", ex);
        }
        return Map.of("batchReference", ref, "status", failed == 0 ? "COMPLETED" : "COMPLETED_WITH_ERRORS", "totalRecords", total, "successRecords", success, "failedRecords", failed);
    }

    public List<Map<String, Object>> batches() {
        return jdbcTemplate.queryForList("select batch_reference, source_type, status, started_at, completed_at from pricing_import.import_batches order by started_at desc");
    }

    public Map<String, Object> batch(String batchReference) {
        return jdbcTemplate.queryForMap("select batch_reference, source_type, status, started_at, completed_at from pricing_import.import_batches where batch_reference=?", batchReference);
    }

    public List<Map<String, Object>> errors(String batchReference) {
        return jdbcTemplate.queryForList("select row_number, field_name, error_message, created_at from pricing_import.import_errors where batch_reference=? order by row_number asc", batchReference);
    }

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("CSV file is required");
        }
        if (file.getSize() > maxFileSizeBytes) {
            throw new IllegalArgumentException("CSV file exceeds max size of " + maxFileSizeBytes + " bytes");
        }
        String filename = file.getOriginalFilename() == null ? "" : file.getOriginalFilename().toLowerCase();
        if (!filename.endsWith(".csv")) {
            throw new IllegalArgumentException("Only CSV uploads are supported");
        }
    }

    private void upsertRateCard(CSVRecord record) {
        jdbcTemplate.update("insert into pricing.rate_cards(rate_card_code, modality, shipment_type, effective_from, effective_to, status, updated_at) values (?,?,?,?,?,?,?) on conflict (rate_card_code) do update set modality = excluded.modality, shipment_type = excluded.shipment_type, effective_from = excluded.effective_from, effective_to = excluded.effective_to, status = excluded.status, updated_at = excluded.updated_at", required(record, "rate_card_code"), required(record, "modality"), required(record, "shipment_type"), LocalDate.parse(required(record, "effective_from")), empty(record, "effective_to") ? null : LocalDate.parse(record.get("effective_to")), empty(record, "status") ? "ACTIVE" : record.get("status"), OffsetDateTime.now());
    }

    private void upsertRateLine(CSVRecord record) {
        jdbcTemplate.update("delete from pricing.rate_card_lines where rate_card_code=? and charge_code=? and rate_basis=? and coalesce(min_value,-1)=coalesce(?,-1) and coalesce(max_value,-1)=coalesce(?,-1) and currency=?", required(record, "rate_card_code"), required(record, "charge_code"), required(record, "rate_basis"), decimalOrNull(record, "min_value"), decimalOrNull(record, "max_value"), empty(record, "currency") ? "ZAR" : record.get("currency"));
        jdbcTemplate.update("insert into pricing.rate_card_lines(rate_card_code, charge_code, rate_basis, min_value, max_value, rate_value, currency) values (?,?,?,?,?,?,?)", required(record, "rate_card_code"), required(record, "charge_code"), required(record, "rate_basis"), decimalOrNull(record, "min_value"), decimalOrNull(record, "max_value"), new BigDecimal(required(record, "rate_value")), empty(record, "currency") ? "ZAR" : record.get("currency"));
    }

    private String required(CSVRecord record, String header) {
        if (empty(record, header)) {
            throw new IllegalArgumentException("Missing required column value: " + header);
        }
        return record.get(header).trim();
    }

    private boolean empty(CSVRecord record, String header) {
        return !record.isMapped(header) || record.get(header) == null || record.get(header).isBlank();
    }

    private BigDecimal decimalOrNull(CSVRecord record, String header) {
        return empty(record, header) ? null : new BigDecimal(record.get(header).trim());
    }
}
