package com.rohlig.platform.rates.importer.api;

import com.rohlig.platform.rates.importer.service.RatesImportService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/rates-importer")
public class RatesImporterController {
    private final RatesImportService ratesImportService;
    public RatesImporterController(RatesImportService ratesImportService) { this.ratesImportService = ratesImportService; }
    @GetMapping("/health") public String health() { return "rates-importer-service running"; }
    @PostMapping("/batches") public Map<String, Object> createBatch(@RequestBody Map<String, Object> request) { return ratesImportService.createBatch(String.valueOf(request.getOrDefault("sourceType", "MANUAL"))); }
    @PostMapping(value = "/batches/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> upload(@RequestParam("file") MultipartFile file, @RequestParam(defaultValue = "CSV") String sourceType) { return ratesImportService.importCsv(file, sourceType); }
    @GetMapping("/batches") public List<Map<String, Object>> batches() { return ratesImportService.batches(); }
    @GetMapping("/batches/{batchReference}") public Map<String, Object> batch(@PathVariable String batchReference) { return ratesImportService.batch(batchReference); }
    @GetMapping("/batches/{batchReference}/errors") public List<Map<String, Object>> errors(@PathVariable String batchReference) { return ratesImportService.errors(batchReference); }
    @GetMapping("/template") public Map<String, Object> template() { return Map.of("headers", List.of("rate_card_code","modality","shipment_type","effective_from","effective_to","status","charge_code","rate_basis","min_value","max_value","rate_value","currency"), "sample", "FCL_IMPORT_STD_2026,FCL,IMPORT,2026-01-01,2026-12-31,ACTIVE,FREIGHT,PER_CONTAINER,,,3500,ZAR"); }
}
