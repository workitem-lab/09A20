package com.rohlig.platform.rates.importer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RatesImporterServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(RatesImporterServiceApplication.class, args);
    }
}
