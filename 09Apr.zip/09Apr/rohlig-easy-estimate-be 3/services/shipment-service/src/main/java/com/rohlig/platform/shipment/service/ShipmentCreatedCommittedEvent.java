package com.rohlig.platform.shipment.service;

import com.rohlig.platform.shipment.events.ShipmentCreatedEvent;

public record ShipmentCreatedCommittedEvent(ShipmentCreatedEvent payload) {
}
