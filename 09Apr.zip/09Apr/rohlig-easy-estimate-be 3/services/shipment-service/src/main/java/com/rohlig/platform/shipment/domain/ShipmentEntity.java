package com.rohlig.platform.shipment.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "shipments")
public class ShipmentEntity {

    @Id
    @Column(name = "shipment_id")
    private String shipmentId;

    @Column(name = "client_id")
    private String clientId;

    @Column(name = "modality")
    private String modality;

    @Column(name = "shipment_type")
    private String shipmentType;

    @Column(name = "incoterm")
    private String incoterm;

    @Column(name = "origin_country")
    private String originCountry;

    @Column(name = "destination_country")
    private String destinationCountry;

    @Column(name = "port_of_loading")
    private String portOfLoading;

    @Column(name = "port_of_destination")
    private String portOfDestination;

    @Column(name = "final_delivery_area")
    private String finalDeliveryArea;

    @Column(name = "carrier")
    private String carrier;

    @Column(name = "chargeable_weight")
    private BigDecimal chargeableWeight;

    @Column(name = "container20_qty")
    private Integer container20Qty;

    @Column(name = "container40_qty")
    private Integer container40Qty;

    @Column(name = "cbm")
    private BigDecimal cbm;

    @Column(name = "goods_value")
    private BigDecimal goodsValue;

    @Column(name = "currency")
    private String currency;

    @Column(name = "hs_code")
    private String hsCode;

    @Column(name = "unit_quantity")
    private BigDecimal unitQuantity;

    @Column(name = "trade_lane_agreement")
    private boolean tradeLaneAgreement;

    @Column(name = "created_at")
    private OffsetDateTime createdAt = OffsetDateTime.now();

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getModality() {
        return modality;
    }

    public void setModality(String modality) {
        this.modality = modality;
    }

    public String getShipmentType() {
        return shipmentType;
    }

    public void setShipmentType(String shipmentType) {
        this.shipmentType = shipmentType;
    }

    public String getIncoterm() {
        return incoterm;
    }

    public void setIncoterm(String incoterm) {
        this.incoterm = incoterm;
    }

    public String getOriginCountry() {
        return originCountry;
    }

    public void setOriginCountry(String originCountry) {
        this.originCountry = originCountry;
    }

    public String getDestinationCountry() {
        return destinationCountry;
    }

    public void setDestinationCountry(String destinationCountry) {
        this.destinationCountry = destinationCountry;
    }

    public String getPortOfLoading() {
        return portOfLoading;
    }

    public void setPortOfLoading(String portOfLoading) {
        this.portOfLoading = portOfLoading;
    }

    public String getPortOfDestination() {
        return portOfDestination;
    }

    public void setPortOfDestination(String portOfDestination) {
        this.portOfDestination = portOfDestination;
    }

    public String getFinalDeliveryArea() {
        return finalDeliveryArea;
    }

    public void setFinalDeliveryArea(String finalDeliveryArea) {
        this.finalDeliveryArea = finalDeliveryArea;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public BigDecimal getChargeableWeight() {
        return chargeableWeight;
    }

    public void setChargeableWeight(BigDecimal chargeableWeight) {
        this.chargeableWeight = chargeableWeight;
    }

    public Integer getContainer20Qty() {
        return container20Qty;
    }

    public void setContainer20Qty(Integer container20Qty) {
        this.container20Qty = container20Qty;
    }

    public Integer getContainer40Qty() {
        return container40Qty;
    }

    public void setContainer40Qty(Integer container40Qty) {
        this.container40Qty = container40Qty;
    }

    public BigDecimal getCbm() {
        return cbm;
    }

    public void setCbm(BigDecimal cbm) {
        this.cbm = cbm;
    }

    public BigDecimal getGoodsValue() {
        return goodsValue;
    }

    public void setGoodsValue(BigDecimal goodsValue) {
        this.goodsValue = goodsValue;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getHsCode() {
        return hsCode;
    }

    public void setHsCode(String hsCode) {
        this.hsCode = hsCode;
    }

    public BigDecimal getUnitQuantity() {
        return unitQuantity;
    }

    public void setUnitQuantity(BigDecimal unitQuantity) {
        this.unitQuantity = unitQuantity;
    }

    public boolean isTradeLaneAgreement() {
        return tradeLaneAgreement;
    }

    public void setTradeLaneAgreement(boolean tradeLaneAgreement) {
        this.tradeLaneAgreement = tradeLaneAgreement;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
}