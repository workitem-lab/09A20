package com.rohlig.platform.shipment.service;

import com.rohlig.platform.shipment.events.ShipmentCreatedEvent;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class ShipmentEventProducer {
    private final KafkaTemplate<String, Object> kafkaTemplate;

    public ShipmentEventProducer(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publish(ShipmentCreatedEvent event) {
        kafkaTemplate.send("shipment.created", event.shipmentId(), event);
    }
}
