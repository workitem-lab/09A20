package com.rohlig.platform.shipment.api;
public record ApiViolation(String field, String message) {}
