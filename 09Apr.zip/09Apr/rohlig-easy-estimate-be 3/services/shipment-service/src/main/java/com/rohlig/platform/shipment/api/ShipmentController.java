package com.rohlig.platform.shipment.api;

import com.rohlig.platform.shipment.domain.ShipmentEntity;
import com.rohlig.platform.shipment.service.ShipmentService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/shipments")
public class ShipmentController {
    private static final int MAX_PAGE_SIZE = 100;

    private final ShipmentService shipmentService;

    public ShipmentController(ShipmentService shipmentService) {
        this.shipmentService = shipmentService;
    }

    @PostMapping
    public ShipmentEntity create(@RequestHeader("Idempotency-Key") String idempotencyKey,
                                 @Valid @RequestBody CreateShipmentRequest request) {
        return shipmentService.create(idempotencyKey, request);
    }

    @GetMapping("/{shipmentId}")
    public ShipmentEntity get(@PathVariable String shipmentId) {
        return shipmentService.get(shipmentId);
    }

    @GetMapping
    public PageResponse<ShipmentEntity> search(@RequestParam(required = false) String clientId,
                                               @RequestParam(required = false) String modality,
                                               @RequestParam(required = false) String shipmentType,
                                               @RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "20") int size) {
        int safePage = Math.max(page, 0);
        int safeSize = Math.min(Math.max(size, 1), MAX_PAGE_SIZE);
        Page<ShipmentEntity> result = shipmentService.search(
                clientId,
                modality,
                shipmentType,
                PageRequest.of(safePage, safeSize, Sort.by(Sort.Direction.DESC, "createdAt"))
        );
        return new PageResponse<>(result.getContent(), result.getTotalElements(), result.getTotalPages(), result.getNumber(), result.getSize());
    }

    @GetMapping("/health")
    public String health() {
        return "shipment-service running";
    }
}
