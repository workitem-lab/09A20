package com.rohlig.platform.shipment.service;

import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
public class ShipmentCreatedCommittedEventListener {
    private final ShipmentEventProducer eventProducer;

    public ShipmentCreatedCommittedEventListener(ShipmentEventProducer eventProducer) {
        this.eventProducer = eventProducer;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onCommitted(ShipmentCreatedCommittedEvent event) {
        eventProducer.publish(event.payload());
    }
}
