package com.rohlig.platform.shipment.api;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import java.math.BigDecimal;

public record CreateShipmentRequest(
        @NotBlank String shipmentId,
        @NotBlank String clientId,
        @NotBlank @Pattern(regexp = "AIR|FCL|LCL", message = "must be one of AIR, FCL, LCL") String modality,
        @NotBlank @Pattern(regexp = "IMPORT|EXPORT", message = "must be one of IMPORT, EXPORT") String shipmentType,
        @NotBlank @Pattern(regexp = "^[A-Z]{3}$", message = "must be a 3-letter incoterm") String incoterm,
        @NotBlank String originCountry,
        @NotBlank String destinationCountry,
        @NotBlank String portOfLoading,
        @NotBlank String portOfDestination,
        String finalDeliveryArea,
        String carrier,
        @NotNull @DecimalMin(value = "0.0", inclusive = false) BigDecimal chargeableWeight,
        Integer container20Qty,
        Integer container40Qty,
        @NotNull @DecimalMin(value = "0.0") BigDecimal cbm,
        @NotNull @DecimalMin(value = "0.0", inclusive = false) BigDecimal goodsValue,
        @NotBlank @Pattern(regexp = "^[A-Z]{3}$", message = "must be an ISO currency code") String currency,
        @NotBlank String hsCode,
        @NotNull @DecimalMin(value = "0.0", inclusive = false) BigDecimal unitQuantity,
        boolean tradeLaneAgreement
) {}
