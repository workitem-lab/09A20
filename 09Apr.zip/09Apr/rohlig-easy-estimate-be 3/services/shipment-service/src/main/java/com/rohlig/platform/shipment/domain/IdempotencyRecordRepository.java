package com.rohlig.platform.shipment.domain;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IdempotencyRecordRepository extends JpaRepository<IdempotencyRecord, String> {}
