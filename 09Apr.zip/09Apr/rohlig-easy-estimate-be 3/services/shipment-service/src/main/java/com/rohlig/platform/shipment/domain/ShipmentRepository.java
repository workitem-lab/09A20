package com.rohlig.platform.shipment.domain;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ShipmentRepository extends JpaRepository<ShipmentEntity, String> {

    @Query("""
            select s from ShipmentEntity s
            where (:clientId is null or s.clientId = :clientId)
              and (:modality is null or upper(s.modality) = upper(:modality))
              and (:shipmentType is null or upper(s.shipmentType) = upper(:shipmentType))
            """)
    Page<ShipmentEntity> search(@Param("clientId") String clientId,
                                @Param("modality") String modality,
                                @Param("shipmentType") String shipmentType,
                                Pageable pageable);
}
