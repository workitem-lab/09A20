CREATE SCHEMA IF NOT EXISTS shipment;

CREATE TABLE shipment.shipments (
    shipment_id VARCHAR(64) PRIMARY KEY,
    client_id VARCHAR(64) NOT NULL,
    modality VARCHAR(16) NOT NULL,
    shipment_type VARCHAR(16) NOT NULL,
    incoterm VARCHAR(16) NOT NULL,
    origin_country VARCHAR(64) NOT NULL,
    destination_country VARCHAR(64) NOT NULL,
    port_of_loading VARCHAR(128) NOT NULL,
    port_of_destination VARCHAR(128) NOT NULL,
    final_delivery_area VARCHAR(128),
    carrier VARCHAR(128),
    chargeable_weight NUMERIC(18,3) NOT NULL,
    container20_qty INTEGER,
    container40_qty INTEGER,
    cbm NUMERIC(18,3) NOT NULL,
    goods_value NUMERIC(18,2) NOT NULL,
    currency VARCHAR(16) NOT NULL,
    hs_code VARCHAR(32) NOT NULL,
    unit_quantity NUMERIC(18,3) NOT NULL,
    trade_lane_agreement BOOLEAN NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE shipment.idempotency_records (
    idempotency_key VARCHAR(200) PRIMARY KEY,
    request_hash VARCHAR(128) NOT NULL,
    resource_id VARCHAR(64) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
