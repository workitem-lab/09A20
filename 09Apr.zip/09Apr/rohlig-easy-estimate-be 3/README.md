# Röhlig Easy Estimate Backend

This repository is a production-hardened backend baseline for the Röhlig Easy Estimate platform. It keeps the existing domain split — gateway, shipment, tariff, costing, quotation, rate repository, and rates importer — while tightening the platform around the major gaps called out in the readiness review.

## What changed in this edition
- internal microservices are no longer published directly to the host in `docker-compose.yml`
- gateway routes are environment-driven instead of hardcoded to fixed container names
- repo hygiene added: root `.gitignore`, IDE/macOS artefacts removed, example env files only
- shipment, costing, and quotation search now use database paging instead of loading whole tables into memory
- shipment and cost Kafka publication now happens after DB transaction commit via Spring transactional events
- quotation template loading now resolves by template code instead of always forcing the FCL import CSV
- PDF rendering now parses CSV rows safely using Apache Commons CSV instead of fragile string splitting
- quotation branding values moved to configuration
- importer now validates file type and max file size before processing
- module test dependencies added and the repo is ready for CI execution in Bitbucket Pipelines
- container images now run as a non-root user

## Current honest status
This repo is much closer to a production-grade baseline, but it is not honestly certifiable as “100% production ready” from this environment because a full Maven build, integration test run, security scan, and deployment verification were not possible inside this container. The important production gaps that still deserve follow-through are full outbox delivery, end-to-end CI execution, environment secret management, and formal runtime verification.

## Services
- `gateway`
- `shipment-service`
- `tariff-service`
- `costing-service`
- `quotation-service`
- `rate-repository-service`
- `rates-importer-service`

## Local start
1. Copy the example env file.
2. Set your own local credentials.
3. Start the platform.

```bash
cp .env.example .env
# edit .env with your own local values

docker compose build --no-cache
docker compose up -d
```

## Local smoke test
```bash
./scripts/test-e2e.sh
```

## Security notes
- never commit `.env`
- the Keycloak realm import under `infra/keycloak/realm-import` is development bootstrap data only
- create real service-client secrets and user accounts in the target environment
- keep all business traffic going through the gateway in normal environments

## CI
A baseline Bitbucket pipeline is included in `bitbucket-pipelines.yml`.

## Next hardening steps
1. implement a real outbox pattern for shipment and costing events
2. add Testcontainers-backed integration tests per service
3. move secrets to Vault / Kubernetes secrets / cloud secret manager
4. add structured logs, tracing, and operational alerts
5. move generated quotation binaries to object storage if volume grows


## Customer integration capability

This edition adds a dedicated `customer-integration-service` to support prospect creation, ShipShip linkage, registered customer sync, and customer identity mapping (`easy_estimate_client_id` -> `shipship_client_code`).

### Core APIs
- `POST /api/v1/customers/prospects`
- `POST /api/v1/customers/{easyEstimateClientId}/link`
- `POST /api/v1/customers/registered/sync`
- `GET /api/v1/customers/{easyEstimateClientId}`
- `GET /api/v1/customers/resolve/by-shipship/{shipshipClientCode}`
- `GET /api/v1/customers`
