# Quotation templates

Maintain business-owned XLSX templates outside the Java code.

Recommended logical templates:
- QUOTE_FCL_IMPORT
- QUOTE_FCL_EXPORT
- QUOTE_LCL_IMPORT
- QUOTE_AIR_IMPORT
- QUOTE_AIR_EXPORT
- QUOTE_ROAD_EXPORT

The quotation-service currently stores the selected `templateCode` on each projection. A later implementation can render XLSX and convert to PDF.
