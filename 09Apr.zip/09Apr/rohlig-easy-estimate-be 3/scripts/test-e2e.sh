#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:8080}"
ACCESS_TOKEN="${ACCESS_TOKEN:-}"

curl -s "$BASE_URL/api/v1/shipments/health" && echo
curl -s "$BASE_URL/api/v1/costs/health" && echo
curl -s "$BASE_URL/api/v1/quotations/health" && echo
curl -s "$BASE_URL/api/v1/rates-importer/health" && echo

if [[ -z "$ACCESS_TOKEN" ]]; then
  echo "ACCESS_TOKEN is not set. Health checks completed. Export ACCESS_TOKEN to run authenticated flows."
  exit 0
fi

curl -s -X POST "$BASE_URL/api/v1/shipments" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: shipment-create-001" \
  -H "X-Correlation-Id: demo-correlation-001" \
  -d @samples/fcl-import-shipment.json

echo
sleep 5
curl -s -H "Authorization: Bearer $ACCESS_TOKEN" "$BASE_URL/api/v1/costs/SHIP-1001" && echo
curl -s -H "Authorization: Bearer $ACCESS_TOKEN" "$BASE_URL/api/v1/quotations/SHIP-1001" && echo
