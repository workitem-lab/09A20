# Quote template strategy

Use professionally designed XLSX templates as the source of truth for quote layouts.

## Recommended templates
- QUOTE_FCL_IMPORT
- QUOTE_FCL_EXPORT
- QUOTE_LCL_IMPORT
- QUOTE_AIR_IMPORT
- QUOTE_AIR_EXPORT
- QUOTE_ROAD_EXPORT

## Best practice
- business owns the XLSX layout
- backend fills template placeholders
- backend can optionally convert the finished workbook to PDF
- template versioning should be tracked outside the calculation code
