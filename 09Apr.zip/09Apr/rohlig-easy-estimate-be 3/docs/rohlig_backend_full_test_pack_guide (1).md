# Rohlig Backend Full Test Pack

This pack contains **80 requests**.

## Included areas
- platform and health checks
- shipment happy paths
- shipment validation and negative cases
- cost retrieval cases
- quotation retrieval cases
- support service endpoint discovery
- async and idempotency scenarios
- extra scenario variants

## Import steps
1. Import the collection JSON into Postman
2. Import the environment JSON
3. Select the **Rohlig Local Full Test** environment

## Suggested execution order
1. `01 Platform & Health`
2. `02 Shipment Happy Path`
3. `04 Cost Retrieval Cases`
4. `05 Quotation Retrieval Cases`
5. `03 Shipment Validations & Negative Cases`
6. `07 Async Flow & Idempotency Scenarios`
7. `08 Additional Scenario Variants`

## Notes
- Some tests intentionally expect `404`, `405`, `400`, `415`, or `422`
- Some async checks allow `200` or `404` because event processing timing can vary
- The rate repository and rates importer currently expose Actuator health, not custom `/api/v1/.../health` routes
- The create shipment requests include idempotency headers where needed