# Keycloak + Active Directory integration

Recommended enterprise pattern:

AD / LDAP -> Keycloak -> Gateway -> Microservices

## Why
- microservices do not bind directly to AD
- gateway becomes the enforcement point
- Keycloak handles federation, login, roles, and JWT issuance

## Minimum implementation path
1. deploy Keycloak
2. federate Keycloak with AD / LDAP
3. map AD groups to application roles
4. secure the gateway as an OAuth2 resource server
5. keep business authorization in services only where required
