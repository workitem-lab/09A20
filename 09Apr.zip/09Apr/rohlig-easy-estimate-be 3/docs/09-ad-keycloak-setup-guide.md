# Röhlig Easy Estimate — AD / Entra ID + Keycloak Setup Guide

This guide explains how to use Microsoft Active Directory / Microsoft Entra ID together with Keycloak, what each one does, the setup steps, and exactly what information you need from the AD / Entra team.

## 1. What each platform does

### Microsoft AD / Entra ID
Use Microsoft Entra ID as the **corporate identity source**.

It is responsible for:
- employee identities
- company sign-in
- MFA
- Conditional Access
- corporate user lifecycle
- groups and directory management

Microsoft documents OpenID Connect endpoints under the tenant authority plus the OpenID well-known configuration path, and Entra app registrations are the standard way to onboard applications. citeturn751949search0turn751949search2

### Keycloak
Use Keycloak as the **application-facing identity broker and token issuer**.

It is responsible for:
- brokering login to Entra ID
- presenting one identity layer to your apps
- issuing the tokens your backend trusts
- claim and role mapping
- future support for additional identity providers
- one unified login architecture for apps and APIs

Keycloak supports identity brokering with external OpenID Connect or SAML providers and exposes standard OIDC endpoints for applications. citeturn751949search1turn751949search8

## 2. Recommended architecture

Use this flow:

`User -> Angular frontend -> Keycloak -> Microsoft Entra ID -> Keycloak -> Gateway -> Microservices`

### Why this is a good design
- employees still use company accounts from Entra ID
- Keycloak becomes the consistent IAM layer for your apps
- the backend trusts only Keycloak tokens
- future external users or other IdPs can be added later without changing the backend security model

## 3. When to use Entra directly instead of Keycloak

Use Entra directly when:
- all users are internal employees
- you want the simplest setup
- you do not need identity brokering now
- you want fewer moving parts

Use Keycloak with Entra when:
- you want one IAM layer for applications
- you expect future partner/customer access
- you want custom claims, login flows, or vendor-neutral application auth
- you want to hide Microsoft-specific identity details from the backend

## 4. What you need from the AD / Entra team

Before you can connect Keycloak to Entra ID, request these items.

### Tenant details
- Tenant ID
- Tenant name or primary domain
- confirmation whether login is single-tenant or multi-tenant

### App registration details
Create or request an Entra app registration for Keycloak brokering.

You need:
- Client ID (Application ID)
- Client secret value
- authority / issuer base:
  - `https://login.microsoftonline.com/<TENANT_ID>/v2.0`
- OpenID Connect metadata endpoint:
  - `https://login.microsoftonline.com/<TENANT_ID>/v2.0/.well-known/openid-configuration`

Microsoft documents the authority format and well-known discovery endpoint for OpenID Connect. citeturn751949search0

### Redirect URIs
The AD / Entra team must allow the Keycloak redirect URI in the app registration.

Typical Keycloak broker callback pattern:
- `https://<keycloak-host>/realms/<realm>/broker/<provider-alias>/endpoint`

You must confirm the final Keycloak hostname before they register it.

### Logout / post-logout URLs
If you want clean logout flows, also request approval for the relevant post-logout redirect URI used by Keycloak and your frontend.

### Claims / identity requirements
Ask what user attributes must come back from Entra:
- email
- preferred username / UPN
- display name
- given name
- surname
- groups, if needed

### Roles / groups
Decide whether backend authorization will come from:
- Entra app roles
- Entra groups
- or Entra groups mapped to Keycloak roles

Microsoft supports app roles and token claims for authorization models. citeturn751949search10turn751949search19

### Security policies to confirm
Ask whether these apply:
- MFA required
- Conditional Access rules
- allowed user scope (all users, one group, selected users only)
- guest/external users allowed or not

## 5. What Keycloak needs to be configured with

In Keycloak, configure Entra ID as an external OpenID Connect identity provider.

You will need:
- Alias, for example `entra`
- Display name, for example `Microsoft Entra ID`
- Authorization URL
- Token URL
- User Info URL if used
- Issuer
- Client ID
- Client secret
- Default scopes, usually:
  - `openid`
  - `profile`
  - `email`

Keycloak supports brokering to external OIDC providers in the admin console. citeturn751949search1turn751949search3

## 6. End-to-end setup steps

## Step 1 — Decide the identity model
Choose one of these:
- Entra directly to backend
- Keycloak brokering Entra to backend

For this guide, use:
- Keycloak in front
- Entra as identity source

## Step 2 — Get the Entra details
Collect:
- Tenant ID
- Client ID
- Client secret
- issuer / well-known endpoint
- approved redirect URI
- required claims
- required role or group model

## Step 3 — Create the Keycloak realm
In Keycloak:
- create realm, for example `rohlig-easy-estimate`
- create frontend client for Angular
- create backend audience/client if needed
- create realm roles like:
  - `ADMIN`
  - `OPERATIONS_USER`
  - `QUOTATION_USER`
  - `RATES_ADMIN`
  - `VIEW_ONLY`

## Step 4 — Add Entra as an identity provider in Keycloak
In Keycloak admin console:
- Identity Providers
- Add provider
- OpenID Connect v1.0

Fill:
- alias: `entra`
- client ID
- client secret
- discovery endpoint or explicit auth/token URLs
- scopes: `openid profile email`

## Step 5 — Map claims and roles
Configure mappers so Keycloak receives and exposes:
- username
- email
- display name
- groups or app roles

Then map:
- Entra roles/groups -> Keycloak roles

## Step 6 — Configure Angular to log in through Keycloak
Angular should use:
- Authorization Code Flow with PKCE
- Keycloak as the authority
- not direct Entra login

## Step 7 — Configure backend to trust Keycloak
Gateway and microservices should validate Keycloak JWTs.

Backend issuer should point to Keycloak, not directly to Entra, if Keycloak is the token issuer for apps.

## Step 8 — Test login
Test:
1. user opens frontend
2. frontend redirects to Keycloak
3. Keycloak redirects to Entra
4. user signs in with company account
5. Entra returns to Keycloak
6. Keycloak issues token
7. frontend calls gateway
8. backend validates Keycloak token

## 7. Backend config model when using Keycloak

If backend trusts Keycloak, your Spring Boot services should use Keycloak issuer settings, for example:

```yaml
spring:
  security:
    oauth2:
      resourceserver:
        jwt:
          issuer-uri: https://<keycloak-host>/realms/rohlig-easy-estimate
```

Then role extraction should use the token claims Keycloak issues.

## 8. What to ask the AD / Entra team in one message

Use something like this:

```text
We are integrating the Röhlig Easy Estimate platform with Microsoft Entra ID through Keycloak as an OpenID Connect broker.

Please provide or configure the following for the Entra application registration:

1. Tenant ID
2. Client ID
3. Client secret
4. OpenID Connect issuer / discovery endpoint
5. Approval of the redirect URI:
   https://<keycloak-host>/realms/<realm>/broker/<provider-alias>/endpoint
6. Confirmation of required user claims:
   email, username/UPN, display name, given name, surname
7. Confirmation whether authorization should use app roles, groups, or both
8. Confirmation whether MFA / Conditional Access applies
9. Confirmation whether access is single-tenant and restricted to internal users only
```

## 9. Minimum values you must have before starting

At minimum, you need:
- Tenant ID
- Client ID
- Client secret
- issuer / well-known OIDC endpoint
- redirect URI approved in Entra
- role/group strategy agreed

Without these, Keycloak cannot complete the Entra connection.

## 10. Recommended Röhlig decision

For Röhlig Easy Estimate, the best staged approach is:

### Phase 1
- Entra as identity source
- Keycloak as broker and token issuer
- backend trusts Keycloak only
- internal employees only

### Phase 2
- map Entra groups/app roles to Keycloak roles
- protect gateway and all services
- add UI role-based behavior

### Phase 3
- optional external user/partner support
- additional identity providers if needed

## 11. Important operational note

Keep these values documented centrally:
- Entra Tenant ID
- Entra Client ID
- Keycloak realm name
- Keycloak provider alias
- redirect URIs
- backend issuer URI
- frontend redirect URI
- role mapping rules

If one changes, update:
- Keycloak IdP config
- frontend auth config
- backend issuer config
- environment files
- documentation

## 12. Source-backed points

- Microsoft Entra OIDC authority and discovery endpoint pattern are documented by Microsoft. citeturn751949search0
- Entra app registration is the standard onboarding model for apps. citeturn751949search2
- Entra app roles are the right basis for application authorization design. citeturn751949search10turn751949search19
- Keycloak supports identity brokering with external OIDC/SAML identity providers. citeturn751949search1turn751949search3
- Keycloak exposes standard OIDC endpoints for downstream applications. citeturn751949search8
