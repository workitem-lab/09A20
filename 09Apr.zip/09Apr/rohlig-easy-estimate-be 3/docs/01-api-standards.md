# API Standards

## Versioning
Public routes use `/api/v1`.

## Idempotency
Write operations support `Idempotency-Key`:
- `POST /api/v1/shipments`
- `POST /api/v1/costs/recalculate`

Reusing the same key with a different request fingerprint returns `409 IDEMPOTENCY_CONFLICT`.

## Search and pagination
List endpoints support `page` and `size`.
Resource filters:
- shipments: `clientId`, `modality`, `shipmentType`
- costs: `clientId`, `modality`, `shipmentType`
- invoices: `clientId`, `status`

## Unified error model
All services return the same error shape with `code`, `message`, `path`, `correlationId`, and `violations`.
