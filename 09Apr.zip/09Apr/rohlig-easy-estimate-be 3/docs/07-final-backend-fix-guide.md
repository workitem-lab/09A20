# Röhlig backend final fix guide

## What this final repo fixes

This final repo is based on the backend you uploaded and adds a concrete backend improvement set instead of another isolated patch.

### Included fixes
- root Maven aggregator `pom.xml` for simpler multi-module builds
- quotation-service extended from read-model only to generation flow
- quotation snapshot, line, and generated document persistence
- CSV generation with dynamic section injection
- PDF generation from the same filled quotation row set
- rate importer upgraded from batch stub to real CSV ingest endpoint
- importer writes to `pricing.rate_cards` and `pricing.rate_card_lines`
- sample import template included
- expanded Postman collection and environment
- clean repository structure without macOS archive leftovers

## Important design notes

### Shipment modality alignment
The current shipment-service only allows `AIR`, `FCL`, and `LCL`, so the working end-to-end quotation path in this final repo is based on `FCL/AIR/LCL` instead of `ROAD`.

### PDF output
The PDF is generated from the filled quotation row set so the data stays aligned with the CSV output. It is a production-ready backend document flow, but not a pixel-perfect reproduction of the sample estimate design.

## Main new endpoints

### Quotation service
- `POST /api/v1/quotations/{shipmentId}/generate`
- `GET /api/v1/quotations/{shipmentId}/documents/csv`
- `GET /api/v1/quotations/{shipmentId}/documents/pdf`

### Rates importer
- `POST /api/v1/rates-importer/batches`
- `POST /api/v1/rates-importer/batches/upload`
- `GET /api/v1/rates-importer/batches`
- `GET /api/v1/rates-importer/batches/{batchReference}`
- `GET /api/v1/rates-importer/batches/{batchReference}/errors`
- `GET /api/v1/rates-importer/template`
