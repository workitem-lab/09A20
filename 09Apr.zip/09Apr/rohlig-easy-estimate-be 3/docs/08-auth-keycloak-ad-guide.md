# Röhlig Easy Estimate Backend Auth Guide

This repo now uses Spring Security OAuth2 Resource Server across the gateway and backend services. Spring Boot can configure a resource server from JWT support plus issuer/JWK configuration, and Keycloak supports acting as the OpenID Connect provider and broker for external identity providers like Microsoft Entra ID. See the official Spring resource server docs and Keycloak OIDC / identity brokering docs for the underlying model. citeturn812930search0turn812930search4turn812930search3turn812930search1

## Architecture

- Keycloak is the app-facing identity layer
- Microsoft Entra ID / AD is the corporate identity source
- Gateway validates JWTs and exposes `/api/v1/auth/me`
- Backend services validate the same JWTs
- Quotation and costing use a confidential service client for internal REST calls

## Roles

Realm roles expected in Keycloak:
- ADMIN
- OPERATIONS_USER
- QUOTATION_USER
- RATES_ADMIN
- VIEW_ONLY

## Docker

`docker-compose.yml` now includes a local Keycloak container on port `8090` with a realm import for local testing. Use the admin credentials from `.env`. The imported realm includes:
- local test users
- a public frontend client
- a confidential `easy-estimate-services` client for service-to-service tokens

For a real AD / Entra integration, configure Microsoft Entra ID as an external OpenID Connect identity provider in Keycloak and map Entra groups or app roles to the realm roles above. Keycloak documents identity brokering with external OpenID Connect providers, and Microsoft documents the OpenID Connect authority and well-known configuration endpoints you need from the Entra side. citeturn812930search3turn812930search1turn812930search0

## What you need from the AD / Entra team

- Tenant ID
- Client ID for the Entra app registration used by Keycloak brokering
- Client secret
- OIDC discovery endpoint
- Approval for the Keycloak broker redirect URI
- Confirmation whether authorization is based on app roles, groups, or both

## Local test users

- create a local admin account in Keycloak
- create a quotation test user in Keycloak
- create an operations test user in Keycloak
- create a rates admin test user in Keycloak

## Run

1. `cp .env.example .env` and set local values
2. `docker compose up --build -d`
3. Open Keycloak at `http://localhost:8090`
4. Get a user token from Keycloak and call gateway `/api/v1/auth/me`
5. Call secured backend endpoints through gateway

## Important notes

- Health endpoints stay open
- Internal REST calls use client credentials
- `rates-importer-service` now uses schema `pricing_import` to avoid Flyway collisions with `rate-repository-service`
