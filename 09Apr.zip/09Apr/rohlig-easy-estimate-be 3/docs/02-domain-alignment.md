# Domain alignment in this rebuild

This rebuild is aligned to the uploaded rule catalogue and ERD notes.

## Why quotation-service instead of invoice-service
The uploaded functional notes describe estimate / quote templates for FCL import, FCL export, LCL import, Air import, Air export, and Road export, and explicitly call out that the current invoice service should really be a quotation or quote service. This rebuild therefore uses `quotation-service` as the business-facing name and keeps `/api/v1/invoices/**` as a temporary compatibility alias.

## Current bounded contexts
- shipment-service: operational shipment capture
- tariff-service: tariff, customs, finance, ROE resolution
- costing-service: cost calculation and persistence
- quotation-service: projected commercial quote output
- rate-repository-service: rate card catalogue API
- rates-importer-service: import batch tracking API

## Recommended next step
Move tariff-service from summary outputs to explicit charge-definition outputs so costing can execute Air, FCL, and LCL calculators with richer line-level transparency.
