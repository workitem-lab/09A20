# Summary of changes applied to this backend edition

## Repository hygiene
- removed `.idea` and `.DS_Store`
- added root `.gitignore`
- replaced committed runtime env files with `.env.example` and `.env.rohligplatform.example`

## Runtime / infrastructure
- hardened `docker-compose.yml` to keep internal services off host ports
- added service healthchecks and restart policy
- updated all Dockerfiles to run as non-root
- added `bitbucket-pipelines.yml`

## Configuration
- externalized gateway route URIs via environment variables
- added graceful shutdown and health probe config across services
- added Hikari pool settings and `open-in-view: false`
- added quotation branding properties

## Backend behaviour
- shipment, costing, and quotation searches now page/filter at repository level
- shipment and costing publish Kafka messages after transaction commit
- quotation renderer now resolves the correct template path per template code
- PDF renderer now parses CSV safely with Apache Commons CSV
- importer validates file size and file extension before import

## Tests
- added starter unit tests for calculation logic and quotation rendering/template resolution

- added `customer-integration-service` for prospect creation, ShipShip linkage, and registered customer sync
- corrected Docker Compose Postgres healthcheck escaping to avoid unhealthy false negatives
- added gateway route and role policy for customer APIs
- added prospect pricing fallback rules in tariff-service for `EE-PROSPECT-*` customer identifiers
