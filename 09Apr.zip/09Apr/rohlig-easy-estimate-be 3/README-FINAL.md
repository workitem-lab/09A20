# Röhlig backend final repo

This repo is the corrected backend package based on the uploaded source.

## Included in this final package
- quotation generation flow with CSV + PDF output
- importer upload flow
- root Maven aggregator
- sample rate import template
- extended Postman collection with approximately 109 requests
- final backend fix guide in `docs/07-final-backend-fix-guide.md`

## Main caveat
This environment was prepared by static code review and patching. It was not fully compiled inside this chat container because Maven is not installed here.
