# Production hardening notes

This edition addresses the highest-value issues from the readiness review, but a real production sign-off still requires runtime verification.

## Implemented in this repo
- secure-ish local compose posture with internal services hidden from host exposure
- environment-driven gateway routing
- non-root runtime Dockerfiles
- root `.gitignore` and removal of IDE / macOS repo noise
- sanitized example env files instead of committed runnable secrets
- database-backed paging for shipment / costing / quotation searches
- after-commit Kafka publication in shipment and costing services
- safer quotation template resolution and PDF rendering
- importer file-size and file-type validation
- baseline CI pipeline file
- test dependency setup and starter test classes

## Still recommended before a live production cutover
- outbox pattern with replay capability
- dead-letter topics and consumer retry tuning verified in environment
- SAST / dependency scanning / image scanning wired into CI
- formal load testing and resilience testing
- TLS termination, ingress policy, WAF, and secret-store integration
- backup / restore drills and DR runbook
- operational alerting and on-call dashboards
