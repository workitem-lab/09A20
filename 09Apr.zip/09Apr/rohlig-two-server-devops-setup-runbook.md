# Röhlig Two-Server DevOps Setup Guide

## Purpose

This document is a practical, end-to-end setup guide for a **two-server Röhlig DevOps deployment** using:

- **Ubuntu Server 22.04.4 LTS**
- **Bitbucket Cloud**
- **Bitbucket Pipelines with a self-hosted runner**
- **Optional Jenkins**
- **Spring Boot backend**
- **Angular frontend**
- **Kafka**
- **Docker Engine and Docker Compose plugin**
- **SSH-based deployment from the CI/CD server to the application server**

The guide is written to be executable in the real environment you provided and includes the commands to connect, validate, prepare, deploy, test, monitor, troubleshoot, and roll back.

---

## Environment Inventory

### Server 1 — CI/CD Server

- **Hostname / Name:** `RGZACICD`
- **IP:** `172.84.39.88`
- **SSH User:** `RTITDrrev`
- **OS:** `Ubuntu Server 22.04.4 LTS`
- **RAM:** `24 GB`
- **Disk:** `500 GB HDD`
- **Primary role:** Bitbucket runner, deployment orchestrator, optional Jenkins, optional central monitoring

### Server 2 — Application Server

- **Hostname / Name:** `RGZADEVOPS01`
- **IP:** `172.38.89.25`
- **SSH User:** `RTRITDev`
- **OS:** `Ubuntu Server 22.04.4 LTS`
- **RAM:** `24 GB`
- **Disk:** `2 TB HDD`
- **Primary role:** Docker Compose application runtime for frontend, backend, Kafka, and supporting services

> **Important security note**
>
> You already have the passwords. Do **not** put passwords into shell scripts, `.env` files, or pipeline YAML. Use the password only for the first login, then move immediately to **SSH key-based authentication**.

---

## Target Operating Model

The target design for this two-server setup is:

- `RGZACICD` runs the **Bitbucket self-hosted runner**.
- Pipelines execute build, test, package, and deployment steps on the CI/CD server.
- The CI/CD server connects to `RGZADEVOPS01` over **SSH** using a key.
- The application server hosts the runtime stack using **Docker Compose**.
- The deployment process copies the release bundle to the application server and runs `docker compose up -d --build`.
- Kafka stays on the application server and is **not exposed publicly** unless there is a hard requirement.
- Optional Jenkins can run on the CI/CD server, but **Bitbucket Pipelines remains the primary CI/CD path**.

This model is practical for a two-server setup because it is:

- easy to operate,
- simple to explain to management,
- fast to implement,
- aligned with your current SSH-based deployment approach,
- and avoids unnecessary infrastructure complexity.

---

## Deployment Architecture

```text
Developer
   |
   v
Bitbucket Cloud Repository
   |
   v
Bitbucket Pipelines
   |
   v
Self-Hosted Runner on RGZACICD (172.84.39.88)
   |
   |  SSH with private key
   v
RGZADEVOPS01 (172.38.89.25)
   |
   +--> Angular frontend container (served by Nginx)
   +--> Spring Boot backend container(s)
   +--> Kafka container
   +--> PostgreSQL container or external DB
   +--> Reverse proxy / shared network / volumes / logs
```

---

## What You Will Configure

By the end of this guide, you will have:

1. verified access to both servers,
2. validated host health and Docker readiness,
3. hardened both Ubuntu servers,
4. configured SSH key-based deployment,
5. prepared the directory structure,
6. installed a Bitbucket self-hosted runner on `RGZACICD`,
7. created an application deployment layout on `RGZADEVOPS01`,
8. created Compose files for frontend, backend, Kafka, and optional database,
9. created a pipeline file that deploys over SSH,
10. validated the deployment,
11. set up monitoring,
12. documented rollback and troubleshooting commands.

---

# 1. Connect to Both Servers and Verify Baseline State

## 1.1 Connect to the CI/CD server

From your local machine:

```bash
ssh RTITDrrev@172.84.39.88
```

When prompted, enter the password manually.

## 1.2 Connect to the application server

From your local machine:

```bash
ssh RTRITDev@172.38.89.25
```

When prompted, enter the password manually.

## 1.3 Run baseline validation on each server

Run the following commands on **both servers**.

```bash
hostnamectl
uname -a
lsb_release -a
whoami
pwd
ip a
free -h
df -h
lsblk
nproc
sudo systemctl status docker --no-pager
sudo docker --version
sudo docker compose version
sudo docker info | head -40
sudo ss -tulpn
```

These commands confirm:

- host identity,
- OS version,
- RAM,
- disk layout,
- CPU count,
- Docker availability,
- open ports,
- and whether the Docker daemon is healthy.

## 1.4 Save the outputs for your records

On each server, create a baseline file:

```bash
mkdir -p ~/server-baseline
{
  echo '===== HOSTNAME ====='
  hostnamectl
  echo
  echo '===== OS ====='
  lsb_release -a
  echo
  echo '===== CPU ====='
  nproc
  echo
  echo '===== MEMORY ====='
  free -h
  echo
  echo '===== DISK ====='
  df -h
  echo
  echo '===== BLOCK DEVICES ====='
  lsblk
  echo
  echo '===== DOCKER ====='
  sudo docker --version
  sudo docker compose version
  echo
  echo '===== PORTS ====='
  sudo ss -tulpn
} | tee ~/server-baseline/initial-baseline.txt
```

---

# 2. Perform Common Ubuntu Preparation on Both Servers

Run this section on **both** `RGZACICD` and `RGZADEVOPS01`.

## 2.1 Update packages

```bash
sudo apt update && sudo apt upgrade -y
sudo apt autoremove -y
sudo apt autoclean -y
```

## 2.2 Install operational utilities

```bash
sudo apt install -y \
  curl \
  wget \
  git \
  unzip \
  zip \
  jq \
  vim \
  nano \
  htop \
  tree \
  net-tools \
  dnsutils \
  ca-certificates \
  gnupg \
  lsb-release \
  software-properties-common \
  openssh-client \
  openssh-server \
  rsync
```

## 2.3 Confirm time zone

For South Africa:

```bash
sudo timedatectl set-timezone Africa/Johannesburg
timedatectl
```

## 2.4 Confirm Docker starts automatically

```bash
sudo systemctl enable docker
sudo systemctl restart docker
sudo systemctl status docker --no-pager
```

## 2.5 Add your login user to the docker group

Run this on each server using the relevant logged-in user.

### On `RGZACICD`

```bash
sudo usermod -aG docker RTITDrrev
```

### On `RGZADEVOPS01`

```bash
sudo usermod -aG docker RTRITDev
```

Apply the new group membership by logging out and back in, or run:

```bash
newgrp docker
```

Validate:

```bash
docker ps
docker compose version
```

## 2.6 Configure UFW firewall

### On the CI/CD server

```bash
sudo ufw allow OpenSSH
sudo ufw allow 8080/tcp
sudo ufw allow 3000/tcp
sudo ufw allow 9090/tcp
sudo ufw allow 9100/tcp
sudo ufw enable
sudo ufw status verbose
```

Use:

- `8080` for optional Jenkins,
- `3000` for Grafana,
- `9090` for Prometheus,
- `9100` if you expose node exporter on the CI/CD host.

### On the application server

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow from 172.84.39.88 to any port 9100 proto tcp
sudo ufw enable
sudo ufw status verbose
```

Do **not** expose Kafka (`9092`) publicly unless there is a confirmed external requirement.

---

# 3. Make SSH Easier and Safer

## 3.1 Create an SSH config on your local machine

On your local machine:

```bash
mkdir -p ~/.ssh
chmod 700 ~/.ssh
nano ~/.ssh/config
```

Add:

```text
Host rgza-cicd
  HostName 172.84.39.88
  User RTITDrrev

Host rgza-app
  HostName 172.38.89.25
  User RTRITDev
```

Then use:

```bash
ssh rgza-cicd
ssh rgza-app
```

---

# 4. Configure Key-Based SSH from CI/CD Server to Application Server

This is one of the most important sections. The pipeline will deploy from `RGZACICD` to `RGZADEVOPS01` over SSH.

## 4.1 Generate a dedicated deployment SSH key on `RGZACICD`

SSH to the CI/CD server:

```bash
ssh RTITDrrev@172.84.39.88
```

Create the key:

```bash
mkdir -p ~/.ssh
chmod 700 ~/.ssh
ssh-keygen -t ed25519 -C "rohlig-deploy-key" -f ~/.ssh/rohlig_deploy_key
```

When asked for a passphrase, for automation you can leave it empty.

Validate files:

```bash
ls -la ~/.ssh/
```

## 4.2 Copy the public key to the application server

From `RGZACICD`, run:

```bash
ssh-copy-id -i ~/.ssh/rohlig_deploy_key.pub RTRITDev@172.38.89.25
```

Enter the application server password when prompted.

## 4.3 Test passwordless access

From `RGZACICD`:

```bash
ssh -i ~/.ssh/rohlig_deploy_key RTRITDev@172.38.89.25 "hostname && whoami && docker ps"
```

You should see the app server hostname, the user, and the Docker process list without a password prompt.

## 4.4 Add a deployment SSH config on `RGZACICD`

On `RGZACICD`:

```bash
nano ~/.ssh/config
```

Add:

```text
Host rohlig-app
  HostName 172.38.89.25
  User RTRITDev
  IdentityFile ~/.ssh/rohlig_deploy_key
  StrictHostKeyChecking accept-new
```

Test:

```bash
ssh rohlig-app "hostname && date"
```

---

# 5. Create the Server Directory Layout

## 5.1 Directory layout on `RGZACICD`

On the CI/CD server:

```bash
mkdir -p ~/rohlig/{runner,scripts,artifacts,logs,monitoring,jenkins}
tree -L 2 ~/rohlig
```

## 5.2 Directory layout on `RGZADEVOPS01`

On the application server:

```bash
sudo mkdir -p /opt/rohlig/{app,compose,env,logs,backups,releases,scripts,data}
sudo chown -R RTRITDev:RTRITDev /opt/rohlig

tree -L 2 /opt/rohlig
```

Recommended layout:

```text
/opt/rohlig/
  app/          # current deployed app code or release content
  compose/      # docker-compose files
  env/          # environment files
  logs/         # host-side logs if needed
  backups/      # config and DB backups
  releases/     # timestamped releases
  scripts/      # operational scripts
  data/         # Docker bind mounts for persistent services
```

---

# 6. Validate Docker Compose End-to-End

Run these tests now so that problems are detected early.

## 6.1 On the CI/CD server

```bash
docker run --rm hello-world
docker compose version
```

## 6.2 On the application server

```bash
docker run --rm hello-world
docker compose version
```

## 6.3 Compose smoke test on the application server

```bash
cat > /tmp/compose-smoke.yml <<'YAML'
services:
  smoke:
    image: nginx:alpine
    ports:
      - "8099:80"
YAML

docker compose -f /tmp/compose-smoke.yml up -d
sleep 5
curl -I http://localhost:8099
docker compose -f /tmp/compose-smoke.yml down -v
rm -f /tmp/compose-smoke.yml
```

---

# 7. Prepare the Application Runtime on `RGZADEVOPS01`

This section creates a production-style Docker Compose deployment structure.

## 7.1 Create the application environment file

On the application server:

```bash
nano /opt/rohlig/env/app.env
```

Use a structure like this and replace values with your actual application values:

```dotenv
SPRING_PROFILES_ACTIVE=prod
SERVER_PORT=8080
TZ=Africa/Johannesburg

POSTGRES_DB=rohlig
POSTGRES_USER=rohlig
POSTGRES_PASSWORD=CHANGE_ME_DB_PASSWORD
POSTGRES_HOST=postgres
POSTGRES_PORT=5432

KAFKA_BOOTSTRAP_SERVERS=kafka:9092
KAFKA_TOPIC_SHIPMENT_CREATED=shipment.created
KAFKA_TOPIC_COST_CALCULATED=cost.calculated

APP_IMAGE_BACKEND=rohlig-backend:latest
APP_IMAGE_FRONTEND=rohlig-frontend:latest
```

Lock down permissions:

```bash
chmod 600 /opt/rohlig/env/app.env
```

## 7.2 Create persistent data directories

```bash
mkdir -p /opt/rohlig/data/{postgres,kafka,nginx,frontend}
```

## 7.3 Create the production Docker Compose file

```bash
nano /opt/rohlig/compose/docker-compose.prod.yml
```

Paste the following example and adjust names or images to your actual repo output.

```yaml
services:
  postgres:
    image: postgres:16
    container_name: rohlig-postgres
    restart: unless-stopped
    env_file:
      - /opt/rohlig/env/app.env
    environment:
      POSTGRES_DB: ${POSTGRES_DB}
      POSTGRES_USER: ${POSTGRES_USER}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      TZ: ${TZ}
    ports:
      - "127.0.0.1:5432:5432"
    volumes:
      - /opt/rohlig/data/postgres:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}"]
      interval: 10s
      timeout: 5s
      retries: 10
    networks:
      - rohlig-net

  kafka:
    image: bitnami/kafka:3.7
    container_name: rohlig-kafka
    restart: unless-stopped
    env_file:
      - /opt/rohlig/env/app.env
    environment:
      - KAFKA_CFG_NODE_ID=1
      - KAFKA_CFG_PROCESS_ROLES=broker,controller
      - KAFKA_CFG_CONTROLLER_LISTENER_NAMES=CONTROLLER
      - KAFKA_CFG_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093
      - KAFKA_CFG_ADVERTISED_LISTENERS=PLAINTEXT://kafka:9092
      - KAFKA_CFG_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT,CONTROLLER:PLAINTEXT
      - KAFKA_CFG_CONTROLLER_QUORUM_VOTERS=1@kafka:9093
      - KAFKA_CFG_INTER_BROKER_LISTENER_NAME=PLAINTEXT
      - KAFKA_CFG_AUTO_CREATE_TOPICS_ENABLE=true
      - KAFKA_KRAFT_CLUSTER_ID=abcdefghijklmnopqrstuv
      - ALLOW_PLAINTEXT_LISTENER=yes
    volumes:
      - /opt/rohlig/data/kafka:/bitnami/kafka
    healthcheck:
      test: ["CMD-SHELL", "bash -c 'exec 3<>/dev/tcp/127.0.0.1/9092'"]
      interval: 15s
      timeout: 5s
      retries: 10
    networks:
      - rohlig-net

  backend:
    image: rohlig-backend:latest
    container_name: rohlig-backend
    restart: unless-stopped
    env_file:
      - /opt/rohlig/env/app.env
    depends_on:
      postgres:
        condition: service_healthy
      kafka:
        condition: service_started
    environment:
      SPRING_PROFILES_ACTIVE: ${SPRING_PROFILES_ACTIVE}
      SERVER_PORT: ${SERVER_PORT}
      TZ: ${TZ}
      SPRING_DATASOURCE_URL: jdbc:postgresql://postgres:5432/${POSTGRES_DB}
      SPRING_DATASOURCE_USERNAME: ${POSTGRES_USER}
      SPRING_DATASOURCE_PASSWORD: ${POSTGRES_PASSWORD}
      SPRING_KAFKA_BOOTSTRAP_SERVERS: ${KAFKA_BOOTSTRAP_SERVERS}
    ports:
      - "127.0.0.1:8080:8080"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/actuator/health"]
      interval: 20s
      timeout: 5s
      retries: 10
    networks:
      - rohlig-net

  frontend:
    image: rohlig-frontend:latest
    container_name: rohlig-frontend
    restart: unless-stopped
    depends_on:
      backend:
        condition: service_started
    ports:
      - "80:80"
    networks:
      - rohlig-net

networks:
  rohlig-net:
    driver: bridge
```

## 7.4 Validate the Compose file

```bash
cd /opt/rohlig/compose
docker compose --env-file /opt/rohlig/env/app.env -f docker-compose.prod.yml config
```

If the output is fully rendered YAML with no error, the file is structurally valid.

---

# 8. Create the Frontend and Backend Image Contracts

This guide assumes your project produces:

- `rohlig-backend:latest`
- `rohlig-frontend:latest`

The easiest two-server deployment model is:

- build the release bundle in Bitbucket Pipelines on `RGZACICD`,
- copy source or release files to `RGZADEVOPS01`,
- build images on the application server,
- start containers with `docker compose up -d --build`.

This avoids needing an external container registry immediately.

---

# 9. Create the Deployment Scripts on the Application Server

## 9.1 Deploy script

On `RGZADEVOPS01`:

```bash
nano /opt/rohlig/scripts/deploy.sh
```

Paste:

```bash
#!/usr/bin/env bash
set -euo pipefail

RELEASE_DIR="/opt/rohlig/releases/current"
COMPOSE_DIR="/opt/rohlig/compose"
ENV_FILE="/opt/rohlig/env/app.env"

cd "$RELEASE_DIR"

echo "[1/5] Checking Docker availability"
docker version
docker compose version

echo "[2/5] Stopping old stack if present"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_DIR/docker-compose.prod.yml" down || true

echo "[3/5] Building fresh images"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_DIR/docker-compose.prod.yml" build --no-cache

echo "[4/5] Starting stack"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_DIR/docker-compose.prod.yml" up -d

echo "[5/5] Final status"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_DIR/docker-compose.prod.yml" ps
```

Make it executable:

```bash
chmod +x /opt/rohlig/scripts/deploy.sh
```

## 9.2 Status script

```bash
nano /opt/rohlig/scripts/status.sh
```

Paste:

```bash
#!/usr/bin/env bash
set -euo pipefail

docker compose --env-file /opt/rohlig/env/app.env -f /opt/rohlig/compose/docker-compose.prod.yml ps
```

Make it executable:

```bash
chmod +x /opt/rohlig/scripts/status.sh
```

## 9.3 Logs script

```bash
nano /opt/rohlig/scripts/logs.sh
```

Paste:

```bash
#!/usr/bin/env bash
set -euo pipefail

docker compose --env-file /opt/rohlig/env/app.env -f /opt/rohlig/compose/docker-compose.prod.yml logs -f --tail=200
```

Make it executable:

```bash
chmod +x /opt/rohlig/scripts/logs.sh
```

---

# 10. Install a Bitbucket Self-Hosted Runner on `RGZACICD`

Bitbucket self-hosted runners are registered from the Bitbucket UI, and Bitbucket gives you a pre-configured command containing the registration token. That command is shown once, so store it safely.

## 10.1 Bitbucket UI steps

In Bitbucket Cloud:

1. Open the repository.
2. Go to **Repository settings**.
3. Under **Pipelines**, open **Runners**.
4. Select **Add runner**.
5. Choose **Linux**.
6. Give the runner a name such as `rgza.cicd.runner`.
7. Add labels such as:
   - `self.hosted`
   - `linux`
   - `rgza.cicd`
   - `rohlig`
8. Copy the generated Docker command.

## 10.2 Create a directory for the runner

On `RGZACICD`:

```bash
mkdir -p ~/rohlig/runner
cd ~/rohlig/runner
```

## 10.3 Run the Bitbucket-generated registration command

Paste the exact command Bitbucket generated for you.

It will look similar in shape to this, but **use the actual command from Bitbucket**, not this placeholder:

```bash
docker run -d \
  --name bitbucket-runner \
  --restart unless-stopped \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v /tmp:/tmp \
  -v ~/rohlig/runner:/runner \
  atlassian/bitbucket-pipelines-runner:latest
```

## 10.4 Confirm the runner is online

On the CI/CD server:

```bash
docker ps
docker logs --tail=200 bitbucket-runner
```

In Bitbucket Cloud, confirm the runner status becomes **online**.

---

# 11. Create the Bitbucket Pipeline for Build, Test, and Deploy

This design uses:

- self-hosted runner on `RGZACICD`,
- SSH deployment to `RGZADEVOPS01`,
- local image build on the application server.

## 11.1 Add repository variables in Bitbucket

In **Repository settings > Repository variables**, create:

```text
APP_HOST=172.38.89.25
APP_USER=RTRITDev
APP_BASE_DIR=/opt/rohlig/releases/current
```

If you prefer, also add the deploy key content as a secured variable and write it during the pipeline. For a runner-based deployment, keeping the deployment key on `RGZACICD` itself is often simpler.

## 11.2 Create `bitbucket-pipelines.yml`

At the root of the repository:

```yaml
pipelines:
  branches:
    main:
      - step:
          name: Build, Test, and Deploy to RGZADEVOPS01
          runs-on:
            - 'self.hosted'
            - 'linux'
            - 'rgza.cicd'
          script:
            - echo "Running on self-hosted runner"
            - pwd
            - ls -la
            - chmod 700 ~/.ssh
            - ssh-keyscan -H $APP_HOST >> ~/.ssh/known_hosts
            - rsync -az --delete ./ $APP_USER@$APP_HOST:$APP_BASE_DIR/
            - ssh $APP_USER@$APP_HOST "mkdir -p /opt/rohlig/releases/current"
            - ssh $APP_USER@$APP_HOST "rsync --version >/dev/null 2>&1 || true"
            - ssh $APP_USER@$APP_HOST "cp $APP_BASE_DIR/docker/docker-compose.prod.yml /opt/rohlig/compose/docker-compose.prod.yml || true"
            - ssh $APP_USER@$APP_HOST "bash /opt/rohlig/scripts/deploy.sh"
            - ssh $APP_USER@$APP_HOST "bash /opt/rohlig/scripts/status.sh"
```

## 11.3 Improved pipeline with Java and Angular build validation

A more realistic pipeline is:

```yaml
image: atlassian/default-image:4

pipelines:
  branches:
    main:
      - step:
          name: Validate, Package, and Deploy
          runs-on:
            - 'self.hosted'
            - 'linux'
            - 'rgza.cicd'
          script:
            - echo "== Validate SSH =="
            - chmod 700 ~/.ssh
            - ssh-keyscan -H $APP_HOST >> ~/.ssh/known_hosts
            - ssh $APP_USER@$APP_HOST "hostname && whoami"

            - echo "== Backend build =="
            - cd backend
            - chmod +x mvnw || true
            - ./mvnw clean test package -DskipTests=false
            - cd ..

            - echo "== Frontend build =="
            - cd frontend
            - npm ci
            - npm run build
            - cd ..

            - echo "== Sync release bundle =="
            - ssh $APP_USER@$APP_HOST "mkdir -p $APP_BASE_DIR"
            - rsync -az --delete ./ $APP_USER@$APP_HOST:$APP_BASE_DIR/

            - echo "== Update compose file on app server =="
            - ssh $APP_USER@$APP_HOST "cp $APP_BASE_DIR/docker/docker-compose.prod.yml /opt/rohlig/compose/docker-compose.prod.yml || true"

            - echo "== Deploy =="
            - ssh $APP_USER@$APP_HOST "bash /opt/rohlig/scripts/deploy.sh"

            - echo "== Verify =="
            - ssh $APP_USER@$APP_HOST "bash /opt/rohlig/scripts/status.sh"
            - ssh $APP_USER@$APP_HOST "curl -f http://localhost/ || true"
            - ssh $APP_USER@$APP_HOST "curl -f http://localhost:8080/actuator/health || true"
```

> Adjust the `backend`, `frontend`, and `docker/docker-compose.prod.yml` paths to match your repository structure.

---

# 12. First Manual Deployment Test Before Using Pipelines

Before trusting the pipeline, test the deployment manually.

## 12.1 Copy a release manually from `RGZACICD`

On `RGZACICD`:

```bash
mkdir -p ~/test-release
cd ~/test-release
printf 'test release %s\n' "$(date)" > RELEASE.txt
rsync -az ./ rohlig-app:/opt/rohlig/releases/current/
```

## 12.2 Confirm the release exists on the application server

```bash
ssh rohlig-app "ls -la /opt/rohlig/releases/current && cat /opt/rohlig/releases/current/RELEASE.txt"
```

## 12.3 Run a manual deployment on the application server

```bash
ssh rohlig-app "bash /opt/rohlig/scripts/deploy.sh"
```

## 12.4 Check status

```bash
ssh rohlig-app "bash /opt/rohlig/scripts/status.sh"
ssh rohlig-app "docker ps"
```

---

# 13. Application Health and Smoke Tests

After the stack is up, verify it properly.

## 13.1 Host-level checks on the application server

```bash
ssh rohlig-app "docker ps"
ssh rohlig-app "docker compose --env-file /opt/rohlig/env/app.env -f /opt/rohlig/compose/docker-compose.prod.yml ps"
ssh rohlig-app "docker compose --env-file /opt/rohlig/env/app.env -f /opt/rohlig/compose/docker-compose.prod.yml logs --tail=100"
```

## 13.2 Frontend checks

From your local machine:

```bash
curl -I http://172.38.89.25
curl http://172.38.89.25 | head
```

## 13.3 Backend health checks

From the application server:

```bash
curl -f http://localhost:8080/actuator/health
curl -f http://localhost:8080/actuator/info || true
```

From your local machine, if the backend is exposed through a reverse proxy or gateway route:

```bash
curl -f http://172.38.89.25/api/actuator/health || true
```

## 13.4 Kafka checks

```bash
ssh rohlig-app "docker exec rohlig-kafka /opt/bitnami/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list"
```

Create a test topic:

```bash
ssh rohlig-app "docker exec rohlig-kafka /opt/bitnami/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --create --if-not-exists --topic rohlig.test --partitions 1 --replication-factor 1"
```

Produce a test message:

```bash
ssh rohlig-app "echo 'hello rohlig' | docker exec -i rohlig-kafka /opt/bitnami/kafka/bin/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic rohlig.test"
```

Consume the message:

```bash
ssh rohlig-app "docker exec rohlig-kafka /opt/bitnami/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic rohlig.test --from-beginning --max-messages 1"
```

---

# 14. Monitoring Setup

For a two-server setup, a sensible monitoring design is:

- **Prometheus + Grafana** on `RGZACICD`
- **Node Exporter** on both servers
- optional container metrics from **cAdvisor** on `RGZADEVOPS01`

## 14.1 Run Node Exporter on the CI/CD server

On `RGZACICD`:

```bash
docker run -d \
  --name node-exporter \
  --restart unless-stopped \
  --net=host \
  --pid=host \
  -v /:/host:ro,rslave \
  prom/node-exporter \
  --path.rootfs=/host
```

## 14.2 Run Node Exporter on the application server

On `RGZADEVOPS01`:

```bash
docker run -d \
  --name node-exporter \
  --restart unless-stopped \
  --net=host \
  --pid=host \
  -v /:/host:ro,rslave \
  prom/node-exporter \
  --path.rootfs=/host
```

Validate:

```bash
curl http://localhost:9100/metrics | head
```

## 14.3 Run Prometheus and Grafana on `RGZACICD`

Create directories:

```bash
mkdir -p ~/rohlig/monitoring/{prometheus,grafana}
```

Create Prometheus config:

```bash
nano ~/rohlig/monitoring/prometheus/prometheus.yml
```

Paste:

```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'rgza-cicd'
    static_configs:
      - targets: ['172.84.39.88:9100']

  - job_name: 'rgza-app'
    static_configs:
      - targets: ['172.38.89.25:9100']
```

Create monitoring compose file:

```bash
nano ~/rohlig/monitoring/docker-compose.monitoring.yml
```

Paste:

```yaml
services:
  prometheus:
    image: prom/prometheus:latest
    container_name: prometheus
    restart: unless-stopped
    ports:
      - "9090:9090"
    volumes:
      - ./prometheus/prometheus.yml:/etc/prometheus/prometheus.yml:ro

  grafana:
    image: grafana/grafana:latest
    container_name: grafana
    restart: unless-stopped
    ports:
      - "3000:3000"
    volumes:
      - grafana-data:/var/lib/grafana

volumes:
  grafana-data:
```

Start monitoring:

```bash
cd ~/rohlig/monitoring
docker compose -f docker-compose.monitoring.yml up -d
```

Validate:

```bash
docker compose -f docker-compose.monitoring.yml ps
curl -I http://localhost:9090
curl -I http://localhost:3000
```

---

# 15. Optional Jenkins on the CI/CD Server

Bitbucket Pipelines should remain the main path. Jenkins is optional when you need:

- manual job orchestration,
- richer pipeline UI,
- legacy job compatibility,
- shared enterprise workflows.

## 15.1 Create a Jenkins Compose file

On `RGZACICD`:

```bash
nano ~/rohlig/jenkins/docker-compose.jenkins.yml
```

Paste:

```yaml
services:
  jenkins:
    image: jenkins/jenkins:lts-jdk21
    container_name: jenkins
    restart: unless-stopped
    user: root
    ports:
      - "8080:8080"
      - "50000:50000"
    volumes:
      - jenkins_home:/var/jenkins_home
      - /var/run/docker.sock:/var/run/docker.sock

volumes:
  jenkins_home:
```

Start Jenkins:

```bash
cd ~/rohlig/jenkins
docker compose -f docker-compose.jenkins.yml up -d
```

Get the initial admin password:

```bash
docker exec jenkins cat /var/jenkins_home/secrets/initialAdminPassword
```

Stop Jenkins if you do not need it:

```bash
docker compose -f ~/rohlig/jenkins/docker-compose.jenkins.yml down
```

---

# 16. Security Hardening Checklist

Apply these controls as part of the final setup.

## 16.1 SSH hardening

On both servers, edit:

```bash
sudo nano /etc/ssh/sshd_config
```

Recommended settings:

```text
PermitRootLogin no
PasswordAuthentication yes
PubkeyAuthentication yes
ChallengeResponseAuthentication no
UsePAM yes
X11Forwarding no
ClientAliveInterval 300
ClientAliveCountMax 2
```

Restart SSH:

```bash
sudo systemctl restart ssh
sudo systemctl status ssh --no-pager
```

After key-based access is fully confirmed and emergency access is handled, you can consider changing:

```text
PasswordAuthentication no
```

Do that only after you are sure key-based login works.

## 16.2 Limit publicly exposed ports

Keep public exposure to:

- `22` for SSH,
- `80` and `443` for the application,
- optional `3000` and `9090` only if monitoring must be remotely reachable.

Do not expose:

- Kafka `9092`,
- PostgreSQL `5432`,
- internal backend ports,
- internal container ports.

## 16.3 Secure environment files

```bash
chmod 600 /opt/rohlig/env/app.env
chmod 700 /opt/rohlig/scripts/*.sh
```

## 16.4 Back up configuration before major changes

```bash
mkdir -p /opt/rohlig/backups/$(date +%F_%H%M%S)
cp -r /opt/rohlig/compose /opt/rohlig/backups/$(date +%F_%H%M%S)/ || true
cp -r /opt/rohlig/env /opt/rohlig/backups/$(date +%F_%H%M%S)/ || true
```

---

# 17. Rollback Strategy

A rollback plan must exist before the first production deployment.

## 17.1 Release folder strategy

Use timestamped releases:

```text
/opt/rohlig/releases/
  2026-04-09_0700/
  2026-04-09_0930/
  current -> symlink or selected folder
```

## 17.2 Example release switch process

On the application server:

```bash
mkdir -p /opt/rohlig/releases/$(date +%F_%H%M%S)
```

Copy a new release into that directory.

Then update the current symlink:

```bash
ln -sfn /opt/rohlig/releases/2026-04-09_0930 /opt/rohlig/releases/current
```

## 17.3 Rollback command sequence

If a deployment fails:

```bash
ln -sfn /opt/rohlig/releases/2026-04-09_0700 /opt/rohlig/releases/current
bash /opt/rohlig/scripts/deploy.sh
bash /opt/rohlig/scripts/status.sh
```

## 17.4 Database caution

If the new release applies database migrations, rollback needs extra care. A code rollback is easy, but a database schema rollback may not be. For Flyway/Liquibase-driven systems:

- back up before deployment,
- review migration order,
- avoid destructive migrations without a tested reverse plan.

---

# 18. Common Operational Commands

## 18.1 Server checks

```bash
hostnamectl
free -h
df -h
uptime
sudo ss -tulpn
sudo journalctl -xe --no-pager | tail -100
```

## 18.2 Docker checks

```bash
docker ps -a
docker images
docker stats --no-stream
docker logs <container_name> --tail=200
```

## 18.3 Compose checks

```bash
docker compose --env-file /opt/rohlig/env/app.env -f /opt/rohlig/compose/docker-compose.prod.yml ps
docker compose --env-file /opt/rohlig/env/app.env -f /opt/rohlig/compose/docker-compose.prod.yml logs -f
docker compose --env-file /opt/rohlig/env/app.env -f /opt/rohlig/compose/docker-compose.prod.yml restart backend
```

## 18.4 Network checks

```bash
ping -c 4 172.84.39.88
ping -c 4 172.38.89.25
nslookup google.com
curl -I http://localhost
curl -I http://172.38.89.25
```

## 18.5 SSH checks

From the CI/CD server:

```bash
ssh rohlig-app "hostname"
ssh rohlig-app "docker ps"
rsync -az ./ rohlig-app:/tmp/rsync-test/
```

---

# 19. Troubleshooting Guide

## 19.1 Cannot SSH to the server

Check:

```bash
ping -c 4 172.84.39.88
ping -c 4 172.38.89.25
nc -zv 172.84.39.88 22
nc -zv 172.38.89.25 22
```

On the target host:

```bash
sudo systemctl status ssh --no-pager
sudo ss -tulpn | grep ':22'
sudo ufw status verbose
```

## 19.2 Docker is installed but not working

```bash
sudo systemctl restart docker
sudo systemctl status docker --no-pager
sudo journalctl -u docker --no-pager | tail -200
docker info
```

## 19.3 Docker Compose file fails to render

```bash
docker compose --env-file /opt/rohlig/env/app.env -f /opt/rohlig/compose/docker-compose.prod.yml config
```

Typical causes:

- missing variable in `app.env`,
- bad YAML indentation,
- invalid healthcheck syntax,
- bad image name.

## 19.4 Backend container starts but health check fails

```bash
docker logs rohlig-backend --tail=200
curl -v http://localhost:8080/actuator/health
```

Common causes:

- wrong datasource URL,
- database not ready,
- Kafka unavailable,
- Spring profile misconfigured,
- missing environment variables.

## 19.5 Frontend loads but API calls fail

Check:

- frontend environment base URL,
- Nginx reverse proxy config,
- CORS,
- backend health,
- gateway route or API path.

Useful commands:

```bash
curl -I http://localhost
curl -I http://localhost:8080/actuator/health
docker logs rohlig-frontend --tail=200
docker logs rohlig-backend --tail=200
```

## 19.6 Kafka problems

```bash
docker logs rohlig-kafka --tail=200
docker exec rohlig-kafka /opt/bitnami/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list
```

Common causes:

- incorrect advertised listener,
- wrong bootstrap server address,
- volume permission problems,
- application using `localhost:9092` instead of `kafka:9092` inside Docker network.

## 19.7 Bitbucket runner is offline

On `RGZACICD`:

```bash
docker ps
docker logs --tail=200 bitbucket-runner
docker restart bitbucket-runner
```

Also check the repository runner page in Bitbucket.

## 19.8 Pipeline deploy fails over SSH

From `RGZACICD`:

```bash
ssh rohlig-app "hostname && whoami"
ssh rohlig-app "ls -la /opt/rohlig"
ssh rohlig-app "bash /opt/rohlig/scripts/status.sh"
```

Common causes:

- wrong SSH key permissions,
- wrong host key,
- wrong pipeline host variable,
- `rsync` missing,
- wrong remote path.

---

# 20. Recommended Go-Live Sequence

Use this exact order for a controlled rollout.

## Step 1 — Verify both servers

```bash
ssh rgza-cicd
ssh rgza-app
```

Run the baseline checks.

## Step 2 — Harden both servers

Run package updates, utility installs, Docker checks, firewall setup, and timezone configuration.

## Step 3 — Configure SSH deployment key

Generate the deploy key on `RGZACICD`, copy it to `RGZADEVOPS01`, and confirm passwordless access.

## Step 4 — Create `/opt/rohlig` structure on the application server

Create the runtime folders, compose folder, scripts folder, and environment file.

## Step 5 — Validate Compose on the application server

Render the config and do a smoke test.

## Step 6 — Install the Bitbucket runner on `RGZACICD`

Register it in Bitbucket and confirm it is online.

## Step 7 — Add pipeline YAML to the repository

Commit the pipeline file to `main` or your chosen deployment branch.

## Step 8 — Run first manual deployment

Copy a release bundle manually and run `deploy.sh`.

## Step 9 — Run first pipeline deployment

Push to the configured branch and monitor the pipeline logs.

## Step 10 — Validate application, backend, and Kafka

Run health checks, frontend checks, and Kafka produce/consume tests.

## Step 11 — Enable monitoring

Run node exporter on both servers and Prometheus/Grafana on `RGZACICD`.

## Step 12 — Capture final evidence

Save:

- `docker ps`,
- compose status,
- backend health response,
- frontend response headers,
- Prometheus target status,
- Grafana availability,
- pipeline success screenshot if needed for management.

---

# 21. Final Validation Commands

Run these after the first successful setup.

## 21.1 CI/CD server

```bash
ssh rgza-cicd
hostnamectl
docker ps
curl -I http://localhost:9090 || true
curl -I http://localhost:3000 || true
```

## 21.2 Application server

```bash
ssh rgza-app
hostnamectl
docker ps
docker compose --env-file /opt/rohlig/env/app.env -f /opt/rohlig/compose/docker-compose.prod.yml ps
curl -I http://localhost
curl -f http://localhost:8080/actuator/health
```

## 21.3 End-user checks

From your workstation:

```bash
curl -I http://172.38.89.25
curl http://172.38.89.25 | head
```

---

# 22. Reference Notes

This guide is aligned to the current Docker and Atlassian direction:

- on Ubuntu, use **Docker Engine** with the **Docker Compose plugin**, so the modern command is `docker compose`,
- Bitbucket self-hosted runners are registered from the Bitbucket UI and scheduled in `bitbucket-pipelines.yml` using `runs-on` labels,
- deployment from the self-hosted runner to the application server is done over SSH.

---

# 23. Next Recommended Improvement After This Setup

Once this two-server model is stable, the next production improvements should be:

1. move from password-based emergency access to full key-only SSH,
2. add TLS with Nginx and real certificates,
3. move secrets out of plain `.env` files into a secret manager,
4. externalize PostgreSQL if you need stricter data durability separation,
5. split Kafka into a more resilient multi-broker design if throughput and resilience increase,
6. add automated backups and restore drills,
7. add image version tagging instead of only `latest`,
8. add pre-deploy smoke tests and post-deploy automated checks.

---

# 24. Ready-to-Run Quick Command List

If you want the shortest practical sequence, here it is.

## On your local machine

```bash
ssh RTITDrrev@172.84.39.88
ssh RTRITDev@172.38.89.25
```

## On both servers

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget git unzip zip jq vim nano htop tree net-tools dnsutils ca-certificates gnupg lsb-release software-properties-common openssh-client openssh-server rsync
sudo systemctl enable docker
sudo systemctl restart docker
docker compose version
```

## On `RGZACICD`

```bash
mkdir -p ~/.ssh
ssh-keygen -t ed25519 -C "rohlig-deploy-key" -f ~/.ssh/rohlig_deploy_key
ssh-copy-id -i ~/.ssh/rohlig_deploy_key.pub RTRITDev@172.38.89.25
ssh -i ~/.ssh/rohlig_deploy_key RTRITDev@172.38.89.25 "hostname && docker ps"
mkdir -p ~/rohlig/{runner,scripts,artifacts,logs,monitoring,jenkins}
```

## On `RGZADEVOPS01`

```bash
sudo mkdir -p /opt/rohlig/{app,compose,env,logs,backups,releases,scripts,data}
sudo chown -R RTRITDev:RTRITDev /opt/rohlig
mkdir -p /opt/rohlig/data/{postgres,kafka,nginx,frontend}
nano /opt/rohlig/env/app.env
nano /opt/rohlig/compose/docker-compose.prod.yml
nano /opt/rohlig/scripts/deploy.sh
chmod +x /opt/rohlig/scripts/deploy.sh
```

## From `RGZACICD` after pipeline and repo are ready

```bash
rsync -az ./ rohlig-app:/opt/rohlig/releases/current/
ssh rohlig-app "bash /opt/rohlig/scripts/deploy.sh"
ssh rohlig-app "bash /opt/rohlig/scripts/status.sh"
```

---

This document is the working baseline for the **Röhlig two-server DevOps setup** using your current servers and SSH-based deployment model.
