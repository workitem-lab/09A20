# Röhlig Easy Estimate 300+ Postman Pack

## Overview

This pack was generated against the customer-integrated backend package and covers the real gateway-facing API surface.

### Request count
- **Total Postman requests:** 527

### Coverage
- gateway health and auth
- customer integration service
- shipment service
- tariff resolution
- rate repository
- rates importer
- costing service
- quotation service
- invoice alias endpoints
- role-based security negatives
- prospect and registered end-to-end flows

## Main roles used
- ADMIN
- OPERATIONS_USER
- QUOTATION_USER
- RATES_ADMIN
- VIEW_ONLY
- CUSTOMER_ADMIN
- invalid / missing token cases

## Import order
1. import the environment file
2. import the collection file
3. select the environment
4. update usernames/passwords if your local Keycloak users differ
5. run **00 Setup Tokens Health** first

## Notes
- The token requests assume password grant is enabled for the configured Keycloak client.
- The collection uses full Postman URL objects, not raw-only URLs.
- Some negative tests allow 400/500 or 404/500 because service error handling may vary in early environments.
- The collection is designed to be broad and regression-friendly, not only demo-friendly.

## Folder summary
- **00 Setup Tokens Health** — 23 requests
- **01 Customer Positive** — 44 requests
- **02 Customer Negative Security** — 31 requests
- **03 Shipment Positive** — 53 requests
- **04 Shipment Negative Security** — 24 requests
- **05 Tariff And Rate Repository** — 37 requests
- **06 Rates Importer Positive** — 16 requests
- **07 Rates Importer Negative Security** — 22 requests
- **08 Costing Positive** — 49 requests
- **09 Costing Negative Security** — 22 requests
- **10 Quotation Positive** — 85 requests
- **11 Quotation Negative Security** — 35 requests
- **12 End To End Prospect Flows** — 16 requests
- **13 End To End Registered Flows** — 19 requests
- **14 Bulk Search And Reconciliation** — 51 requests

## Sample files included
- `samples/rate-import-template-valid.csv`
- `samples/rate-import-template-invalid.csv`
- `samples/not-a-csv.txt`

## Most important flows to run
1. `00 Setup Tokens Health`
2. `01 Customer Positive`
3. `03 Shipment Positive`
4. `08 Costing Positive`
5. `10 Quotation Positive`
6. `12 End To End Prospect Flows`
7. `13 End To End Registered Flows`
