# Bitbucket Pipeline Guide

This repo includes a `bitbucket-pipelines.yml` that calls the same orchestrator script used in manual mode.

## What you need in Bitbucket first

Create secured repository variables:

- `BITBUCKET_APP_USER`
- `BITBUCKET_APP_PASSWORD`
- `APP_SERVER_RUNTIME_ENV_B64`

### About `APP_SERVER_RUNTIME_ENV_B64`

Base64-encode your final runtime env file, then store it as a secured variable.

On your laptop:

```bash
base64 -i config/runtime.env | tr -d '\n'
```

Copy the output and save it in Bitbucket as `APP_SERVER_RUNTIME_ENV_B64`.

## Runner labels

The pipeline is written for a Bitbucket self-hosted Linux Docker runner.

Default labels used in this repo:

- `self.hosted`
- `linux`
- `rohlig-cicd`

Update `config/bitbucket.env` and `pipelines/bitbucket-pipelines.yml` if your runner labels differ.

## Pipeline flow

1. validate config
2. clone backend and frontend repos
3. build backend in Dockerized Maven
4. build frontend in Dockerized Node
5. build backend and frontend runtime images
6. package release tarball
7. stage runtime env on the app server
8. deploy over SSH
9. run remote smoke tests
