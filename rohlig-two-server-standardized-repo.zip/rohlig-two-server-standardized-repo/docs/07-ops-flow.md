# Operations Flow

## Manual build and release

Run these from `RGZACICD`:

```bash
cd ~/rohlig-two-server-master-repo
./scripts/orchestrators/10-build-package.sh
./scripts/orchestrators/20-deploy-release.sh
./scripts/orchestrators/30-verify-deployment.sh
```

## Smoke tests

```bash
./scripts/orchestrators/40-run-smoke-tests.sh
```

## Rollback

```bash
./scripts/orchestrators/50-rollback-remote.sh
```

## Status commands

On the app server:

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZADEVOPS01/scripts
./60-status.sh
```

On the CI/CD server:

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZACICD/scripts
./50-status.sh
```
