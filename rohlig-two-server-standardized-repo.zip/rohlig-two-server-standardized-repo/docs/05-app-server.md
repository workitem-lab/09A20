# App Server Guide — RGZADEVOPS01

## Server identity

- Host: `RGZADEVOPS01`
- IP: `172.28.29.68`
- SSH user: `RGITDev`
- Purpose: runtime host for the Röhlig stack

## Step-by-step sequence

### 1. Connect

```bash
ssh RGITDev@172.28.29.68
```

### 2. Run precheck

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZADEVOPS01/scripts
./00-precheck.sh
```

### 3. Bootstrap runtime packages and firewall baseline

```bash
./10-bootstrap-app.sh
```

### 4. Create runtime folder structure

```bash
./20-create-app-layout.sh
```

### 5. Stage the runtime env file

From your laptop or the CI/CD server:

```bash
scp ~/rohlig-two-server-master-repo/config/runtime.env RGITDev@172.28.29.68:/tmp/runtime.env
ssh RGITDev@172.28.29.68 "sudo mkdir -p /opt/rohlig/shared/env && sudo mv /tmp/runtime.env /opt/rohlig/shared/env/runtime.env && sudo chown RGITDev:RGITDev /opt/rohlig/shared/env/runtime.env && chmod 600 /opt/rohlig/shared/env/runtime.env"
```

### 6. Deploy release bundle

This is normally done from the CI/CD server. The deploy script on the app server will:

- unpack the release
- `docker load` backend and frontend images
- assemble the final release env
- start the stack with `docker compose`
- update `/opt/rohlig/current`

### 7. Check runtime status

```bash
./60-status.sh
```

### 8. Run smoke tests

```bash
./70-smoke-tests.sh
```

### 9. Roll back if required

```bash
./50-rollback-release.sh
```

## Exposed URLs

- `http://172.28.29.68/`
- `http://172.28.29.68:8080/actuator/health`
- `http://172.28.29.68:9090/`
- `http://172.28.29.68:3000/`
