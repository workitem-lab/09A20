# Architecture

## Logical architecture

The deployment uses two Ubuntu servers.

### CI/CD server: RGZACICD

This server is responsible for:

- cloning the backend repo
- cloning the frontend repo
- running Maven and Node builds inside Docker containers
- creating runtime Docker images for backend and frontend
- packaging the release bundle
- transferring the release to the app server over SSH
- optionally hosting a Bitbucket self-hosted runner
- optionally hosting Jenkins

### App server: RGZADEVOPS01

This server is responsible for:

- storing release bundles under `/opt/rohlig/releases`
- loading Docker image tar archives into the local Docker engine
- running the application stack using `docker compose`
- exposing frontend, backend, Kafka, Prometheus, and Grafana to your dev computer
- keeping a `current` symlink to the active release
- rolling back to the previous release when needed

## Deployment topology

```text
Developer laptop
    |
    | SSH / Browser
    v
RGZACICD (172.28.29.35)
    |  clones repos from Bitbucket
    |  builds backend + frontend
    |  builds Docker images
    |  creates release bundle
    |  SCP over SSH
    v
RGZADEVOPS01 (172.28.29.68)
    |  docker load
    |  docker compose up -d
    v
Runtime containers
    |- rohlig-backend
    |- rohlig-frontend
    |- rohlig-kafka
    |- rohlig-nginx
    |- rohlig-prometheus
    |- rohlig-grafana
```

## Runtime stack

The default stack includes:

- backend container
- frontend container
- Kafka broker using KRaft mode
- NGINX reverse proxy
- Prometheus
- Grafana

The backend database is expected to be externalized through `runtime.env`.

## Release layout on app server

```text
/opt/rohlig/
├── current -> /opt/rohlig/releases/<release-id>
├── releases/
│   └── <release-id>/
│       ├── compose/
│       ├── env/
│       ├── images/
│       └── metadata/
└── shared/
    ├── env/runtime.env
    ├── backups/
    └── logs/
```

## Exposed ports

### RGZADEVOPS01

- `80` → frontend and reverse proxy entry point
- `8080` → backend direct access
- `9092` → Kafka external listener
- `9090` → Prometheus
- `3000` → Grafana

### RGZACICD

- `8080` → Jenkins, if enabled

## URL mapping

- `/` → frontend
- `/api/` → backend API through reverse proxy
- `/actuator/` → backend actuator through reverse proxy

## Why this design works well now

- no dependency on a separate Docker registry
- clear split between build host and runtime host
- low operational complexity
- easy rollback with release symlink strategy
- simple enough for management visibility and engineering control
- still compatible with later upgrades to Kubernetes or a registry-based model
