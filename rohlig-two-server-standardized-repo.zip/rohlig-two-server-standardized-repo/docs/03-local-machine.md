# Local Machine Steps

These are the steps you run from your laptop before touching the servers.

## Check local prerequisites

```bash
./scripts/local/00-check-local.sh
```

## Generate a local SSH key if you do not already have one

```bash
ssh-keygen -t ed25519 -C "robertnd@local"
```

## First login checks

```bash
./scripts/local/10-first-logins.sh
```

This script does not store passwords. It only prints the commands you should run.

## Copy this repo to both servers

From your laptop, assuming you already have access:

```bash
scp -r ./rohlig-two-server-master-repo RGITDev@172.28.29.35:~/
scp -r ./rohlig-two-server-master-repo RGITDev@172.28.29.68:~/
```

If you prefer `rsync`:

```bash
rsync -av --delete ./rohlig-two-server-master-repo/ RGITDev@172.28.29.35:~/rohlig-two-server-master-repo/
rsync -av --delete ./rohlig-two-server-master-repo/ RGITDev@172.28.29.68:~/rohlig-two-server-master-repo/
```
