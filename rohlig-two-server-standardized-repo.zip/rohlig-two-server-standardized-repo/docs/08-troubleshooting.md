# Troubleshooting

## SSH to app server asks for password every time

Check from `RGZACICD`:

```bash
ls -lah ~/.ssh
ssh -v RGITDev@172.28.29.68
```

Check on `RGZADEVOPS01`:

```bash
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
chown -R RGITDev:RGITDev ~/.ssh
```

## Docker build fails for backend

Typical causes:

- wrong Maven wrapper permissions
- wrong Java version required by the project
- wrong JAR glob in `config/platform.env`
- tests or plugins failing during the Maven build

Check:

```bash
cat config/platform.env
grep BACKEND_BUILD_CMD config/platform.env
```

Then rerun:

```bash
./scripts/orchestrators/10-build-package.sh
```

## Angular build succeeds but frontend image is empty

Check the resolved dist directory inside the build workspace:

```bash
find /opt/rohlig-ci/workspace/src/frontend -type f -name index.html | sort
```

If your Angular output path differs, update `FRONTEND_DIST_HINT` in `config/platform.env`.

## App server deployment starts but backend health is down

Check:

```bash
ssh RGITDev@172.28.29.68
cd /opt/rohlig/current/compose
cat ../env/release.env
cat /opt/rohlig/shared/env/runtime.env
docker compose --env-file ../env/release.env --env-file /opt/rohlig/shared/env/runtime.env -f docker-compose.prod.yml logs --tail=200 rohlig-backend
```

## NGINX returns 502

Check container reachability inside the Docker network:

```bash
docker ps
cd /opt/rohlig/current/compose
docker compose --env-file ../env/release.env --env-file /opt/rohlig/shared/env/runtime.env -f docker-compose.prod.yml logs --tail=200 rohlig-nginx
```

## Kafka port is open but clients cannot connect

The default Compose file exposes Kafka with this external host:

- `172.28.29.68:9092`

If the app server IP changes, update `APP_SERVER_IP` in `config/platform.env` and redeploy.

## Bitbucket pipeline cannot clone other repos

Check the secured variables:

- `BITBUCKET_APP_USER`
- `BITBUCKET_APP_PASSWORD`

Also make sure the app password has repo read access for both backend and frontend repositories.

## Jenkins install fails

Check Java and service logs:

```bash
java -version
sudo systemctl status jenkins --no-pager
sudo journalctl -u jenkins -n 200 --no-pager
```
