# Stage-by-Stage Test Cases and Validation Commands

This document gives you the test command, the expected result, and the pass condition for every major stage in the Röhlig two-server deployment flow.

## Stage 0 — Repo validation on your dev computer

Run these commands from the root of this repo:

```bash
find . -type f -name "*.sh" -exec chmod +x {} \;
./checks/repo-sanity-check.sh
./checks/run-all-validations.sh
```

Expected result:

- shell syntax passes
- config validation passes
- pipeline validation passes
- compose validation passes when Docker is available locally

Pass condition: all checks report `[OK]` and no `[ERROR]` appears.

## Stage 1 — First SSH access from your dev computer

```bash
./scripts/local/00-check-local.sh
./scripts/local/10-first-logins.sh
ssh RGITDev@172.28.29.35
ssh RGITDev@172.28.29.68
```

Expected result:

- SSH connects to both servers
- hostname and prompt show the correct target server

Pass condition: you can log into both hosts without network or credential errors.

## Stage 2 — CI/CD server precheck and bootstrap

On `RGZACICD`:

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZACICD/scripts
./00-precheck.sh
./10-bootstrap-cicd.sh
./05-verify-bootstrap.sh
./50-status.sh
```

Expected result:

- Docker is installed and active
- `docker compose version` works
- `/opt/rohlig-ci/workspace` exists
- `/opt/rohlig-ci/releases` exists

Pass condition: `./05-verify-bootstrap.sh` ends with `[OK] CI/CD bootstrap verification passed`.

## Stage 3 — App server precheck and bootstrap

On `RGZADEVOPS01`:

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZADEVOPS01/scripts
./00-precheck.sh
./10-bootstrap-app.sh
./20-create-app-layout.sh
./15-verify-bootstrap.sh
./60-status.sh
```

Expected result:

- Docker is installed and active
- `/opt/rohlig/releases` exists
- `/opt/rohlig/shared/env` exists

Pass condition: `./15-verify-bootstrap.sh` ends with `[OK] App server bootstrap verification passed`.

## Stage 4 — SSH trust from CI/CD server to app server

On `RGZACICD`:

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZACICD/scripts
./20-create-ssh-key.sh
ssh-copy-id RGITDev@172.28.29.68
./21-test-app-ssh.sh
```

Expected result:

- the public key is installed on the app server
- passwordless SSH works from the CI/CD server to the app server

Pass condition: `./21-test-app-ssh.sh` prints hostname, username, and uptime without asking for a password.

## Stage 5 — Bitbucket runner stage

On `RGZACICD`:

```bash
cp ../env/runner.env.example ../env/runner.env
vi ../env/runner.env
./30-start-bitbucket-runner.sh
./31-test-runner.sh
```

Expected result:

- the container `rohlig-bitbucket-runner` is running
- recent runner logs do not show immediate crash loops

Pass condition: `./31-test-runner.sh` ends with `[OK] Bitbucket runner container is running`.

## Stage 6 — Manual build and package stage

On `RGZACICD` from the repo root:

```bash
./scripts/orchestrators/10-build-package.sh
ls -lah /opt/rohlig-ci/releases
```

Expected result:

- a timestamped release folder is created under `/opt/rohlig-ci/releases`
- a matching `.tar.gz` release file is created
- backend and frontend image archives exist inside the release

Pass condition: the script ends with `RELEASE_ID=...` and `RELEASE_TAR=...`.

## Stage 7 — Manual deploy stage

On `RGZACICD` from the repo root:

```bash
./scripts/orchestrators/20-deploy-release.sh
./scripts/orchestrators/30-verify-deployment.sh
```

Expected result:

- the release uploads to the app server
- `/opt/rohlig/current` points to the new release
- containers are created on the app server

Pass condition: `./scripts/orchestrators/30-verify-deployment.sh` shows the exposed URLs and the app server status script returns container information.

## Stage 8 — Post-deploy verification on app server

On `RGZADEVOPS01`:

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZADEVOPS01/scripts
./42-verify-current-release.sh
./70-smoke-tests.sh
```

Expected result:

- current release files are present
- compose config resolves successfully
- frontend root responds
- backend health responds
- Prometheus and Grafana ports respond

Pass condition: both scripts complete without errors.

## Stage 9 — Exposed URL checks from your dev computer

Run these from your laptop:

```bash
curl -I http://172.28.29.68/
curl -fsS http://172.28.29.68:8080/actuator/health
curl -I http://172.28.29.68:9090/
curl -I http://172.28.29.68:3000/
```

Expected result:

- `http://172.28.29.68/` returns HTTP headers
- backend health returns JSON
- Prometheus and Grafana return HTTP headers

Pass condition: all endpoints are reachable from your dev machine.

## Stage 10 — Rollback readiness test

On `RGZADEVOPS01`:

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZADEVOPS01/scripts
./55-test-rollback-readiness.sh
```

Expected result:

- the script finds at least two releases
- the script shows both the current and previous release path

Pass condition: the script ends with `[OK] Rollback readiness passed`.

## Stage 11 — Rollback execution test

Only run this after at least two known-good releases exist.

On `RGZACICD` from the repo root:

```bash
./scripts/orchestrators/50-rollback-remote.sh
./scripts/orchestrators/30-verify-deployment.sh
```

Or directly on `RGZADEVOPS01`:

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZADEVOPS01/scripts
./50-rollback-release.sh
./42-verify-current-release.sh
./70-smoke-tests.sh
```

Expected result:

- `/opt/rohlig/current` points to the previous release
- containers come up again from the previous release
- smoke tests still pass

Pass condition: post-rollback verification passes and the application is reachable again.

## Recommended full validation sequence

For a clean setup, use this order:

```bash
# on your dev computer
./checks/run-all-validations.sh

# on RGZACICD
./00-precheck.sh
./10-bootstrap-cicd.sh
./05-verify-bootstrap.sh
./20-create-ssh-key.sh
./21-test-app-ssh.sh
./30-start-bitbucket-runner.sh
./31-test-runner.sh

# on RGZADEVOPS01
./00-precheck.sh
./10-bootstrap-app.sh
./20-create-app-layout.sh
./15-verify-bootstrap.sh

# back on RGZACICD
./scripts/orchestrators/10-build-package.sh
./scripts/orchestrators/20-deploy-release.sh
./scripts/orchestrators/30-verify-deployment.sh
./scripts/orchestrators/40-run-smoke-tests.sh
```
