# CI/CD Server Guide — RGZACICD

## Server identity

- Host: `RGZACICD`
- IP: `172.28.29.35`
- SSH user: `RGITDev`
- Purpose: build, package, release, runner, optional Jenkins

## Step-by-step sequence

### 1. Connect

```bash
ssh RGITDev@172.28.29.35
```

### 2. Run precheck

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZACICD/scripts
./00-precheck.sh
```

### 3. Bootstrap packages and working directories

```bash
./10-bootstrap-cicd.sh
```

### 4. Create CI/CD SSH key

```bash
./20-create-ssh-key.sh
```

### 5. Confirm the public key is ready

```bash
cat ~/.ssh/id_ed25519.pub
```

### 6. Add that public key to the app server

Use `ssh-copy-id` or paste it into the app server `~/.ssh/authorized_keys`.

### 7. Test passwordless SSH to the app server

```bash
./21-test-app-ssh.sh
```

### 8. Optional: install Jenkins

```bash
./40-install-jenkins-optional.sh
```

### 9. Runner setup

After creating a Bitbucket self-hosted Linux Docker runner in Bitbucket Cloud, copy the OAuth values into:

- `servers/RGZACICD/env/runner.env`

Then run:

```bash
./30-start-bitbucket-runner.sh
```

### 10. Build and deploy manually once

From the repo root on the CI/CD server:

```bash
cd ~/rohlig-two-server-master-repo
./scripts/orchestrators/10-build-package.sh
./scripts/orchestrators/20-deploy-release.sh
./scripts/orchestrators/30-verify-deployment.sh
```

## Expected outcomes

- `/opt/rohlig-ci` exists
- Docker works
- CI/CD server can SSH to `RGZADEVOPS01` without a password
- release tarball exists under `/opt/rohlig-ci/releases`
- app server receives the release and starts the containers
