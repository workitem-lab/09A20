# Start Here

This repo is the operating kit for your two-server Röhlig deployment.

The working model is:

- **RGZACICD** builds and packages releases
- **RGZADEVOPS01** runs the platform containers
- deployment happens over **SSH**
- Docker images are built on the CI/CD server
- images are transferred as tar files to the app server
- the app server loads the images locally and starts them with `docker compose`

That design avoids needing a separate Docker registry on day one.

## Server map

### RGZACICD

- IP: `172.28.29.35`
- Purpose: build, package, pipeline runner, optional Jenkins
- OS: Ubuntu Server 22.04.4 LTS
- RAM: 24 GB
- Disk: 500 GB

### RGZADEVOPS01

- IP: `172.28.29.68`
- Purpose: runtime platform host
- OS: Ubuntu Server 22.04.4 LTS
- RAM: 24 GB
- Disk: 2 TB

## One-time rule before you do anything else

Do not put raw passwords into scripts, Compose files, Git, or Bitbucket YAML.

Use:

- SSH keys for server-to-server trust
- protected environment files on servers
- Bitbucket secured repository variables

## Step 1 — create the config files

From the root of this repo:

```bash
cp config/platform.env.example config/platform.env
cp config/bitbucket.env.example config/bitbucket.env
cp config/runtime.env.example config/runtime.env
```

## Step 2 — edit these three files only

### `config/platform.env`

Use this for:

- server IPs
- server SSH users
- repo slugs
- build commands
- app ports
- image names
- release root directories

### `config/bitbucket.env`

Use this for:

- Bitbucket workspace
- Bitbucket base URL
- app password user
- app password token placeholder
- runner labels

### `config/runtime.env`

Use this for:

- Spring profile
- datasource URL
- datasource username/password
- Kafka bootstrap settings
- actuator exposure settings
- any backend runtime environment values

## Step 3 — make scripts executable

```bash
find . -type f -name "*.sh" -exec chmod +x {} \;
```

## Step 4 — run repo sanity checks locally

```bash
./checks/repo-sanity-check.sh
```

## Step 5 — bootstrap the CI/CD server

Read `servers/RGZACICD/README.md`, then run:

```bash
ssh RGITDev@172.28.29.35
cd ~/rohlig-two-server-master-repo/servers/RGZACICD/scripts
./00-precheck.sh
./10-bootstrap-cicd.sh
./20-create-ssh-key.sh
```

## Step 6 — bootstrap the app server

Read `servers/RGZADEVOPS01/README.md`, then run:

```bash
ssh RGITDev@172.28.29.68
cd ~/rohlig-two-server-master-repo/servers/RGZADEVOPS01/scripts
./00-precheck.sh
./10-bootstrap-app.sh
./20-create-app-layout.sh
```

## Step 7 — authorize the CI/CD public key on the app server

From the CI/CD server:

```bash
ssh-copy-id RGITDev@172.28.29.68
ssh RGITDev@172.28.29.68 "hostname && whoami"
```

## Step 8 — stage runtime env on the app server

From your local machine or CI/CD server:

```bash
scp config/runtime.env RGITDev@172.28.29.68:/tmp/runtime.env
ssh RGITDev@172.28.29.68 "sudo mkdir -p /opt/rohlig/shared/env && sudo mv /tmp/runtime.env /opt/rohlig/shared/env/runtime.env && sudo chown RGITDev:RGITDev /opt/rohlig/shared/env/runtime.env && chmod 600 /opt/rohlig/shared/env/runtime.env"
```

## Step 9 — run one manual build and deploy from the CI/CD server

On `RGZACICD`:

```bash
cd ~/rohlig-two-server-master-repo
./scripts/orchestrators/10-build-package.sh
./scripts/orchestrators/20-deploy-release.sh
./scripts/orchestrators/30-verify-deployment.sh
```

## Step 10 — enable Bitbucket runner and pipeline

After the manual deploy works, set up the runner using `servers/RGZACICD/scripts/30-start-bitbucket-runner.sh`, then commit this repo to Bitbucket and enable the pipeline defined in `pipelines/bitbucket-pipelines.yml`.

## If something fails

Go to:

- `docs/08-troubleshooting.md`
- `servers/RGZADEVOPS01/scripts/50-rollback-release.sh`
- `scripts/orchestrators/40-run-smoke-tests.sh`
