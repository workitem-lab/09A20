# Configuration Model

This repo is intentionally driven by a small number of environment files.

## 1. `config/platform.env`

This file controls infrastructure and build behavior.

Main sections:

- server hostnames, IPs, and SSH users
- repo slugs and branches
- build commands
- Docker image names
- release paths
- port exposure

## 2. `config/bitbucket.env`

This file controls Bitbucket integration.

Main sections:

- Bitbucket base URL
- workspace slug
- app password username
- app password token placeholder
- runner labels
- repository variables required by the pipeline

## 3. `config/runtime.env`

This file controls backend runtime configuration.

Examples:

- `SPRING_PROFILES_ACTIVE=prod`
- `SPRING_DATASOURCE_URL=jdbc:postgresql://<host>:5432/<db>`
- `SPRING_DATASOURCE_USERNAME=...`
- `SPRING_DATASOURCE_PASSWORD=...`
- `MANAGEMENT_ENDPOINTS_WEB_EXPOSURE_INCLUDE=health,info,prometheus`

## 4. `servers/RGZACICD/env/runner.env.example`

Use this to store the Bitbucket runner UUID and OAuth values after the runner is created in Bitbucket Cloud.

## 5. `servers/RGZADEVOPS01/env/app.env.example`

This is a server-side reference for app runtime and release behavior. The deployed stack ultimately uses the actual runtime env file placed under `/opt/rohlig/shared/env/runtime.env`.

## Important rule

If you need to change the backend repo slug, frontend repo slug, branch names, or build commands, do not edit shell scripts first. Update the config files. The scripts source those values automatically.
