# Standard Defaults Used In This Repo

This repo is wired as a **standard new-project baseline** for Röhlig when some project details do not exist yet.

## Repo names

- Backend repository: `rohlig-easy-estimate-be`
- Frontend repository: `rohlig-easy-estimate-fe`

## Build defaults

- Backend build command: `./mvnw -B -ntp clean package -DskipTests`
- Frontend build command: `npm ci && npm run build`
- Backend artifact discovery: `target/*.jar`
- Frontend dist hint: `dist`

## Runtime image defaults

- Backend image: `rohlig-easy-estimate-backend:<release-id>`
- Frontend image: `rohlig-easy-estimate-frontend:<release-id>`

## Container defaults

- Postgres: `rohlig-postgres`
- Kafka: `rohlig-kafka`
- Backend: `rohlig-backend`
- Frontend: `rohlig-frontend`
- Nginx: `rohlig-nginx`
- Prometheus: `rohlig-prometheus`
- Grafana: `rohlig-grafana`

## Port defaults

- Frontend through Nginx: `80`
- Backend direct: `8080`
- Kafka external: `9092`
- Prometheus: `9090`
- Grafana: `3000`

## Health defaults

- Backend health: `/actuator/health`
- Backend metrics: `/actuator/prometheus`

## Data stack default

This repo now assumes **Postgres and Kafka run in the same Docker Compose stack on the app server**. That makes the initial deployment more self-contained for a brand-new environment.

## Secrets still requiring change

Before a real deployment, change at least these values:

- `BITBUCKET_WORKSPACE`
- `BITBUCKET_APP_USER`
- `BITBUCKET_APP_PASSWORD`
- `SPRING_DATASOURCE_PASSWORD`
- `POSTGRES_PASSWORD`
- `GRAFANA_ADMIN_PASSWORD`
