# Röhlig Two-Server DevOps Master Repo

This is the final operations repo for a two-server Röhlig deployment.

It is built for these two Ubuntu 22.04.4 LTS servers:

- **RGZACICD** — CI/CD server — `172.28.29.35`
- **RGZADEVOPS01** — application server — `172.28.29.68`

Both servers already have Docker and Docker Compose available.

This repo is designed so that you can:

1. open one repo
2. edit a small number of config files
3. bootstrap both servers
4. build the backend and frontend from Bitbucket
5. package a release
6. deploy it over SSH to the app server
7. run smoke tests
8. roll back if needed



## Standardized defaults used in this version

Because you said these are **new projects and new servers**, this version ships with standardized defaults for the missing application details:

- backend repo: `rohlig-easy-estimate-be`
- frontend repo: `rohlig-easy-estimate-fe`
- backend build: `./mvnw -B -ntp clean package -DskipTests`
- frontend build: `npm ci && npm run build`
- backend port: `8080`
- frontend public port through Nginx: `80`
- backend health: `/actuator/health`
- backend metrics: `/actuator/prometheus`
- app stack on app server: backend + frontend + Postgres + Kafka + Nginx + Prometheus + Grafana

See `docs/10-standard-defaults.md` for the full baseline.

## Fastest path

This repo now includes an **ordered-run** folder that gives you the strict top-to-bottom sequence.

Start here:

```bash
cd rohlig-two-server-standardized-repo
./ordered-run/01-local-prepare-and-validate.sh
```

Then follow:

- `ordered-run/00-run-this-in-order.md`
- `ordered-run/README.md`

## What this repo contains

- per-server scripts
- per-folder Markdown instructions
- central configuration files
- release packaging scripts
- Docker runtime image templates
- application stack Compose files
- monitoring and reverse proxy configuration
- Bitbucket Pipelines template
- optional Jenkins pipeline file
- repo sanity checks
- config validation scripts
- stage-by-stage validation and smoke-test scripts

## Important safety note

This repo intentionally does **not** store any real passwords, app passwords, runner tokens, database passwords, or private keys.

Use the passwords you already have only for the first SSH login. After that, switch to SSH keys.

## Current wiring assumptions

This repo is wired around these assumed Röhlig repository slugs and standard build commands:

- backend repo: `rohlig-easy-estimate-be`
- frontend repo: `rohlig-easy-estimate-fe`
- backend build: `./mvnw -B -ntp clean package -DskipTests`
- frontend build: `npm ci && npm run build`

If your real slugs or build commands differ, edit **only**:

- `config/platform.env`
- `config/bitbucket.env`

The scripts read from those files, so you do not have to search through the repo.

## Recommended execution order

1. Read `docs/00-start-here.md`
2. Copy and edit the example config files in `config/`
3. Run the local validation scripts in `scripts/local/`
4. Bootstrap `RGZACICD`
5. Bootstrap `RGZADEVOPS01`
6. Set up SSH key trust from CI/CD server to app server
7. Set up the Bitbucket runner on `RGZACICD`
8. Run the manual end-to-end deploy once
9. Enable the Bitbucket pipeline
10. Use the smoke test and rollback scripts for operations

## Repo layout

```text
rohlig-two-server-master-repo/
├── README.md
├── config/
├── docs/
├── checks/
├── deploy/
│   └── compose/
├── docker/
│   ├── backend-runtime/
│   └── frontend-runtime/
├── pipelines/
├── scripts/
│   ├── lib/
│   ├── local/
│   └── orchestrators/
└── servers/
    ├── RGZACICD/
    └── RGZADEVOPS01/
```

## Default exposed URLs for your dev computer

After deployment, the default URLs are:

- Frontend: `http://172.28.29.68/`
- Backend direct: `http://172.28.29.68:8080/`
- Backend health: `http://172.28.29.68:8080/actuator/health`
- Backend via reverse proxy: `http://172.28.29.68/api/`
- Kafka external listener: `172.28.29.68:9092`
- Prometheus: `http://172.28.29.68:9090/`
- Grafana: `http://172.28.29.68:3000/`
- Optional Jenkins: `http://172.28.29.35:8080/`

## Quick start

```bash
cd rohlig-two-server-master-repo
cp config/platform.env.example config/platform.env
cp config/bitbucket.env.example config/bitbucket.env
cp config/runtime.env.example config/runtime.env
find . -type f -name "*.sh" -exec chmod +x {} \;
./checks/repo-sanity-check.sh
./checks/run-all-validations.sh
```

Then follow `docs/00-start-here.md` and `docs/09-stage-tests.md`.
