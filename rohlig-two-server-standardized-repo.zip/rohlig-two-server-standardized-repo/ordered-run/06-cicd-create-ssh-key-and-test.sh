#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[CICD] Creating SSH key if needed"
./servers/RGZACICD/scripts/20-create-ssh-key.sh

cat <<'EOT'

Now run this manually on RGZACICD to install the public key on the app server:
ssh-copy-id RGITDev@172.28.29.68

Then rerun this file or continue with:
./servers/RGZACICD/scripts/21-test-app-ssh.sh
EOT

echo
echo "[CICD] Testing passwordless SSH if already installed"
./servers/RGZACICD/scripts/21-test-app-ssh.sh || true
