#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[CICD] Verifying deployment"
./scripts/orchestrators/30-verify-deployment.sh

echo
echo "[CICD] Running smoke tests"
./scripts/orchestrators/40-run-smoke-tests.sh

echo "[OK] Manual verify and smoke tests completed"
