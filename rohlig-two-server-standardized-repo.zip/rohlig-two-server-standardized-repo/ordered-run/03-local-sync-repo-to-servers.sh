#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[LOCAL] Syncing repo to both servers"
./scripts/local/20-sync-repo-to-servers.sh

cat <<'EOT'

After sync:
- on RGZACICD go to ~/rohlig-two-server-master-repo
- on RGZADEVOPS01 go to ~/rohlig-two-server-master-repo
EOT
