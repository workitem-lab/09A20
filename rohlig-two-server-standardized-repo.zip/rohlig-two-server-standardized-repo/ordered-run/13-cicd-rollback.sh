#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[CICD] Executing rollback on app server"
./scripts/orchestrators/50-rollback-remote.sh

echo
echo "[CICD] Verifying application after rollback"
./scripts/orchestrators/30-verify-deployment.sh
./scripts/orchestrators/40-run-smoke-tests.sh

echo "[OK] Rollback sequence completed"
