# Exact Run Order

Use this exact sequence.

## Before you start

1. Do **not** store passwords in this repo.
2. Use the first password login only to get in.
3. After that, switch to SSH keys from the CI/CD server to the app server.
4. Keep all config in:
   - `config/platform.env`
   - `config/bitbucket.env`
   - `config/runtime.env`

## Step order

### LOCAL machine
1. `./ordered-run/01-local-prepare-and-validate.sh`
2. `./ordered-run/02-local-first-logins.sh`
3. `./ordered-run/03-local-sync-repo-to-servers.sh`

### CICD server — `RGZACICD`
4. `./ordered-run/04-cicd-bootstrap.sh`

### APP server — `RGZADEVOPS01`
5. `./ordered-run/05-app-bootstrap.sh`

### CICD server — `RGZACICD`
6. `./ordered-run/06-cicd-create-ssh-key-and-test.sh`
7. follow `ordered-run/07-cicd-runner-start.md`
8. `./ordered-run/08-cicd-manual-build-package.sh`
9. `./ordered-run/09-cicd-manual-deploy.sh`
10. `./ordered-run/10-cicd-manual-verify-and-smoke.sh`

### LOCAL machine
11. `./ordered-run/11-local-exposed-url-checks.sh`

### APP server — `RGZADEVOPS01`
12. `./ordered-run/12-app-rollback-readiness.sh`

### CICD server — `RGZACICD`
13. `./ordered-run/13-cicd-rollback.sh` only when needed

## Expected exposed URLs

- Frontend: `http://172.28.29.68/`
- Backend: `http://172.28.29.68:8080/`
- Backend health: `http://172.28.29.68:8080/actuator/health`
- Prometheus: `http://172.28.29.68:9090/`
- Grafana: `http://172.28.29.68:3000/`
- Kafka external: `172.28.29.68:9092`

## Where to fill the real Bitbucket values

Edit:
- `config/bitbucket.env`
- `config/runtime.env`

Then rerun:
```bash
./checks/run-all-validations.sh
```
