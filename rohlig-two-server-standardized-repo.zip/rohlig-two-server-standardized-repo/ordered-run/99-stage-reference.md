# Stage Reference

This file maps the ordered sequence to the detailed documentation.

- `ordered-run/01-local-prepare-and-validate.sh`
  - `docs/00-start-here.md`
  - `docs/02-config-model.md`
  - `docs/03-local-machine.md`
  - `docs/09-stage-tests.md`

- `ordered-run/04-cicd-bootstrap.sh`
  - `docs/04-cicd-server.md`

- `ordered-run/05-app-bootstrap.sh`
  - `docs/05-app-server.md`

- `ordered-run/07-cicd-runner-start.md`
  - `docs/06-bitbucket-pipeline.md`

- `ordered-run/08-cicd-manual-build-package.sh`
  - `docs/07-ops-flow.md`

- `ordered-run/13-cicd-rollback.sh`
  - `docs/08-troubleshooting.md`

Use the ordered-run folder first. Use the docs folder when you want the explanation behind each step.
