#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[LOCAL] First login helper"
./scripts/local/10-first-logins.sh

cat <<'EOT'

Next actions:
1. Open one terminal to:
   ssh RGITDev@172.28.29.35
2. Open another terminal to:
   ssh RGITDev@172.28.29.68

If SSH key auth blocks the first login, force password mode:
ssh -o PreferredAuthentications=password -o PubkeyAuthentication=no -o IdentitiesOnly=yes RGITDev@172.28.29.35
ssh -o PreferredAuthentications=password -o PubkeyAuthentication=no -o IdentitiesOnly=yes RGITDev@172.28.29.68
EOT
