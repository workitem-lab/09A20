#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[LOCAL] Checking exposed URLs from your dev computer"
./scripts/local/30-check-exposed-urls.sh
