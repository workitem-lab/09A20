#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[CICD] Running RGZACICD precheck"
./servers/RGZACICD/scripts/00-precheck.sh

echo "[CICD] Bootstrapping RGZACICD"
./servers/RGZACICD/scripts/10-bootstrap-cicd.sh

echo "[CICD] Verifying RGZACICD"
./servers/RGZACICD/scripts/05-verify-bootstrap.sh
./servers/RGZACICD/scripts/50-status.sh

echo "[OK] CICD bootstrap sequence completed"
