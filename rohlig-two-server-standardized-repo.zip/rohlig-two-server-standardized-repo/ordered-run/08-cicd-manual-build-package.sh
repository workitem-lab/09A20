#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[CICD] Building and packaging release"
./scripts/orchestrators/10-build-package.sh

echo
echo "[CICD] Latest release files"
ls -lah /opt/rohlig-ci/releases | tail -n 20

echo "[OK] Manual build and package completed"
