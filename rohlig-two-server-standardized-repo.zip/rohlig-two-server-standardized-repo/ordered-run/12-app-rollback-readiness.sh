#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[APP] Checking rollback readiness"
./servers/RGZADEVOPS01/scripts/55-test-rollback-readiness.sh
