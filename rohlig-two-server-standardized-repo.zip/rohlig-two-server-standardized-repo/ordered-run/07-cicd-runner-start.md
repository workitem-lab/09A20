# CICD Runner Start

Run this on **RGZACICD** after bootstrap and SSH trust are complete.

## 1. Create the runner env file

```bash
cd ~/rohlig-two-server-master-repo/servers/RGZACICD/env
cp runner.env.example runner.env
vi runner.env
```

Fill the real Bitbucket runner values:
- account UUID or workspace UUID
- runner UUID
- OAuth client ID
- OAuth client secret

## 2. Start the runner

```bash
cd ~/rohlig-two-server-master-repo
./servers/RGZACICD/scripts/30-start-bitbucket-runner.sh
./servers/RGZACICD/scripts/31-test-runner.sh
./servers/RGZACICD/scripts/50-status.sh
```

Pass condition:
- the `rohlig-bitbucket-runner` container is running
- logs do not show immediate startup failure
