#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[APP] Running RGZADEVOPS01 precheck"
./servers/RGZADEVOPS01/scripts/00-precheck.sh

echo "[APP] Bootstrapping RGZADEVOPS01"
./servers/RGZADEVOPS01/scripts/10-bootstrap-app.sh
./servers/RGZADEVOPS01/scripts/20-create-app-layout.sh

echo "[APP] Verifying RGZADEVOPS01"
./servers/RGZADEVOPS01/scripts/15-verify-bootstrap.sh
./servers/RGZADEVOPS01/scripts/60-status.sh

echo "[OK] App bootstrap sequence completed"
