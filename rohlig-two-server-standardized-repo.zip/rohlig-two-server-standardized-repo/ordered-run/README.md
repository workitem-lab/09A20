# Ordered Run Folder

This folder is the opinionated top-to-bottom execution path for the Röhlig two-server deployment.

Use these files in exact order. Each file tells you **where it must run**:

- **LOCAL** = your dev laptop
- **CICD** = `RGZACICD` (`172.28.29.35`)
- **APP** = `RGZADEVOPS01` (`172.28.29.68`)

The repo still keeps the original docs and per-server folders, but this folder is the fastest path when you want a strict sequence.

Start with `00-run-this-in-order.md`.
