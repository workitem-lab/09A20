#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[CICD] Deploying latest release to app server"
./scripts/orchestrators/20-deploy-release.sh

echo "[OK] Manual deploy completed"
