#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[LOCAL] Preparing config files"
[[ -f config/platform.env ]] || cp config/platform.env.example config/platform.env
[[ -f config/bitbucket.env ]] || cp config/bitbucket.env.example config/bitbucket.env
[[ -f config/runtime.env ]] || cp config/runtime.env.example config/runtime.env

echo "[LOCAL] Making scripts executable"
find . -type f -name "*.sh" -exec chmod +x {} \;

echo "[LOCAL] Running local tool check"
./scripts/local/00-check-local.sh

echo "[LOCAL] Running repo checks"
./checks/repo-sanity-check.sh
./checks/validate-step-order.sh
./checks/run-all-validations.sh

echo "[OK] Local prepare and validation step completed"
