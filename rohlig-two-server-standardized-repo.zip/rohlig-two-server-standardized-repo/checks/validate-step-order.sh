#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ORDERED_DIR="$ROOT_DIR/ordered-run"

[[ -d "$ORDERED_DIR" ]] || { echo "[ERROR] Missing ordered-run directory" >&2; exit 1; }

required_files=(
  "README.md"
  "00-run-this-in-order.md"
  "01-local-prepare-and-validate.sh"
  "02-local-first-logins.sh"
  "03-local-sync-repo-to-servers.sh"
  "04-cicd-bootstrap.sh"
  "05-app-bootstrap.sh"
  "06-cicd-create-ssh-key-and-test.sh"
  "07-cicd-runner-start.md"
  "08-cicd-manual-build-package.sh"
  "09-cicd-manual-deploy.sh"
  "10-cicd-manual-verify-and-smoke.sh"
  "11-local-exposed-url-checks.sh"
  "12-app-rollback-readiness.sh"
  "13-cicd-rollback.sh"
  "99-stage-reference.md"
)

for rel in "${required_files[@]}"; do
  [[ -f "$ORDERED_DIR/$rel" ]] || { echo "[ERROR] Missing ordered-run file: $rel" >&2; exit 1; }
done

find "$ORDERED_DIR" -type f -name '*.sh' -print0 | while IFS= read -r -d '' file; do
  bash -n "$file"
done

echo "[OK] Ordered step files validation passed"
