#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

for f in \
  "$ROOT_DIR/config/platform.env.example" \
  "$ROOT_DIR/config/bitbucket.env.example" \
  "$ROOT_DIR/config/runtime.env.example" \
  "$ROOT_DIR/deploy/compose/docker-compose.prod.yml" \
  "$ROOT_DIR/deploy/compose/nginx/default.conf" \
  "$ROOT_DIR/deploy/compose/prometheus/prometheus.yml" \
  "$ROOT_DIR/pipelines/bitbucket-pipelines.yml" \
  "$ROOT_DIR/pipelines/Jenkinsfile"; do
  [[ -f "$f" ]] || { echo "[ERROR] Missing file: $f" >&2; exit 1; }
done

if [[ -f "$ROOT_DIR/config/platform.env" ]]; then
  echo "[OK] platform.env present"
else
  echo "[WARN] platform.env not copied yet"
fi

if [[ -f "$ROOT_DIR/config/bitbucket.env" ]]; then
  echo "[OK] bitbucket.env present"
else
  echo "[WARN] bitbucket.env not copied yet"
fi

if [[ -f "$ROOT_DIR/config/runtime.env" ]]; then
  echo "[OK] runtime.env present"
else
  echo "[WARN] runtime.env not copied yet"
fi

find "$ROOT_DIR" -type f -name '*.sh' -print0 | while IFS= read -r -d '' file; do
  bash -n "$file"
done

echo "[OK] shell syntax checks passed"

if command -v python3 >/dev/null 2>&1; then
  python3 - <<PY
from pathlib import Path
root = Path(r"$ROOT_DIR")
for rel in [
    "README.md",
    "docs/00-start-here.md",
    "docs/09-stage-tests.md",
    "servers/RGZACICD/README.md",
    "servers/RGZADEVOPS01/README.md",
    "ordered-run/README.md",
    "ordered-run/00-run-this-in-order.md",
]:
    p = root / rel
    assert p.exists(), f"Missing markdown file: {p}"
print("[OK] markdown presence checks passed")
PY
fi
