#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
source "$ROOT_DIR/scripts/lib/common.sh"

load_config
load_runtime_env_if_present

fail() {
  echo "[ERROR] $*" >&2
  exit 1
}

warn() {
  echo "[WARN] $*" >&2
}

require_non_empty() {
  local name="$1"
  local value="${!name:-}"
  [[ -n "$value" ]] || fail "Variable is empty: $name"
}

warn_on_placeholder() {
  local name="$1"
  local value="${!name:-}"
  case "$value" in
    replace-me|your-*|__SET_*|changeme|CHANGE_ME|example|example.com)
      warn "Variable still contains a placeholder value: $name=$value"
      ;;
  esac
}

check_ip() {
  local name="$1"
  local ip="${!name:-}"
  [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || fail "Invalid IPv4 format for $name: $ip"
  IFS='.' read -r a b c d <<< "$ip"
  for octet in "$a" "$b" "$c" "$d"; do
    (( octet >= 0 && octet <= 255 )) || fail "IPv4 octet out of range in $name: $ip"
  done
}

check_port() {
  local name="$1"
  local value="${!name:-}"
  [[ "$value" =~ ^[0-9]+$ ]] || fail "Port is not numeric: $name=$value"
  (( value >= 1 && value <= 65535 )) || fail "Port out of range: $name=$value"
}

check_path_abs() {
  local name="$1"
  local value="${!name:-}"
  [[ "$value" = /* ]] || fail "Path must be absolute: $name=$value"
}

require_non_empty STACK_NAME
require_non_empty CICD_HOST
require_non_empty CICD_SSH_USER
require_non_empty APP_HOST
require_non_empty APP_SSH_USER
require_non_empty BACKEND_REPO_SLUG
require_non_empty FRONTEND_REPO_SLUG
require_non_empty BACKEND_BRANCH
require_non_empty FRONTEND_BRANCH
require_non_empty BITBUCKET_BASE_URL
require_non_empty BITBUCKET_WORKSPACE
require_non_empty RUNNER_LABEL_1
require_non_empty RUNNER_LABEL_2
require_non_empty RUNNER_LABEL_3
warn_on_placeholder STACK_NAME
warn_on_placeholder CICD_HOST
warn_on_placeholder CICD_SSH_USER
warn_on_placeholder APP_HOST
warn_on_placeholder APP_SSH_USER
warn_on_placeholder BACKEND_REPO_SLUG
warn_on_placeholder FRONTEND_REPO_SLUG
warn_on_placeholder BACKEND_BRANCH
warn_on_placeholder FRONTEND_BRANCH
warn_on_placeholder BITBUCKET_BASE_URL
warn_on_placeholder BITBUCKET_WORKSPACE
warn_on_placeholder RUNNER_LABEL_1
warn_on_placeholder RUNNER_LABEL_2
warn_on_placeholder RUNNER_LABEL_3

check_ip CICD_SERVER_IP
check_ip APP_SERVER_IP

check_path_abs CICD_ROOT
check_path_abs APP_ROOT
check_path_abs WORKSPACE_DIR
check_path_abs RELEASES_DIR

check_port PUBLIC_HTTP_PORT
check_port PUBLIC_BACKEND_PORT
check_port PUBLIC_KAFKA_PORT
check_port PUBLIC_PROMETHEUS_PORT
check_port PUBLIC_GRAFANA_PORT
check_port BACKEND_RUNTIME_PORT
check_port FRONTEND_RUNTIME_PORT
check_port KAFKA_CONTROLLER_PORT
check_port KAFKA_INTERNAL_PORT
check_port KAFKA_EXTERNAL_PORT

[[ "$BITBUCKET_BASE_URL" =~ ^https?:// ]] || fail "BITBUCKET_BASE_URL must start with http:// or https://"
[[ "$BACKEND_HEALTH_PATH" = /* ]] || fail "BACKEND_HEALTH_PATH must start with /"
[[ "$BACKEND_PROMETHEUS_PATH" = /* ]] || fail "BACKEND_PROMETHEUS_PATH must start with /"

[[ "$WORKSPACE_DIR" == "$CICD_ROOT"* ]] || warn "WORKSPACE_DIR is not under CICD_ROOT"
[[ "$RELEASES_DIR" == "$CICD_ROOT"* ]] || warn "RELEASES_DIR is not under CICD_ROOT"

if [[ -f "$ROOT_DIR/config/runtime.env" ]]; then
  require_non_empty SPRING_PROFILES_ACTIVE
  require_non_empty SPRING_DATASOURCE_URL
  require_non_empty SPRING_DATASOURCE_USERNAME
  require_non_empty SPRING_DATASOURCE_PASSWORD
  require_non_empty SPRING_KAFKA_BOOTSTRAP_SERVERS
  warn_on_placeholder SPRING_PROFILES_ACTIVE
  warn_on_placeholder SPRING_DATASOURCE_URL
  warn_on_placeholder SPRING_DATASOURCE_USERNAME
  warn_on_placeholder SPRING_DATASOURCE_PASSWORD
  warn_on_placeholder SPRING_KAFKA_BOOTSTRAP_SERVERS
fi

echo "[OK] Config validation passed"
