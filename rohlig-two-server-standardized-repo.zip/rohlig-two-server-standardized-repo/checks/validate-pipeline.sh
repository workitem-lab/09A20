#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PIPELINE_FILE="$ROOT_DIR/pipelines/bitbucket-pipelines.yml"

[[ -f "$PIPELINE_FILE" ]] || { echo "[ERROR] Missing pipeline file" >&2; exit 1; }

grep -q 'self.hosted' "$PIPELINE_FILE" || { echo "[ERROR] Pipeline missing self.hosted runner label" >&2; exit 1; }
grep -q './checks/repo-sanity-check.sh' "$PIPELINE_FILE" || { echo "[ERROR] Pipeline missing repo sanity step" >&2; exit 1; }
grep -q './scripts/orchestrators/10-build-package.sh' "$PIPELINE_FILE" || { echo "[ERROR] Pipeline missing build/package step" >&2; exit 1; }
grep -q './scripts/orchestrators/20-deploy-release.sh' "$PIPELINE_FILE" || { echo "[ERROR] Pipeline missing deploy step" >&2; exit 1; }
grep -q './scripts/orchestrators/40-run-smoke-tests.sh' "$PIPELINE_FILE" || { echo "[ERROR] Pipeline missing smoke-test step" >&2; exit 1; }
grep -q 'APP_SERVER_RUNTIME_ENV_B64' "$PIPELINE_FILE" || { echo "[ERROR] Pipeline missing runtime env variable decode" >&2; exit 1; }

echo "[OK] Pipeline structure validation passed"
