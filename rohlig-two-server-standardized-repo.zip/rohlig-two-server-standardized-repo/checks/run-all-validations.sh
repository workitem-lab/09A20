#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

run_step() {
  local name="$1"
  local cmd="$2"
  echo
  echo "===== $name ====="
  bash -lc "$cmd"
}

run_step "Repo sanity" "cd '$ROOT_DIR' && ./checks/repo-sanity-check.sh"
run_step "Config validation" "cd '$ROOT_DIR' && ./checks/validate-config.sh"
run_step "Pipeline validation" "cd '$ROOT_DIR' && ./checks/validate-pipeline.sh"
run_step "Ordered step validation" "cd '$ROOT_DIR' && ./checks/validate-step-order.sh"

if command -v docker >/dev/null 2>&1; then
  run_step "Compose template validation" "cd '$ROOT_DIR' && ./checks/validate-compose-template.sh"
else
  echo
  echo "===== Compose template validation ====="
  echo "[WARN] docker not found on this machine, skipping compose validation"
fi

echo

echo "[OK] Local validation pass complete"
