#!/usr/bin/env bash
set -euo pipefail

echo "=== RGZACICD PRECHECK ==="
whoami
hostname
pwd
printf '\n--- OS ---\n'
cat /etc/os-release || true
printf '\n--- CPU / MEMORY / DISK ---\n'
nproc || true
free -h || true
df -h || true
printf '\n--- NETWORK ---\n'
ip -brief a || true
printf '\n--- DOCKER ---\n'
docker --version || true
docker compose version || true
sudo systemctl status docker --no-pager || true
printf '\n--- SUDO ---\n'
sudo -l || true
