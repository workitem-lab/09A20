#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../../.." && pwd)"
PLATFORM_ENV="$ROOT_DIR/config/platform.env"
APP_USER="RGITDev"
APP_IP="172.28.29.68"

if [[ -f "$PLATFORM_ENV" ]]; then
  set -a
  # shellcheck source=/dev/null
  source "$PLATFORM_ENV"
  set +a
  APP_USER="${APP_SSH_USER:-$APP_USER}"
  APP_IP="${APP_SERVER_IP:-$APP_IP}"
fi

KEY_PATH="${HOME}/.ssh/id_ed25519"
mkdir -p "${HOME}/.ssh"
chmod 700 "${HOME}/.ssh"

if [[ ! -f "${KEY_PATH}" ]]; then
  ssh-keygen -t ed25519 -C "rohlig-cicd@RGZACICD" -f "${KEY_PATH}" -N ""
fi

chmod 600 "${KEY_PATH}"
chmod 644 "${KEY_PATH}.pub"

echo "Public key:"
cat "${KEY_PATH}.pub"
echo
echo "Next: ssh-copy-id ${APP_USER}@${APP_IP}"
