#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../../.." && pwd)"
PLATFORM_ENV="$ROOT_DIR/config/platform.env"
APP_USER="RGITDev"
APP_IP="172.28.29.68"

if [[ -f "$PLATFORM_ENV" ]]; then
  set -a
  # shellcheck source=/dev/null
  source "$PLATFORM_ENV"
  set +a
  APP_USER="${APP_SSH_USER:-$APP_USER}"
  APP_IP="${APP_SERVER_IP:-$APP_IP}"
fi

ssh -o BatchMode=yes -o ConnectTimeout=10 "${APP_USER}@${APP_IP}" "hostname && whoami && uptime"
