#!/usr/bin/env bash
set -euo pipefail

if ! docker ps --format '{{.Names}}' | grep -qx 'rohlig-bitbucket-runner'; then
  echo "[ERROR] Runner container rohlig-bitbucket-runner is not running" >&2
  exit 1
fi

docker inspect rohlig-bitbucket-runner --format '{{.State.Status}}' | grep -qx 'running'
docker logs --tail 50 rohlig-bitbucket-runner || true

echo "[OK] Bitbucket runner container is running"
