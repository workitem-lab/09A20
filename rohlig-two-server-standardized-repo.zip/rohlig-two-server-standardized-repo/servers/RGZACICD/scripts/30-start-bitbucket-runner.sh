#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
RUNNER_ENV="${SCRIPT_DIR}/../env/runner.env"

if [[ ! -f "${RUNNER_ENV}" ]]; then
  echo "[ERROR] Missing ${RUNNER_ENV}. Copy runner.env.example to runner.env and fill it first." >&2
  exit 1
fi

set -a
source "${RUNNER_ENV}"
set +a

for var in RUNNER_UUID OAUTH_CLIENT_ID OAUTH_CLIENT_SECRET ACCOUNT_UUID; do
  [[ -n "${!var:-}" ]] || { echo "[ERROR] Missing ${var}" >&2; exit 1; }
done

RUNNER_DIR="/opt/rohlig-ci/bitbucket-runner"
mkdir -p "${RUNNER_DIR}"

docker rm -f rohlig-bitbucket-runner >/dev/null 2>&1 || true

docker run -d \
  --name rohlig-bitbucket-runner \
  --restart unless-stopped \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v "${RUNNER_DIR}:/tmp" \
  -e ACCOUNT_UUID="${ACCOUNT_UUID}" \
  -e RUNNER_UUID="${RUNNER_UUID}" \
  -e OAUTH_CLIENT_ID="${OAUTH_CLIENT_ID}" \
  -e OAUTH_CLIENT_SECRET="${OAUTH_CLIENT_SECRET}" \
  docker-public.packages.atlassian.com/sox/atlassian/bitbucket-pipelines-runner:1

docker ps --filter name=rohlig-bitbucket-runner
