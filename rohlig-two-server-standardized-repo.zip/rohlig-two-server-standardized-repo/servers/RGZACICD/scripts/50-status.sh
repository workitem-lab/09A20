#!/usr/bin/env bash
set -euo pipefail

echo "=== RGZACICD STATUS ==="
hostname
uptime
echo
docker --version || true
docker compose version || true
docker ps || true
echo
ls -lah /opt/rohlig-ci || true
ls -lah /opt/rohlig-ci/releases || true
