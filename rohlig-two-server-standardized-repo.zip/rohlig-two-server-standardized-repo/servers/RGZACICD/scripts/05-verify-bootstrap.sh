#!/usr/bin/env bash
set -euo pipefail

fail() { echo "[ERROR] $*" >&2; exit 1; }
pass() { echo "[OK] $*"; }

for cmd in git ssh rsync docker; do
  command -v "$cmd" >/dev/null 2>&1 || fail "Missing command: $cmd"
done

sudo systemctl is-active --quiet docker || fail "Docker service is not active"
docker compose version >/dev/null 2>&1 || fail "docker compose plugin is not working"
[[ -d /opt/rohlig-ci/workspace ]] || fail "/opt/rohlig-ci/workspace missing"
[[ -d /opt/rohlig-ci/releases ]] || fail "/opt/rohlig-ci/releases missing"
getent hosts bitbucket.org >/dev/null 2>&1 || fail "DNS lookup for bitbucket.org failed"

pass "CI/CD bootstrap verification passed"
