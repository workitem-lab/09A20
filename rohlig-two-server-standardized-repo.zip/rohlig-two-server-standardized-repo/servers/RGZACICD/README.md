# RGZACICD

This folder contains everything specific to the CI/CD server.

## Files

- `scripts/00-precheck.sh`
- `scripts/05-verify-bootstrap.sh`
- `scripts/10-bootstrap-cicd.sh`
- `scripts/20-create-ssh-key.sh`
- `scripts/21-test-app-ssh.sh`
- `scripts/30-start-bitbucket-runner.sh`
- `scripts/31-test-runner.sh`
- `scripts/40-install-jenkins-optional.sh`
- `scripts/50-status.sh`
- `env/runner.env.example`

## Normal order

```bash
./00-precheck.sh
./10-bootstrap-cicd.sh
./05-verify-bootstrap.sh
./20-create-ssh-key.sh
./21-test-app-ssh.sh
./30-start-bitbucket-runner.sh
./31-test-runner.sh
```
