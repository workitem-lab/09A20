# RGZADEVOPS01

This folder contains everything specific to the application server.

## Files

- `scripts/00-precheck.sh`
- `scripts/10-bootstrap-app.sh`
- `scripts/15-verify-bootstrap.sh`
- `scripts/20-create-app-layout.sh`
- `scripts/40-deploy-release.sh`
- `scripts/42-verify-current-release.sh`
- `scripts/50-rollback-release.sh`
- `scripts/55-test-rollback-readiness.sh`
- `scripts/60-status.sh`
- `scripts/70-smoke-tests.sh`
- `env/app.env.example`

## Normal order

```bash
./00-precheck.sh
./10-bootstrap-app.sh
./20-create-app-layout.sh
./15-verify-bootstrap.sh
```

Deployment is normally triggered remotely from the CI/CD server.
