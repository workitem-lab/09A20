#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/opt/rohlig"

echo "=== APP STATUS ==="
hostname
uptime
echo

echo "--- Docker ---"
docker --version || true
docker compose version || true
docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}' || true
echo

echo "--- Releases ---"
ls -lah "${APP_ROOT}" || true
ls -lah "${APP_ROOT}/releases" || true
readlink -f "${APP_ROOT}/current" || true
echo

echo "--- Ports ---"
sudo ss -tulpn | grep -E ':80|:8080|:9092|:9090|:3000' || true
echo

echo "--- Health ---"
curl -I http://localhost || true
curl -fsS http://localhost:8080/actuator/health || true
echo

echo "--- Core containers ---"
for name in rohlig-postgres rohlig-kafka rohlig-backend rohlig-frontend rohlig-nginx rohlig-prometheus rohlig-grafana; do
  docker inspect "$name" --format '{{.Name}} -> {{.State.Status}}' 2>/dev/null || echo "$name -> missing"
done
