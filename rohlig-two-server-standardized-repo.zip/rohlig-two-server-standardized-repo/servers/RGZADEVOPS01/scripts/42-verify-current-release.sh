#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/opt/rohlig"
CURRENT_LINK="${APP_ROOT}/current"
RUNTIME_ENV="${APP_ROOT}/shared/env/runtime.env"

[[ -L "$CURRENT_LINK" ]] || { echo "[ERROR] Current symlink missing: $CURRENT_LINK" >&2; exit 1; }
CURRENT_DIR="$(readlink -f "$CURRENT_LINK")"
[[ -d "$CURRENT_DIR" ]] || { echo "[ERROR] Current release directory missing: $CURRENT_DIR" >&2; exit 1; }
[[ -f "$RUNTIME_ENV" ]] || { echo "[ERROR] Runtime env missing: $RUNTIME_ENV" >&2; exit 1; }
[[ -f "$CURRENT_DIR/env/release.env" ]] || { echo "[ERROR] Release env missing in current release" >&2; exit 1; }
[[ -f "$CURRENT_DIR/compose/docker-compose.prod.yml" ]] || { echo "[ERROR] Compose file missing in current release" >&2; exit 1; }

cd "$CURRENT_DIR/compose"
docker compose \
  --env-file ../env/release.env \
  --env-file "$RUNTIME_ENV" \
  -f docker-compose.prod.yml \
  config >/dev/null

docker compose \
  --env-file ../env/release.env \
  --env-file "$RUNTIME_ENV" \
  -f docker-compose.prod.yml \
  ps

echo "[OK] Current release verification passed"
