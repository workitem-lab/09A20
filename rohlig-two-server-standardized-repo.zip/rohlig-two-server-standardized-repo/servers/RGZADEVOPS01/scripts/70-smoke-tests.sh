#!/usr/bin/env bash
set -euo pipefail

echo "[1] Frontend root"
curl -I http://localhost

echo
echo "[2] Backend health"
curl -fsS http://localhost:8080/actuator/health

echo
echo "[3] Reverse-proxied API health"
curl -fsS http://localhost/actuator/health || true

echo
echo "[4] Prometheus up"
curl -I http://localhost:9090 || true

echo
echo "[5] Grafana up"
curl -I http://localhost:3000 || true

echo
echo "[6] Postgres container state"
docker inspect rohlig-postgres --format '{{.State.Status}}'

echo
echo "[7] Kafka container state"
docker inspect rohlig-kafka --format '{{.State.Status}}'

echo
echo "[8] Containers"
docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
