#!/usr/bin/env bash
set -euo pipefail

fail() { echo "[ERROR] $*" >&2; exit 1; }
pass() { echo "[OK] $*"; }

for cmd in docker curl gzip; do
  command -v "$cmd" >/dev/null 2>&1 || fail "Missing command: $cmd"
done

sudo systemctl is-active --quiet docker || fail "Docker service is not active"
docker compose version >/dev/null 2>&1 || fail "docker compose plugin is not working"
[[ -d /opt/rohlig/releases ]] || fail "/opt/rohlig/releases missing"
[[ -d /opt/rohlig/shared/env ]] || fail "/opt/rohlig/shared/env missing"

for port in 80 8080 9092 9090 3000; do
  sudo ss -tulpn | grep -q ":${port} " && echo "[INFO] Port ${port} already in use" || true
done

pass "App server bootstrap verification passed"
