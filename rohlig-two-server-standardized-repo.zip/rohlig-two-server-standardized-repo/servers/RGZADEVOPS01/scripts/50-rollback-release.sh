#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/opt/rohlig"
RELEASES_DIR="${APP_ROOT}/releases"
CURRENT_LINK="${APP_ROOT}/current"
RUNTIME_ENV="${APP_ROOT}/shared/env/runtime.env"

mapfile -t RELEASES < <(find "${RELEASES_DIR}" -mindepth 1 -maxdepth 1 -type d | sort)
COUNT="${#RELEASES[@]}"

if (( COUNT < 2 )); then
  echo "Need at least two releases to roll back." >&2
  exit 1
fi

CURRENT_TARGET="$(readlink -f "${CURRENT_LINK}" || true)"
PREVIOUS=""
for (( i=COUNT-1; i>=0; i-- )); do
  if [[ "${RELEASES[$i]}" != "${CURRENT_TARGET}" ]]; then
    PREVIOUS="${RELEASES[$i]}"
    break
  fi
done

[[ -n "${PREVIOUS}" ]] || { echo "Could not determine previous release" >&2; exit 1; }

ln -sfn "${PREVIOUS}" "${CURRENT_LINK}"
cd "${PREVIOUS}/compose"
docker compose \
  --env-file ../env/release.env \
  --env-file "${RUNTIME_ENV}" \
  -f docker-compose.prod.yml \
  up -d --remove-orphans

echo "Rolled back to $(readlink -f "${CURRENT_LINK}")"
