#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="/opt/rohlig"
sudo mkdir -p "${ROOT_DIR}"/{releases,shared/env,shared/backups,shared/logs}
sudo chown -R "$USER:$USER" "${ROOT_DIR}"

echo "Created ${ROOT_DIR} layout"
find "${ROOT_DIR}" -maxdepth 2 -type d | sort
