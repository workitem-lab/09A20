#!/usr/bin/env bash
set -euo pipefail

sudo apt update
sudo apt install -y \
  ca-certificates curl gnupg lsb-release jq unzip zip net-tools \
  dnsutils rsync tree ufw gzip

if ! command -v docker >/dev/null 2>&1; then
  sudo install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  sudo chmod a+r /etc/apt/keyrings/docker.gpg
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
    sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
  sudo apt update
  sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

sudo usermod -aG docker "$USER" || true
sudo ufw allow 22/tcp || true
sudo ufw allow 80/tcp || true
sudo ufw allow 8080/tcp || true
sudo ufw allow 9092/tcp || true
sudo ufw allow 9090/tcp || true
sudo ufw allow 3000/tcp || true

echo "Bootstrap complete. Re-login if docker group membership does not apply immediately."
