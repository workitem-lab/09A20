#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 /tmp/<release>.tar.gz /tmp/runtime.env" >&2
  exit 1
fi

RELEASE_TAR="$1"
RUNTIME_ENV_SRC="$2"
APP_ROOT="/opt/rohlig"
RELEASES_DIR="${APP_ROOT}/releases"
CURRENT_LINK="${APP_ROOT}/current"
SHARED_RUNTIME_ENV="${APP_ROOT}/shared/env/runtime.env"

[[ -f "${RELEASE_TAR}" ]] || { echo "[ERROR] Missing release tarball: ${RELEASE_TAR}" >&2; exit 1; }
[[ -f "${RUNTIME_ENV_SRC}" ]] || { echo "[ERROR] Missing runtime env file: ${RUNTIME_ENV_SRC}" >&2; exit 1; }

sudo mkdir -p "${RELEASES_DIR}" "${APP_ROOT}/shared/env"
sudo chown -R "$USER:$USER" "${APP_ROOT}"

cp "${RUNTIME_ENV_SRC}" "${SHARED_RUNTIME_ENV}"
chmod 600 "${SHARED_RUNTIME_ENV}"

RELEASE_ID="$(basename "${RELEASE_TAR}" .tar.gz)"
TARGET_DIR="${RELEASES_DIR}/${RELEASE_ID}"
rm -rf "${TARGET_DIR}"
mkdir -p "${TARGET_DIR}"

tar -C "${RELEASES_DIR}" -xzf "${RELEASE_TAR}"

[[ -d "${TARGET_DIR}" ]] || { echo "[ERROR] Extracted release directory missing: ${TARGET_DIR}" >&2; exit 1; }
[[ -f "${TARGET_DIR}/env/release.env" ]] || { echo "[ERROR] Missing release.env inside ${TARGET_DIR}" >&2; exit 1; }
[[ -f "${TARGET_DIR}/compose/docker-compose.prod.yml" ]] || { echo "[ERROR] Missing docker-compose.prod.yml inside ${TARGET_DIR}" >&2; exit 1; }

cd "${TARGET_DIR}"

gzip -dc images/backend-image.tar.gz | docker load
gzip -dc images/frontend-image.tar.gz | docker load

ln -sfn "${TARGET_DIR}" "${CURRENT_LINK}"
cd "${TARGET_DIR}/compose"
docker compose \
  --env-file ../env/release.env \
  --env-file "${SHARED_RUNTIME_ENV}" \
  -f docker-compose.prod.yml \
  up -d --remove-orphans

sleep 12

echo "Current release: $(readlink -f "${CURRENT_LINK}")"
docker compose \
  --env-file ../env/release.env \
  --env-file "${SHARED_RUNTIME_ENV}" \
  -f docker-compose.prod.yml \
  ps
