#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/opt/rohlig"
RELEASES_DIR="${APP_ROOT}/releases"
CURRENT_LINK="${APP_ROOT}/current"

mapfile -t RELEASES < <(find "$RELEASES_DIR" -mindepth 1 -maxdepth 1 -type d | sort)
COUNT="${#RELEASES[@]}"

if (( COUNT < 2 )); then
  echo "[ERROR] Rollback not ready. Need at least two releases under $RELEASES_DIR" >&2
  exit 1
fi

CURRENT_TARGET="$(readlink -f "$CURRENT_LINK")"
PREVIOUS=""
for (( i=COUNT-1; i>=0; i-- )); do
  if [[ "${RELEASES[$i]}" != "$CURRENT_TARGET" ]]; then
    PREVIOUS="${RELEASES[$i]}"
    break
  fi
done

[[ -n "$PREVIOUS" ]] || { echo "[ERROR] Could not determine previous release" >&2; exit 1; }

echo "[OK] Rollback readiness passed"
echo "Current : $CURRENT_TARGET"
echo "Previous: $PREVIOUS"
