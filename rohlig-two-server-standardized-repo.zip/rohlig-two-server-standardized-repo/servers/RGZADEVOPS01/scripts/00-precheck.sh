#!/usr/bin/env bash
set -euo pipefail

echo "=== RGZADEVOPS01 PRECHECK ==="
whoami
hostname
pwd
printf '\n--- OS ---\n'
cat /etc/os-release || true
printf '\n--- CPU / MEMORY / DISK ---\n'
nproc || true
free -h || true
df -h || true
printf '\n--- NETWORK ---\n'
ip -brief a || true
printf '\n--- DOCKER ---\n'
docker --version || true
docker compose version || true
sudo systemctl status docker --no-pager || true
printf '\n--- PORTS ---\n'
sudo ss -tulpn | grep -E ':22|:80|:443|:8080|:9090|:3000|:9092' || true
