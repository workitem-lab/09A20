#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
source "$ROOT_DIR/scripts/lib/common.sh"

load_config
require_cmd rsync

EXCLUDES=(
  "--exclude=.git"
  "--exclude=*.zip"
  "--exclude=.DS_Store"
)

echo "[INFO] Syncing repo to ${CICD_SSH_USER}@${CICD_SERVER_IP}:~/rohlig-two-server-master-repo"
rsync -av --delete "${EXCLUDES[@]}" "${ROOT_DIR}/" "${CICD_SSH_USER}@${CICD_SERVER_IP}:~/rohlig-two-server-master-repo/"

echo "[INFO] Syncing repo to ${APP_SSH_USER}@${APP_SERVER_IP}:~/rohlig-two-server-master-repo"
rsync -av --delete "${EXCLUDES[@]}" "${ROOT_DIR}/" "${APP_SSH_USER}@${APP_SERVER_IP}:~/rohlig-two-server-master-repo/"

echo "[OK] Repo sync to both servers completed"
