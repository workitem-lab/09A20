#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
PLATFORM_ENV="$ROOT_DIR/config/platform.env"

CICD_USER="RGITDev"
CICD_IP="172.28.29.35"
APP_USER="RGITDev"
APP_IP="172.28.29.68"

if [[ -f "$PLATFORM_ENV" ]]; then
  set -a
  # shellcheck source=/dev/null
  source "$PLATFORM_ENV"
  set +a
  CICD_USER="${CICD_SSH_USER:-$CICD_USER}"
  CICD_IP="${CICD_SERVER_IP:-$CICD_IP}"
  APP_USER="${APP_SSH_USER:-$APP_USER}"
  APP_IP="${APP_SERVER_IP:-$APP_IP}"
fi

cat <<EOF2
Run these manually from your laptop:

ssh ${CICD_USER}@${CICD_IP}
ssh ${APP_USER}@${APP_IP}

If needed, force password authentication for first login checks:

ssh -o PreferredAuthentications=password -o PubkeyAuthentication=no -o IdentitiesOnly=yes ${CICD_USER}@${CICD_IP}
ssh -o PreferredAuthentications=password -o PubkeyAuthentication=no -o IdentitiesOnly=yes ${APP_USER}@${APP_IP}
EOF2
