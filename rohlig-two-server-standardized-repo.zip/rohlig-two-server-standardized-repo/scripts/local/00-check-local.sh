#!/usr/bin/env bash
set -euo pipefail

for cmd in ssh scp rsync git tar zip python3; do
  if command -v "$cmd" >/dev/null 2>&1; then
    echo "[OK] $cmd -> $(command -v "$cmd")"
  else
    echo "[WARN] Missing: $cmd"
  fi
done

echo
echo "Local SSH keys:"
ls -lah ~/.ssh || true
