#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
source "$ROOT_DIR/scripts/lib/common.sh"

load_config

echo "[1] Frontend root"
curl -I "http://${APP_SERVER_IP}/"

echo
echo "[2] Backend health"
curl -fsS "http://${APP_SERVER_IP}:${PUBLIC_BACKEND_PORT}${BACKEND_HEALTH_PATH}"

echo
echo "[3] Prometheus"
curl -I "http://${APP_SERVER_IP}:${PUBLIC_PROMETHEUS_PORT}/"

echo
echo "[4] Grafana"
curl -I "http://${APP_SERVER_IP}:${PUBLIC_GRAFANA_PORT}/"

echo
echo "[5] Kafka listener check from local machine"
if command -v nc >/dev/null 2>&1; then
  nc -vz "${APP_SERVER_IP}" "${PUBLIC_KAFKA_PORT}"
else
  echo "[WARN] nc not installed locally; skipping TCP check for Kafka"
fi

echo "[OK] Exposed URL and port checks finished"
