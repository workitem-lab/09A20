#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PLATFORM_ENV="${ROOT_DIR}/config/platform.env"
BITBUCKET_ENV="${ROOT_DIR}/config/bitbucket.env"
RUNTIME_ENV="${ROOT_DIR}/config/runtime.env"

require_file() {
  local file="$1"
  if [[ ! -f "$file" ]]; then
    echo "[ERROR] Required file not found: $file" >&2
    exit 1
  fi
}

load_config() {
  require_file "$PLATFORM_ENV"
  require_file "$BITBUCKET_ENV"
  set -a
  # shellcheck source=/dev/null
  source "$PLATFORM_ENV"
  # shellcheck source=/dev/null
  source "$BITBUCKET_ENV"
  set +a
}

load_runtime_env_if_present() {
  if [[ -f "$RUNTIME_ENV" ]]; then
    set -a
    # shellcheck source=/dev/null
    source "$RUNTIME_ENV"
    set +a
  fi
}

log() {
  printf '\n[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"
}

ensure_dir() {
  mkdir -p "$1"
}

require_cmd() {
  local cmd="$1"
  command -v "$cmd" >/dev/null 2>&1 || { echo "[ERROR] Missing command: $cmd" >&2; exit 1; }
}

require_vars() {
  local name
  for name in "$@"; do
    if [[ -z "${!name:-}" ]]; then
      echo "[ERROR] Required variable is empty: $name" >&2
      exit 1
    fi
  done
}

bitbucket_clone_url() {
  local repo_slug="$1"
  require_vars BITBUCKET_BASE_URL BITBUCKET_WORKSPACE BITBUCKET_APP_USER BITBUCKET_APP_PASSWORD
  printf '%s/%s/%s.git\n' \
    "${BITBUCKET_BASE_URL/https:\/\//https://${BITBUCKET_APP_USER}:${BITBUCKET_APP_PASSWORD}@}" \
    "$BITBUCKET_WORKSPACE" \
    "$repo_slug"
}

trim() {
  awk '{$1=$1};1'
}
