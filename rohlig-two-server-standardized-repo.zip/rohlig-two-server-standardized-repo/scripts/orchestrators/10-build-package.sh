#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/lib/common.sh"
load_config

require_cmd git
require_cmd docker
require_cmd tar
require_cmd find
require_cmd awk
require_vars CICD_ROOT WORKSPACE_DIR RELEASES_DIR BACKEND_REPO_SLUG FRONTEND_REPO_SLUG BACKEND_BRANCH FRONTEND_BRANCH

BUILD_ROOT="${WORKSPACE_DIR}"
SRC_ROOT="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/package"
BACKEND_SRC="${SRC_ROOT}/backend"
FRONTEND_SRC="${SRC_ROOT}/frontend"
STAMP="$(date +%Y%m%d_%H%M%S)"
RELEASE_ID="${STAMP}"
RELEASE_DIR="${RELEASES_DIR}/${RELEASE_ID}"
RELEASE_TAR="${RELEASES_DIR}/${RELEASE_ID}.tar.gz"

log "Preparing workspace"
sudo mkdir -p "${CICD_ROOT}" "${WORKSPACE_DIR}" "${RELEASES_DIR}"
sudo chown -R "$(id -u):$(id -g)" "${CICD_ROOT}"
rm -rf "${SRC_ROOT}" "${PKG_ROOT}"
mkdir -p "${SRC_ROOT}" "${PKG_ROOT}" "${RELEASE_DIR}"/{compose/nginx,compose/prometheus,images,env,metadata}

log "Cloning backend repo ${BACKEND_REPO_SLUG}"
rm -rf "${BACKEND_SRC}"
git clone --branch "${BACKEND_BRANCH}" --depth 1 "$(bitbucket_clone_url "${BACKEND_REPO_SLUG}")" "${BACKEND_SRC}"

log "Cloning frontend repo ${FRONTEND_REPO_SLUG}"
rm -rf "${FRONTEND_SRC}"
git clone --branch "${FRONTEND_BRANCH}" --depth 1 "$(bitbucket_clone_url "${FRONTEND_REPO_SLUG}")" "${FRONTEND_SRC}"

log "Building backend inside ${MAVEN_BUILDER_IMAGE}"
chmod +x "${BACKEND_SRC}/mvnw" 2>/dev/null || true
docker run --rm \
  -u "$(id -u):$(id -g)" \
  -v "${BACKEND_SRC}:/workspace" \
  -w /workspace \
  "${MAVEN_BUILDER_IMAGE}" \
  bash -lc "${BACKEND_BUILD_CMD}"

BACKEND_JAR="$(find "${BACKEND_SRC}" -path "*/target/*.jar" ! -name '*sources.jar' ! -name '*javadoc.jar' | sort | tail -n 1)"
if [[ -z "${BACKEND_JAR}" ]]; then
  echo "[ERROR] No backend JAR found under ${BACKEND_SRC}" >&2
  exit 1
fi
log "Resolved backend JAR: ${BACKEND_JAR}"

log "Building frontend inside ${NODE_BUILDER_IMAGE}"
docker run --rm \
  -u "$(id -u):$(id -g)" \
  -v "${FRONTEND_SRC}:/workspace" \
  -w /workspace \
  "${NODE_BUILDER_IMAGE}" \
  bash -lc "corepack enable >/dev/null 2>&1 || true; ${FRONTEND_BUILD_CMD}"

FRONTEND_DIST_DIR="$(find "${FRONTEND_SRC}/${FRONTEND_DIST_HINT}" -type f -name index.html -print 2>/dev/null | head -n 1 | xargs -r dirname)"
if [[ -z "${FRONTEND_DIST_DIR}" ]]; then
  echo "[ERROR] Could not resolve frontend dist directory. Check FRONTEND_DIST_HINT in config/platform.env" >&2
  exit 1
fi
log "Resolved frontend dist directory: ${FRONTEND_DIST_DIR}"

log "Preparing backend image build context"
BACKEND_CTX="${PKG_ROOT}/backend-image"
rm -rf "${BACKEND_CTX}"
mkdir -p "${BACKEND_CTX}"
cp "${ROOT_DIR}/docker/backend-runtime/Dockerfile" "${BACKEND_CTX}/Dockerfile"
cp "${BACKEND_JAR}" "${BACKEND_CTX}/app.jar"

log "Preparing frontend image build context"
FRONTEND_CTX="${PKG_ROOT}/frontend-image"
rm -rf "${FRONTEND_CTX}"
mkdir -p "${FRONTEND_CTX}/dist"
cp "${ROOT_DIR}/docker/frontend-runtime/Dockerfile" "${FRONTEND_CTX}/Dockerfile"
cp -R "${FRONTEND_DIST_DIR}/." "${FRONTEND_CTX}/dist/"

BACKEND_IMAGE_TAG="${BACKEND_IMAGE_REPO}:${RELEASE_ID}"
FRONTEND_IMAGE_TAG="${FRONTEND_IMAGE_REPO}:${RELEASE_ID}"

log "Building backend image ${BACKEND_IMAGE_TAG}"
docker build \
  --build-arg BASE_IMAGE="${BACKEND_BASE_RUNTIME_IMAGE}" \
  -t "${BACKEND_IMAGE_TAG}" \
  "${BACKEND_CTX}"

log "Building frontend image ${FRONTEND_IMAGE_TAG}"
docker build \
  --build-arg BASE_IMAGE="${FRONTEND_BASE_RUNTIME_IMAGE}" \
  -t "${FRONTEND_IMAGE_TAG}" \
  "${FRONTEND_CTX}"

log "Saving Docker images"
docker save "${BACKEND_IMAGE_TAG}" | gzip > "${RELEASE_DIR}/images/backend-image.tar.gz"
docker save "${FRONTEND_IMAGE_TAG}" | gzip > "${RELEASE_DIR}/images/frontend-image.tar.gz"

log "Copying deployment templates"
cp "${ROOT_DIR}/deploy/compose/docker-compose.prod.yml" "${RELEASE_DIR}/compose/docker-compose.prod.yml"
cp "${ROOT_DIR}/deploy/compose/nginx/default.conf" "${RELEASE_DIR}/compose/nginx/default.conf"
cp "${ROOT_DIR}/deploy/compose/prometheus/prometheus.yml" "${RELEASE_DIR}/compose/prometheus/prometheus.yml"

cat > "${RELEASE_DIR}/env/release.env" <<EOF
RELEASE_ID=${RELEASE_ID}
APP_SERVER_IP=${APP_SERVER_IP}
PUBLIC_HTTP_PORT=${PUBLIC_HTTP_PORT}
PUBLIC_BACKEND_PORT=${PUBLIC_BACKEND_PORT}
PUBLIC_KAFKA_PORT=${PUBLIC_KAFKA_PORT}
PUBLIC_PROMETHEUS_PORT=${PUBLIC_PROMETHEUS_PORT}
PUBLIC_GRAFANA_PORT=${PUBLIC_GRAFANA_PORT}
BACKEND_IMAGE=${BACKEND_IMAGE_TAG}
FRONTEND_IMAGE=${FRONTEND_IMAGE_TAG}
BACKEND_HEALTH_PATH=${BACKEND_HEALTH_PATH}
BACKEND_PROMETHEUS_PATH=${BACKEND_PROMETHEUS_PATH}
KAFKA_NODE_ID=${KAFKA_NODE_ID}
KAFKA_CLUSTER_ID=${KAFKA_CLUSTER_ID}
KAFKA_CONTROLLER_PORT=${KAFKA_CONTROLLER_PORT}
KAFKA_INTERNAL_PORT=${KAFKA_INTERNAL_PORT}
KAFKA_EXTERNAL_PORT=${KAFKA_EXTERNAL_PORT}
EOF

cat > "${RELEASE_DIR}/metadata/build-info.txt" <<EOF
RELEASE_ID=${RELEASE_ID}
BUILT_AT=$(date -Is)
BACKEND_REPO_SLUG=${BACKEND_REPO_SLUG}
BACKEND_BRANCH=${BACKEND_BRANCH}
FRONTEND_REPO_SLUG=${FRONTEND_REPO_SLUG}
FRONTEND_BRANCH=${FRONTEND_BRANCH}
BACKEND_IMAGE=${BACKEND_IMAGE_TAG}
FRONTEND_IMAGE=${FRONTEND_IMAGE_TAG}
EOF

log "Packaging release tarball ${RELEASE_TAR}"
tar -C "${RELEASES_DIR}" -czf "${RELEASE_TAR}" "${RELEASE_ID}"

log "Build and package complete"
echo "RELEASE_ID=${RELEASE_ID}"
echo "RELEASE_DIR=${RELEASE_DIR}"
echo "RELEASE_TAR=${RELEASE_TAR}"
