#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/lib/common.sh"
load_config

log "Running remote status check"
ssh "${APP_SSH_USER}@${APP_SERVER_IP}" "cd ~/rohlig-two-server-master-repo/servers/RGZADEVOPS01/scripts 2>/dev/null && ./60-status.sh || true"

echo
echo "Expected URLs from your dev machine:"
echo "Frontend      : http://${APP_SERVER_IP}/"
echo "Backend health: http://${APP_SERVER_IP}:${PUBLIC_BACKEND_PORT}${BACKEND_HEALTH_PATH}"
echo "Prometheus    : http://${APP_SERVER_IP}:${PUBLIC_PROMETHEUS_PORT}/"
echo "Grafana       : http://${APP_SERVER_IP}:${PUBLIC_GRAFANA_PORT}/"
