#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/lib/common.sh"
load_config

require_cmd ssh
require_cmd scp
require_cmd ls

LATEST_TAR="$(ls -1t "${RELEASES_DIR}"/*.tar.gz 2>/dev/null | head -n 1)"
if [[ -z "${LATEST_TAR}" ]]; then
  echo "[ERROR] No release tarball found in ${RELEASES_DIR}" >&2
  exit 1
fi

log "Using latest release tarball: ${LATEST_TAR}"
RELEASE_NAME="$(basename "${LATEST_TAR}")"
REMOTE_TMP_TAR="/tmp/${RELEASE_NAME}"
REMOTE_DEPLOY_SCRIPT="/tmp/40-deploy-release.sh"
REMOTE_RUNTIME_ENV="/tmp/runtime.env"

log "Checking SSH connectivity to app server"
ssh -o BatchMode=yes -o ConnectTimeout=10 "${APP_SSH_USER}@${APP_SERVER_IP}" "hostname && whoami"

log "Uploading runtime env"
scp "${ROOT_DIR}/config/runtime.env" "${APP_SSH_USER}@${APP_SERVER_IP}:${REMOTE_RUNTIME_ENV}"

log "Uploading release tarball"
scp "${LATEST_TAR}" "${APP_SSH_USER}@${APP_SERVER_IP}:${REMOTE_TMP_TAR}"

log "Uploading deploy script"
scp "${ROOT_DIR}/servers/RGZADEVOPS01/scripts/40-deploy-release.sh" "${APP_SSH_USER}@${APP_SERVER_IP}:${REMOTE_DEPLOY_SCRIPT}"

log "Running remote deployment"
ssh "${APP_SSH_USER}@${APP_SERVER_IP}" "chmod +x ${REMOTE_DEPLOY_SCRIPT} && ${REMOTE_DEPLOY_SCRIPT} ${REMOTE_TMP_TAR} ${REMOTE_RUNTIME_ENV}"
