#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/lib/common.sh"
load_config

log "Running remote smoke tests"
ssh "${APP_SSH_USER}@${APP_SERVER_IP}" "cd ~/rohlig-two-server-master-repo/servers/RGZADEVOPS01/scripts 2>/dev/null && ./70-smoke-tests.sh"
