# Run and Test

## Start
From the repo root:
```bash
cp .env.rohligplatform .env
docker compose build --no-cache
docker compose up
```

## Health checks
```bash
curl http://localhost:8080/api/v1/shipments/health
curl http://localhost:8080/api/v1/costs/health
curl http://localhost:8080/api/v1/quotations/health
curl http://localhost:8082/api/v1/tariffs/health
```

## Create shipment
```bash
curl -X POST http://localhost:8080/api/v1/shipments   -H "Content-Type: application/json"   -H "Idempotency-Key: shipment-create-001"   -d @samples/fcl-import-shipment.json
```

## Fetch results
```bash
sleep 5
curl http://localhost:8080/api/v1/costs/SHIP-1001
curl http://localhost:8080/api/v1/quotations/SHIP-1001
```
