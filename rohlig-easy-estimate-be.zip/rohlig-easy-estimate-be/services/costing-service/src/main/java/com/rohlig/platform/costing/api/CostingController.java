package com.rohlig.platform.costing.api;

import com.rohlig.platform.costing.domain.CostRecordEntity;
import com.rohlig.platform.costing.service.CostingService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/costs")
public class CostingController {
    private final CostingService costingService;

    public CostingController(CostingService costingService) {
        this.costingService = costingService;
    }

    @PostMapping("/recalculate")
    public CostRecordEntity recalculate(@RequestHeader("Idempotency-Key") String idempotencyKey,
                                        @Valid @RequestBody RecalculateCostRequest request) {
        return costingService.recalculate(idempotencyKey, request);
    }

    @GetMapping("/{shipmentId}")
    public CostRecordEntity get(@PathVariable String shipmentId) {
        return costingService.get(shipmentId);
    }

    @GetMapping
    public PageResponse<CostRecordEntity> search(@RequestParam(required = false) String clientId,
                                                 @RequestParam(required = false) String modality,
                                                 @RequestParam(required = false) String shipmentType,
                                                 @RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "20") int size) {
        List<CostRecordEntity> filtered = costingService.searchAll().stream()
                .filter(c -> clientId == null || clientId.equals(c.getClientId()))
                .filter(c -> modality == null || modality.equals(c.getModality()))
                .filter(c -> shipmentType == null || shipmentType.equals(c.getShipmentType()))
                .toList();
        int from = Math.min(page * size, filtered.size());
        int to = Math.min(from + size, filtered.size());
        int totalPages = size == 0 ? 0 : (int) Math.ceil((double) filtered.size() / size);
        return new PageResponse<>(filtered.subList(from, to), filtered.size(), totalPages, page, size);
    }

    @GetMapping("/health")
    public String health() {
        return "costing-service running";
    }
}
