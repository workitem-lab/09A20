package com.rohlig.platform.costing.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rohlig.platform.costing.api.IdempotencyConflictException;
import com.rohlig.platform.costing.api.RecalculateCostRequest;
import com.rohlig.platform.costing.domain.*;
import com.rohlig.platform.costing.events.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
public class CostingService {
    private final TariffClient tariffClient;
    private final CalculationEngine calculationEngine;
    private final CostRecordRepository costRecordRepository;
    private final IdempotencyRecordRepository idempotencyRepository;
    private final CostEventProducer eventProducer;
    private final ObjectMapper objectMapper;

    public CostingService(TariffClient tariffClient, CalculationEngine calculationEngine,
                          CostRecordRepository costRecordRepository,
                          IdempotencyRecordRepository idempotencyRepository,
                          CostEventProducer eventProducer,
                          ObjectMapper objectMapper) {
        this.tariffClient = tariffClient;
        this.calculationEngine = calculationEngine;
        this.costRecordRepository = costRecordRepository;
        this.idempotencyRepository = idempotencyRepository;
        this.eventProducer = eventProducer;
        this.objectMapper = objectMapper;
    }

    public CostRecordEntity process(ShipmentCreatedEvent shipment) {
        TariffResolutionResponse resolution = tariffClient.resolve(new TariffResolutionRequest(
                shipment.clientId(), shipment.modality(), shipment.shipmentType(), shipment.incoterm(),
                shipment.originCountry(), shipment.destinationCountry(), shipment.portOfLoading(), shipment.portOfDestination(),
                shipment.finalDeliveryArea(), shipment.carrier(), shipment.chargeableWeight(), shipment.container20Qty(),
                shipment.container40Qty(), shipment.cbm(), shipment.goodsValue(), shipment.currency(),
                shipment.hsCode(), shipment.unitQuantity(), shipment.tradeLaneAgreement()
        ));
        return persist(shipment, resolution);
    }

    public CostRecordEntity recalculate(String idempotencyKey, RecalculateCostRequest request) {
        String requestHash = hash(request);
        IdempotencyRecord existing = idempotencyRepository.findById(idempotencyKey).orElse(null);
        if (existing != null) {
            if (!existing.getRequestHash().equals(requestHash)) {
                throw new IdempotencyConflictException("Idempotency key already used for a different request");
            }
            return costRecordRepository.findById(existing.getResourceId()).orElseThrow(() -> new NoSuchElementException("Existing cost not found"));
        }
        ShipmentCreatedEvent shipment = new ShipmentCreatedEvent(
                request.shipmentId(), request.clientId(), request.modality(), request.shipmentType(), request.incoterm(),
                request.originCountry(), request.destinationCountry(), request.portOfLoading(), request.portOfDestination(),
                request.finalDeliveryArea(), request.carrier(), request.chargeableWeight(), request.container20Qty(),
                request.container40Qty(), request.cbm(), request.goodsValue(), request.currency(), request.hsCode(),
                request.unitQuantity(), request.tradeLaneAgreement()
        );
        TariffResolutionResponse resolution = tariffClient.resolve(new TariffResolutionRequest(
                shipment.clientId(), shipment.modality(), shipment.shipmentType(), shipment.incoterm(),
                shipment.originCountry(), shipment.destinationCountry(), shipment.portOfLoading(), shipment.portOfDestination(),
                shipment.finalDeliveryArea(), shipment.carrier(), shipment.chargeableWeight(), shipment.container20Qty(),
                shipment.container40Qty(), shipment.cbm(), shipment.goodsValue(), shipment.currency(), shipment.hsCode(),
                shipment.unitQuantity(), shipment.tradeLaneAgreement()
        ));
        CostRecordEntity saved = persist(shipment, resolution);
        IdempotencyRecord record = new IdempotencyRecord();
        record.setIdempotencyKey(idempotencyKey);
        record.setRequestHash(requestHash);
        record.setResourceId(saved.getShipmentId());
        idempotencyRepository.save(record);
        return saved;
    }

    public CostRecordEntity get(String shipmentId) {
        return costRecordRepository.findById(shipmentId).orElseThrow(() -> new NoSuchElementException("Cost record not found"));
    }

    public List<CostRecordEntity> searchAll() { return costRecordRepository.findAll(); }

    private CostRecordEntity persist(ShipmentCreatedEvent shipment, TariffResolutionResponse resolution) {
        CostAggregate aggregate = calculationEngine.calculate(shipment, resolution);
        CostRecordEntity entity = costRecordRepository.findById(shipment.shipmentId()).orElseGet(CostRecordEntity::new);
        entity.setShipmentId(shipment.shipmentId());
        entity.setClientId(shipment.clientId());
        entity.setModality(shipment.modality());
        entity.setShipmentType(shipment.shipmentType());
        entity.clearLines();

        BigDecimal operationalTotal = BigDecimal.ZERO;
        BigDecimal customsTotal = BigDecimal.ZERO;
        BigDecimal financeTotal = BigDecimal.ZERO;
        BigDecimal valuationBase = BigDecimal.ZERO;

        for (CostLine line : aggregate.lines()) {
            CostLineEntity item = new CostLineEntity();
            item.setLineType(line.type());
            item.setAmount(line.amount());
            item.setCurrencyCode(line.currency());
            item.setNotes(line.notes());
            entity.addLine(item);

            switch (line.type()) {
                case "FREIGHT" -> { entity.setFreight(line.amount()); operationalTotal = operationalTotal.add(line.amount()); }
                case "CARTAGE" -> { entity.setCartage(line.amount()); operationalTotal = operationalTotal.add(line.amount()); }
                case "DESTINATION_CHARGES" -> { entity.setDestinationCharges(line.amount()); operationalTotal = operationalTotal.add(line.amount()); }
                case "APPLICABLE_CHARGES" -> { entity.setApplicableCharges(line.amount()); operationalTotal = operationalTotal.add(line.amount()); }
                case "CUSTOMS_VALUE" -> { entity.setCustomsValue(line.amount()); valuationBase = valuationBase.add(line.amount()); }
                case "DUTY" -> { entity.setDuty(line.amount()); customsTotal = customsTotal.add(line.amount()); }
                case "AD_VALOREM" -> { entity.setAdValorem(line.amount()); customsTotal = customsTotal.add(line.amount()); }
                case "CUSTOMS_VAT" -> { entity.setCustomsVat(line.amount()); customsTotal = customsTotal.add(line.amount()); }
                case "FINANCE_FEE" -> { entity.setFinanceFee(line.amount()); financeTotal = financeTotal.add(line.amount()); }
                default -> { }
            }
        }
        BigDecimal payableTotal = operationalTotal.add(customsTotal).add(financeTotal);
        entity.setOperationalTotal(operationalTotal);
        entity.setCustomsTotal(customsTotal);
        entity.setFinanceTotal(financeTotal);
        entity.setValuationBase(valuationBase);
        entity.setPayableTotal(payableTotal);
        entity.setTotal(payableTotal);
        CostRecordEntity saved = costRecordRepository.save(entity);

        eventProducer.publish(new CostCalculatedEvent(
                saved.getShipmentId(), saved.getClientId(), saved.getModality(), saved.getShipmentType(),
                saved.getFreight(), saved.getCartage(), saved.getDestinationCharges(), saved.getApplicableCharges(),
                saved.getCustomsValue(), saved.getDuty(), saved.getAdValorem(), saved.getCustomsVat(),
                saved.getFinanceFee(), saved.getTotal(),
                saved.getLines().stream().map(l -> new CostLineEvent(l.getLineType(), l.getAmount(), l.getCurrencyCode(), l.getNotes())).collect(Collectors.toList())
        ));
        return saved;
    }

    private String hash(Object request) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(objectMapper.writeValueAsString(request).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to hash request", ex);
        }
    }
}
