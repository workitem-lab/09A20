package com.rohlig.platform.costing.domain;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CostRecordRepository extends JpaRepository<CostRecordEntity, String> {}
