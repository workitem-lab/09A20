package com.rohlig.platform.shipment.domain;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ShipmentRepository extends JpaRepository<ShipmentEntity, String> {}
