package com.rohlig.platform.shipment.api;

import com.rohlig.platform.shipment.domain.ShipmentEntity;
import com.rohlig.platform.shipment.service.ShipmentService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/shipments")
public class ShipmentController {
    private final ShipmentService shipmentService;

    public ShipmentController(ShipmentService shipmentService) {
        this.shipmentService = shipmentService;
    }

    @PostMapping
    public ShipmentEntity create(@RequestHeader("Idempotency-Key") String idempotencyKey,
                                 @Valid @RequestBody CreateShipmentRequest request) {
        return shipmentService.create(idempotencyKey, request);
    }

    @GetMapping("/{shipmentId}")
    public ShipmentEntity get(@PathVariable String shipmentId) {
        return shipmentService.get(shipmentId);
    }

    @GetMapping
    public PageResponse<ShipmentEntity> search(@RequestParam(required = false) String clientId,
                                               @RequestParam(required = false) String modality,
                                               @RequestParam(required = false) String shipmentType,
                                               @RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "20") int size) {
        List<ShipmentEntity> filtered = shipmentService.searchAll().stream()
                .filter(s -> clientId == null || clientId.equals(s.getClientId()))
                .filter(s -> modality == null || modality.equals(s.getModality()))
                .filter(s -> shipmentType == null || shipmentType.equals(s.getShipmentType()))
                .toList();
        int from = Math.min(page * size, filtered.size());
        int to = Math.min(from + size, filtered.size());
        int totalPages = size == 0 ? 0 : (int) Math.ceil((double) filtered.size() / size);
        return new PageResponse<>(filtered.subList(from, to), filtered.size(), totalPages, page, size);
    }

    @GetMapping("/health")
    public String health() {
        return "shipment-service running";
    }
}
