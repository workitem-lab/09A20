package com.rohlig.platform.shipment.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rohlig.platform.shipment.api.CreateShipmentRequest;
import com.rohlig.platform.shipment.api.IdempotencyConflictException;
import com.rohlig.platform.shipment.domain.*;
import com.rohlig.platform.shipment.events.ShipmentCreatedEvent;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class ShipmentService {
    private final ShipmentRepository shipmentRepository;
    private final IdempotencyRecordRepository idempotencyRepository;
    private final ShipmentEventProducer eventProducer;
    private final ObjectMapper objectMapper;

    public ShipmentService(ShipmentRepository shipmentRepository,
                           IdempotencyRecordRepository idempotencyRepository,
                           ShipmentEventProducer eventProducer,
                           ObjectMapper objectMapper) {
        this.shipmentRepository = shipmentRepository;
        this.idempotencyRepository = idempotencyRepository;
        this.eventProducer = eventProducer;
        this.objectMapper = objectMapper;
    }

    public ShipmentEntity create(String idempotencyKey, CreateShipmentRequest request) {
        String requestHash = hash(request);
        IdempotencyRecord existing = idempotencyRepository.findById(idempotencyKey).orElse(null);
        if (existing != null) {
            if (!existing.getRequestHash().equals(requestHash)) {
                throw new IdempotencyConflictException("Idempotency key already used for a different request");
            }
            return shipmentRepository.findById(existing.getResourceId()).orElseThrow(() -> new NoSuchElementException("Existing shipment not found"));
        }

        ShipmentEntity entity = new ShipmentEntity();
        entity.setShipmentId(request.shipmentId());
        entity.setClientId(request.clientId());
        entity.setModality(request.modality());
        entity.setShipmentType(request.shipmentType());
        entity.setIncoterm(request.incoterm());
        entity.setOriginCountry(request.originCountry());
        entity.setDestinationCountry(request.destinationCountry());
        entity.setPortOfLoading(request.portOfLoading());
        entity.setPortOfDestination(request.portOfDestination());
        entity.setFinalDeliveryArea(request.finalDeliveryArea());
        entity.setCarrier(request.carrier());
        entity.setChargeableWeight(request.chargeableWeight());
        entity.setContainer20Qty(request.container20Qty());
        entity.setContainer40Qty(request.container40Qty());
        entity.setCbm(request.cbm());
        entity.setGoodsValue(request.goodsValue());
        entity.setCurrency(request.currency());
        entity.setHsCode(request.hsCode());
        entity.setUnitQuantity(request.unitQuantity());
        entity.setTradeLaneAgreement(request.tradeLaneAgreement());

        ShipmentEntity saved = shipmentRepository.save(entity);

        IdempotencyRecord record = new IdempotencyRecord();
        record.setIdempotencyKey(idempotencyKey);
        record.setRequestHash(requestHash);
        record.setResourceId(saved.getShipmentId());
        idempotencyRepository.save(record);

        eventProducer.publish(new ShipmentCreatedEvent(
                saved.getShipmentId(), saved.getClientId(), saved.getModality(), saved.getShipmentType(),
                saved.getIncoterm(), saved.getOriginCountry(), saved.getDestinationCountry(),
                saved.getPortOfLoading(), saved.getPortOfDestination(), saved.getFinalDeliveryArea(),
                saved.getCarrier(), saved.getChargeableWeight(), saved.getContainer20Qty(), saved.getContainer40Qty(),
                saved.getCbm(), saved.getGoodsValue(), saved.getCurrency(), saved.getHsCode(),
                saved.getUnitQuantity(), saved.isTradeLaneAgreement()
        ));
        return saved;
    }

    public ShipmentEntity get(String shipmentId) {
        return shipmentRepository.findById(shipmentId).orElseThrow(() -> new NoSuchElementException("Shipment not found"));
    }

    public List<ShipmentEntity> searchAll() {
        return shipmentRepository.findAll();
    }

    private String hash(Object request) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(objectMapper.writeValueAsString(request).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to hash request", ex);
        }
    }
}
