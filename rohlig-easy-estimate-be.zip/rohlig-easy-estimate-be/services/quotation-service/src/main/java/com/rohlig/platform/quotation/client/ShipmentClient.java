package com.rohlig.platform.quotation.client;

import com.rohlig.platform.quotation.security.ServiceAccessTokenProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class ShipmentClient {
    private final RestClient restClient;
    private final ServiceAccessTokenProvider tokenProvider;
    public ShipmentClient(@Value("${quotation.services.shipment-base-url}") String baseUrl, RestClient.Builder builder, ServiceAccessTokenProvider tokenProvider) {
        this.restClient = builder.baseUrl(baseUrl).build();
        this.tokenProvider = tokenProvider;
    }
    public ShipmentDto get(String shipmentId) {
        return restClient.get()
                .uri("/api/v1/shipments/{shipmentId}", shipmentId)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + tokenProvider.getAccessToken())
                .retrieve().body(ShipmentDto.class);
    }
}
