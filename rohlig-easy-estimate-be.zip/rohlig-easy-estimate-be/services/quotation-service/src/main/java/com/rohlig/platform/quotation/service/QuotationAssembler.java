package com.rohlig.platform.quotation.service;

import com.rohlig.platform.quotation.client.CostRecordDto;
import com.rohlig.platform.quotation.client.ShipmentDto;
import com.rohlig.platform.quotation.document.QuotationDocumentModel;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Component
public class QuotationAssembler {
    private final QuotationTemplateResolver templateResolver;
    public QuotationAssembler(QuotationTemplateResolver templateResolver) { this.templateResolver = templateResolver; }
    public QuotationDocumentModel assemble(ShipmentDto shipment, CostRecordDto cost) {
        String templateCode = templateResolver.resolve(shipment.modality(), shipment.shipmentType());
        String estimateNumber = shipment.shipmentId().replace("SHIP-", "EST-");
        var sections = List.of(
                new QuotationDocumentModel.ChargeSection("FREIGHT", "Freight Charges", List.of(
                        line("Base Freight", cost.freight()), line("Cartage", cost.cartage()))),
                new QuotationDocumentModel.ChargeSection("DESTINATION", "Destination Charges", List.of(
                        line("Destination Charges", cost.destinationCharges()), line("Applicable Charges", cost.applicableCharges()))),
                new QuotationDocumentModel.ChargeSection("CUSTOMS", "Customs and Finance", List.of(
                        line("Duty", cost.duty()), line("Ad Valorem", cost.adValorem()), line("Customs VAT", cost.customsVat()), line("Finance Fee", cost.financeFee())))
        );
        BigDecimal subtotal = nz(cost.operationalTotal()).add(nz(cost.customsTotal())).add(nz(cost.financeTotal()));
        return new QuotationDocumentModel(
                shipment.shipmentId(), shipment.clientId(), templateCode, estimateNumber, 1, LocalDate.now(),
                "Röhlig-Grindrod (Pty) Ltd", "4870188051",
                "2 Price Lane, Extension 127, Meadowview Business Estate, Linbro Park, 2065, South Africa",
                "30 DAYS FROM STATEMENT", LocalDate.now().plusDays(7),
                new QuotationDocumentModel.ShipmentDetails(shipment.clientId(), shipment.clientId(), shipment.originCountry(),
                        shipment.destinationCountry(), shipment.portOfLoading(), shipment.portOfDestination(),
                        shipment.finalDeliveryArea(), shipment.modality(), shipment.shipmentType(), shipment.incoterm(),
                        shipment.carrier(), shipment.chargeableWeight(), shipment.container20Qty(), shipment.container40Qty(),
                        shipment.cbm(), shipment.goodsValue(), shipment.currency(), shipment.hsCode(), shipment.unitQuantity()),
                sections,
                new QuotationDocumentModel.Totals(subtotal, BigDecimal.ZERO, nz(cost.total()), "ZAR"),
                List.of("Based on the provided information.", "Excluding customs duty, taxes or insurance unless listed.", "Validity as indicated on the estimate."),
                List.of("This estimate is non-binding and subject to the Company Standard Trading Terms and Conditions.", "Additional charges may arise at the time of shipment.")
        );
    }
    private QuotationDocumentModel.ChargeLine line(String description, BigDecimal amount) {
        return new QuotationDocumentModel.ChargeLine(description, "Z", "PER_SHIPMENT", null, null, "ZAR", nz(amount), BigDecimal.ZERO);
    }
    private BigDecimal nz(BigDecimal value) { return value == null ? BigDecimal.ZERO : value; }
}
