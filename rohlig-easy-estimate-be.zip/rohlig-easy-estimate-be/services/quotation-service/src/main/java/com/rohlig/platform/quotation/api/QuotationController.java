package com.rohlig.platform.quotation.api;

import com.rohlig.platform.quotation.domain.QuotationProjectionEntity;
import com.rohlig.platform.quotation.service.QuotationGenerationService;
import com.rohlig.platform.quotation.service.QuotationService;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class QuotationController {
    private final QuotationService quotationService;
    private final QuotationGenerationService quotationGenerationService;
    public QuotationController(QuotationService quotationService, QuotationGenerationService quotationGenerationService) {
        this.quotationService = quotationService; this.quotationGenerationService = quotationGenerationService;
    }
    @GetMapping({"/api/v1/quotations/{shipmentId}", "/api/v1/invoices/{shipmentId}"})
    public QuotationProjectionEntity get(@PathVariable String shipmentId) { return quotationService.get(shipmentId); }
    @GetMapping({"/api/v1/quotations", "/api/v1/invoices"})
    public PageResponse<QuotationProjectionEntity> search(@RequestParam(required = false) String clientId,
                                                          @RequestParam(required = false) String status,
                                                          @RequestParam(defaultValue = "0") int page,
                                                          @RequestParam(defaultValue = "20") int size) {
        List<QuotationProjectionEntity> filtered = quotationService.searchAll().stream().filter(i -> clientId == null || clientId.equals(i.getClientId())).filter(i -> status == null || status.equals(i.getStatus())).toList();
        int from = Math.min(page * size, filtered.size()); int to = Math.min(from + size, filtered.size()); int totalPages = size == 0 ? 0 : (int) Math.ceil((double) filtered.size() / size);
        return new PageResponse<>(filtered.subList(from, to), filtered.size(), totalPages, page, size);
    }
    @PostMapping("/api/v1/quotations/{shipmentId}/generate")
    public GeneratedDocumentResponse generate(@PathVariable String shipmentId) { return quotationGenerationService.generate(shipmentId); }
    @GetMapping("/api/v1/quotations/{shipmentId}/documents/csv")
    public ResponseEntity<byte[]> downloadCsv(@PathVariable String shipmentId) {
        byte[] body = quotationGenerationService.download(shipmentId, "CSV");
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(shipmentId + ".csv").build().toString()).contentType(MediaType.parseMediaType("text/csv")).body(body);
    }
    @GetMapping("/api/v1/quotations/{shipmentId}/documents/pdf")
    public ResponseEntity<byte[]> downloadPdf(@PathVariable String shipmentId) {
        byte[] body = quotationGenerationService.download(shipmentId, "PDF");
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(shipmentId + ".pdf").build().toString()).contentType(MediaType.APPLICATION_PDF).body(body);
    }
    @GetMapping({"/api/v1/quotations/health", "/api/v1/invoices/health"})
    public String health() { return "quotation-service running"; }
}
