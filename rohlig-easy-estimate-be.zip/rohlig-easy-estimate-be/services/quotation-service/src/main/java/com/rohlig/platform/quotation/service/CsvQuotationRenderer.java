package com.rohlig.platform.quotation.service;
import com.rohlig.platform.quotation.document.QuotationDocumentModel;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
@Component
public class CsvQuotationRenderer {
    public RenderedCsv render(QuotationDocumentModel model) {
        List<String> lines = loadTemplate();
        lines = replaceScalarMarkers(lines, model);
        lines = injectSection(lines, "##FREIGHT_ROWS##", rowsFor(section(model, "FREIGHT")));
        lines = injectSection(lines, "##DESTINATION_ROWS##", rowsFor(section(model, "DESTINATION")));
        lines = injectSection(lines, "##CUSTOMS_ROWS##", rowsFor(section(model, "CUSTOMS")));
        return new RenderedCsv(String.join(System.lineSeparator(), lines).getBytes(StandardCharsets.UTF_8), lines);
    }
    private List<String> loadTemplate() {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(
                        new ClassPathResource("quotation-templates/fcl-import/template.csv").getInputStream(),
                        StandardCharsets.UTF_8))) {
            return reader.lines().toList();
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to load quotation CSV template", ex);
        }
    }
    private List<String> replaceScalarMarkers(List<String> source, QuotationDocumentModel model) {
        List<String> target = new ArrayList<>();
        for (String line : source) {
            target.add(line.replace("${estimateNumber}", safe(model.estimateNumber()))
                    .replace("${estimateDate}", String.valueOf(model.estimateDate()))
                    .replace("${validUntil}", String.valueOf(model.validUntil()))
                    .replace("${clientId}", safe(model.clientId()))
                    .replace("${modality}", safe(model.shipment().modality()))
                    .replace("${shipmentType}", safe(model.shipment().shipmentType()))
                    .replace("${originCountry}", safe(model.shipment().originCountry()))
                    .replace("${destinationCountry}", safe(model.shipment().destinationCountry()))
                    .replace("${portOfLoading}", safe(model.shipment().portOfLoading()))
                    .replace("${portOfDestination}", safe(model.shipment().portOfDestination()))
                    .replace("${incoterm}", safe(model.shipment().incoterm()))
                    .replace("${carrier}", safe(model.shipment().carrier()))
                    .replace("${chargeableWeight}", String.valueOf(model.shipment().chargeableWeight()))
                    .replace("${subtotal}", String.valueOf(model.totals().subtotal()))
                    .replace("${vat}", String.valueOf(model.totals().vat()))
                    .replace("${total}", String.valueOf(model.totals().total()))
                    .replace("${currency}", safe(model.totals().currency())));
        }
        return target;
    }
    private List<String> injectSection(List<String> source, String marker, List<String> rows) {
        List<String> result = new ArrayList<>();
        for (String line : source) {
            if (line.contains(marker)) {
                result.addAll(rows);
            } else {
                result.add(line);
            }
        }
        return result;
    }
    private List<String> rowsFor(QuotationDocumentModel.ChargeSection section) {
        List<String> rows = new ArrayList<>();
        for (QuotationDocumentModel.ChargeLine line : section.lines()) {
            rows.add(csv(
                    section.title(),
                    line.description(),
                    line.vatCode(),
                    line.calculationBasis(),
                    line.localCurrency(),
                    line.localAmountExcl()));
        }
        return rows;
    }
    private String csv(Object... values) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) {
                sb.append(',');
            }
            String value = values[i] == null ? "" : String.valueOf(values[i]);
            sb.append('"').append(value.replace("\"", "\"\"")).append('"');
        }
        return sb.toString();
    }
    private QuotationDocumentModel.ChargeSection section(QuotationDocumentModel model, String code) {
        return model.sections().stream()
                .filter(s -> code.equals(s.sectionCode()))
                .findFirst()
                .orElse(new QuotationDocumentModel.ChargeSection(code, code, List.of()));
    }
    private String safe(String value) {
        return value == null ? "" : value;
    }
    public record RenderedCsv(byte[] bytes, List<String> rows) {}
}