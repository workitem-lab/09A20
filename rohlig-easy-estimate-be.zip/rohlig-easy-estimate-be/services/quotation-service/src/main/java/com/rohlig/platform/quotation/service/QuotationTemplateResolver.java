package com.rohlig.platform.quotation.service;

import org.springframework.stereotype.Component;

@Component
public class QuotationTemplateResolver {
    public String resolve(String modality, String shipmentType) {
        String mod = modality == null ? "UNKNOWN" : modality.toUpperCase();
        String type = shipmentType == null ? "UNKNOWN" : shipmentType.toUpperCase();
        return switch (mod + "_" + type) {
            case "FCL_IMPORT" -> "QUOTE_FCL_IMPORT";
            case "FCL_EXPORT" -> "QUOTE_FCL_EXPORT";
            case "LCL_IMPORT" -> "QUOTE_LCL_IMPORT";
            case "AIR_IMPORT" -> "QUOTE_AIR_IMPORT";
            case "AIR_EXPORT" -> "QUOTE_AIR_EXPORT";
            default -> "QUOTE_GENERIC";
        };
    }
}
