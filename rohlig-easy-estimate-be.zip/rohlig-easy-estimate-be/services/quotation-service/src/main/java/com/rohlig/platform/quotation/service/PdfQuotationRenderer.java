package com.rohlig.platform.quotation.service;
import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.stereotype.Component;
import java.io.ByteArrayOutputStream;
import java.util.List;
@Component
public class PdfQuotationRenderer {
    public byte[] render(String title, List<String> csvRows) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            Document document = new Document();
            PdfWriter.getInstance(document, out);
            document.open();
            document.add(new Paragraph(title));
            document.add(new Paragraph("Generated from the filled quotation rows"));
            document.add(new Paragraph(" "));
            PdfPTable table = new PdfPTable(6);
            table.setWidthPercentage(100);
            for (String header : new String[]{"Section", "Description", "VAT", "Basis", "Currency", "Amount"}) {
                table.addCell(header);
            }
            for (String row : csvRows) {
                if (row.startsWith("\"") && !row.contains("${")) {
                    String[] parts = parse(row);
                    if (parts.length >= 6
                            && !"Field".equalsIgnoreCase(parts[0])
                            && !"Section".equalsIgnoreCase(parts[0])
                            && !parts[0].isBlank()) {
                        for (int i = 0; i < 6; i++) {
                            table.addCell(parts[i]);
                        }
                    }
                }
            }
            document.add(table);
            document.close();
            return out.toByteArray();
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to render PDF", ex);
        }
    }
    private String[] parse(String row) {
        String trimmed = row.substring(1, row.length() - 1);
        return trimmed.split("\",\"");
    }
}