package com.rohlig.platform.quotation.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface QuotationProjectionRepository extends JpaRepository<QuotationProjectionEntity, String> {
}
