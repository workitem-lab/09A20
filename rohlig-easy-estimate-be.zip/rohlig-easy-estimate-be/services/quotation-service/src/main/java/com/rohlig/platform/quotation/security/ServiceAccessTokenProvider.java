package com.rohlig.platform.quotation.security;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;

import java.time.Instant;

@Component
public class ServiceAccessTokenProvider {
    private final RestClient restClient;
    private final String clientId;
    private final String clientSecret;
    private volatile CachedToken cachedToken;

    public ServiceAccessTokenProvider(RestClient.Builder builder,
                                      @Value("${app.security.service-client.token-uri}") String tokenUri,
                                      @Value("${app.security.service-client.client-id}") String clientId,
                                      @Value("${app.security.service-client.client-secret}") String clientSecret) {
        this.restClient = builder.baseUrl(tokenUri).build();
        this.clientId = clientId;
        this.clientSecret = clientSecret;
    }

    public synchronized String getAccessToken() {
        if (cachedToken != null && cachedToken.expiresAt().isAfter(Instant.now().plusSeconds(30))) {
            return cachedToken.token();
        }
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("grant_type", "client_credentials");
        form.add("client_id", clientId);
        form.add("client_secret", clientSecret);
        TokenResponse response = restClient.post()
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .body(form)
                .retrieve()
                .body(TokenResponse.class);
        if (response == null || response.accessToken() == null || response.accessToken().isBlank()) {
            throw new IllegalStateException("Unable to obtain service access token");
        }
        cachedToken = new CachedToken(response.accessToken(), Instant.now().plusSeconds(Math.max(60, response.expiresIn())));
        return cachedToken.token();
    }

    private record CachedToken(String token, Instant expiresAt) {}
    private record TokenResponse(@JsonProperty("access_token") String accessToken, @JsonProperty("expires_in") long expiresIn) {}
}
