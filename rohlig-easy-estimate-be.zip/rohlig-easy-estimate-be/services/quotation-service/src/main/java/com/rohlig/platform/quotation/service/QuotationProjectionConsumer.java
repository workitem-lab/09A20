package com.rohlig.platform.quotation.service;

import com.rohlig.platform.quotation.domain.QuotationProjectionEntity;
import com.rohlig.platform.quotation.domain.QuotationProjectionRepository;
import com.rohlig.platform.quotation.events.CostCalculatedEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class QuotationProjectionConsumer {
    private final QuotationProjectionRepository repository;

    public QuotationProjectionConsumer(QuotationProjectionRepository repository) {
        this.repository = repository;
    }

    @KafkaListener(topics = "costing.calculated")
    public void handle(CostCalculatedEvent event) {
        QuotationProjectionEntity entity = new QuotationProjectionEntity();
        entity.setShipmentId(event.shipmentId());
        entity.setClientId(event.clientId());
        entity.setTotal(event.total());
        entity.setStatus("PROJECTED");
        entity.setTemplateCode(templateFor(event.modality(), event.shipmentType()));
        repository.save(entity);
    }

    private String templateFor(String modality, String shipmentType) {
        String mod = modality == null ? "UNKNOWN" : modality.toUpperCase();
        String type = shipmentType == null ? "UNKNOWN" : shipmentType.toUpperCase();
        return switch (mod + "_" + type) {
            case "FCL_IMPORT" -> "QUOTE_FCL_IMPORT";
            case "FCL_EXPORT" -> "QUOTE_FCL_EXPORT";
            case "LCL_IMPORT" -> "QUOTE_LCL_IMPORT";
            case "AIR_IMPORT" -> "QUOTE_AIR_IMPORT";
            case "AIR_EXPORT" -> "QUOTE_AIR_EXPORT";
            case "ROAD_EXPORT" -> "QUOTE_ROAD_EXPORT";
            default -> "QUOTE_GENERIC";
        };
    }
}
