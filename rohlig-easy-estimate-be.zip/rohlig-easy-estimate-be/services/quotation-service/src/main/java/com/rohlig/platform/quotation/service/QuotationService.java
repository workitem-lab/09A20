package com.rohlig.platform.quotation.service;

import com.rohlig.platform.quotation.domain.QuotationProjectionEntity;
import com.rohlig.platform.quotation.domain.QuotationProjectionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class QuotationService {
    private final QuotationProjectionRepository repository;

    public QuotationService(QuotationProjectionRepository repository) {
        this.repository = repository;
    }

    public QuotationProjectionEntity get(String shipmentId) {
        return repository.findById(shipmentId).orElseThrow(() -> new NoSuchElementException("Quotation projection not found"));
    }

    public List<QuotationProjectionEntity> searchAll() { return repository.findAll(); }
}
