#!/usr/bin/env bash
set -euo pipefail

curl -s http://localhost:8080/api/v1/shipments/health && echo
curl -s http://localhost:8080/api/v1/costs/health && echo
curl -s http://localhost:8080/api/v1/quotations/health && echo
curl -s http://localhost:8082/api/v1/tariffs/health && echo

curl -s -X POST http://localhost:8080/api/v1/shipments   -H "Content-Type: application/json"   -H "Idempotency-Key: shipment-create-001"   -H "X-Correlation-Id: demo-correlation-001"   -d @samples/fcl-import-shipment.json
echo

sleep 5

curl -s http://localhost:8080/api/v1/costs/SHIP-1001 && echo
curl -s http://localhost:8080/api/v1/quotations/SHIP-1001 && echo
