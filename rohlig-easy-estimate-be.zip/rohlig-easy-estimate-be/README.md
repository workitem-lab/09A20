# Röhlig Backend — Rebuilt Around Shipment, Costing, Quotation, Tariff, Rates Repository, and Rates Importer

This rebuild is grounded in the uploaded rule catalogue, ERD notes, and quote template guidance. It keeps the current end-to-end shipment -> costing -> quote flow, while moving the solution closer to the target enterprise domains.

## Included services
- gateway
- shipment-service
- tariff-service
- costing-service
- quotation-service
- rate-repository-service
- rates-importer-service

## Key changes in this rebuild
- `invoice-service` renamed to `quotation-service` because the current business artifact is a commercial quote / estimate, not a final AR invoice
- `/api/v1/invoices/**` kept as a compatibility alias to the quotation API
- PostgreSQL pinned to `15`
- Flyway PostgreSQL support module added to database-backed services
- Kafka JSON type-header issue fixed by disabling producer type headers and using consumer-side default event types
- costing header extended with `operationalTotal`, `customsTotal`, `financeTotal`, `valuationBase`, and `payableTotal`
- rate repository and importer service stubs added to reflect the target solution domains
- quote template strategy documented for XLSX -> PDF rendering later
- Keycloak + AD integration approach documented for enterprise SSO

## Start
```bash
cp .env.rohligplatform .env
docker compose build --no-cache
docker compose up
```

## Baseline smoke test
```bash
./scripts/test-e2e.sh
```

## Important note
This is a stronger backend source rebuild. It is designed to align better with the uploaded rules and target ERD, but it still needs environment-specific hardening, fuller tariff execution, and template rendering before it can be called production-complete.
